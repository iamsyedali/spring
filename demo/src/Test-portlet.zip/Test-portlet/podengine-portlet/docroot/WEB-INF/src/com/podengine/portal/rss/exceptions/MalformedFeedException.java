package com.podengine.portal.rss.exceptions;

public class MalformedFeedException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MalformedFeedException(String message, Throwable throwable) {
		super(message, throwable);
	}
}
