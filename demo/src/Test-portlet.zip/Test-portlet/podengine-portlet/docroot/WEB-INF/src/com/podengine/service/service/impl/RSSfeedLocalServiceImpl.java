/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.podengine.service.service.impl;

import java.util.List;

import com.liferay.portal.kernel.exception.SystemException;
import com.podengine.service.NoSuchRSSfeedException;
import com.podengine.service.model.RSSfeed;
import com.podengine.service.service.base.RSSfeedLocalServiceBaseImpl;
import com.podengine.service.service.persistence.RSSfeedUtil;

/**
 * The implementation of the r s sfeed local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.podengine.service.service.RSSfeedLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author shamshuddin
 * @see com.podengine.service.service.base.RSSfeedLocalServiceBaseImpl
 * @see com.podengine.service.service.RSSfeedLocalServiceUtil
 */
public class RSSfeedLocalServiceImpl extends RSSfeedLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.podengine.service.service.RSSfeedLocalServiceUtil} to access the r s sfeed local service.
	 *//*---------------Tahir url check in DB-------------*/
	public RSSfeed findbyRSSfeedURL(String feedURL) throws NoSuchRSSfeedException, SystemException{
		return RSSfeedUtil.findByfeedUrl(feedURL);
	}
	
	public List<RSSfeed> findRSSFeedsByContentType(String contentType) throws SystemException {
		return RSSfeedUtil.findByContentType(contentType);
	}
	
	public RSSfeed findByRSSFeedIdAndStatus(long rssFeedId, long workflowStatus){
		try {
			return rsSfeedPersistence.findByrssfeedIdAndStatus(rssFeedId, workflowStatus);
		} catch (SystemException e) {
			System.out.println("error while getting status "+e.getMessage());
		} catch (NoSuchRSSfeedException e) {
			System.out.println("getting error NoSuchRSSfeedException "+e.getMessage());
		}
		return null;
	}
}