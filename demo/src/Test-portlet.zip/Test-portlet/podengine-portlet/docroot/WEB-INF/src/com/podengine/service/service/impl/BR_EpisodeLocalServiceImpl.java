/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.podengine.service.service.impl;

import java.util.List;

import com.liferay.portal.kernel.exception.SystemException;
import com.podengine.service.model.BR_Episode;
import com.podengine.service.service.base.BR_EpisodeLocalServiceBaseImpl;

/**
 * The implementation of the b r_ episode local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.podengine.service.service.BR_EpisodeLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author shamshuddin
 * @see com.podengine.service.service.base.BR_EpisodeLocalServiceBaseImpl
 * @see com.podengine.service.service.BR_EpisodeLocalServiceUtil
 */
public class BR_EpisodeLocalServiceImpl extends BR_EpisodeLocalServiceBaseImpl {
	
	public BR_Episode findBR_episodeByEpisodeIdAndCategoryId(long episodeId,long categoryId) throws SystemException 
	{
		return br_EpisodePersistence.fetchByepisodeIdAndCategoryId_First(episodeId, categoryId, null);
	}
	
	public List<BR_Episode> findBR_episodeByCategoyId(long categoryId) throws SystemException  
	{
		return br_EpisodePersistence.findByCategoryId(categoryId);
	}
	
	public BR_Episode findBR_episodeByRSSFeedIdAndCategoryId(long rssFeedId,long categoryId) throws SystemException
	{
		return br_EpisodePersistence.fetchByRSSFeedIdAndCategoryIdForEpisode_First(rssFeedId, categoryId, null);
	}
	
	public List<BR_Episode> findByRSSFeedId(long rssFeedId) throws SystemException{
		
		return br_EpisodePersistence.findByRSSFeedId(rssFeedId);
	}
}