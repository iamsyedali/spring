package com.podengine.portal.util;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Blob;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageInputStream;
import javax.imageio.stream.ImageOutputStream;
import javax.portlet.ActionRequest;
import javax.portlet.PortletRequest;
import javax.portlet.RenderRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.validator.UrlValidator;

import player.PlayerControl;
import player.PlayerFactory;

import com.beaglebuddy.id3.pojo.AttachedPicture;
import com.beaglebuddy.mp3.MP3;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.NoSuchWorkflowDefinitionLinkException;
import com.liferay.portal.UserIdException;
import com.liferay.portal.kernel.dao.jdbc.OutputBlob;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.FileUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.liferay.portal.kernel.workflow.WorkflowHandlerRegistryUtil;
import com.liferay.portal.model.Role;
import com.liferay.portal.model.User;
import com.liferay.portal.model.WorkflowDefinitionLink;
import com.liferay.portal.service.RoleLocalServiceUtil;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.portal.service.WorkflowDefinitionLinkLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.asset.model.AssetCategory;
import com.liferay.portlet.asset.model.AssetEntry;
import com.liferay.portlet.asset.model.AssetVocabulary;
import com.liferay.portlet.asset.service.AssetCategoryLocalServiceUtil;
import com.liferay.portlet.asset.service.AssetEntryLocalServiceUtil;
import com.liferay.portlet.asset.service.AssetVocabularyLocalServiceUtil;
import com.liferay.portlet.expando.model.ExpandoColumn;
import com.liferay.portlet.expando.model.ExpandoColumnConstants;
import com.liferay.portlet.expando.model.ExpandoTable;
import com.liferay.portlet.expando.model.ExpandoTableConstants;
import com.liferay.portlet.expando.model.ExpandoValue;
import com.liferay.portlet.expando.service.ExpandoColumnLocalServiceUtil;
import com.liferay.portlet.expando.service.ExpandoTableLocalServiceUtil;
import com.liferay.portlet.expando.service.ExpandoValueLocalServiceUtil;
import com.podengine.portal.rss.model.RSSFeedXML;
import com.podengine.portal.util.constants.AccountsConstants;
import com.podengine.portal.util.constants.CONTENT_TYPE;
import com.podengine.portal.util.constants.ImageConstants;
import com.podengine.service.model.BR_Episode;
import com.podengine.service.model.BR_RSSFeed;
import com.podengine.service.model.MyContent;
import com.podengine.service.model.PlayList;
import com.podengine.service.model.PodJockeyPlayList;
import com.podengine.service.model.Podcast;
import com.podengine.service.model.RSSfeed;
import com.podengine.service.service.BR_EpisodeLocalServiceUtil;
import com.podengine.service.service.BR_RSSFeedLocalServiceUtil;
import com.podengine.service.service.MyContentLocalServiceUtil;
import com.podengine.service.service.PlayListLocalServiceUtil;
import com.podengine.service.service.PodJockeyPlayListLocalServiceUtil;
import com.podengine.service.service.PodcastLocalServiceUtil;
import com.podengine.service.service.RSSfeedLocalServiceUtil;

public class PodEngineUtil {

	private static Log _log = LogFactoryUtil.getLog(PodEngineUtil.class);
	public static ThemeDisplay themeDispaly;
	private static final int IMG_WIDTH = 900;
	private static final int IMG_HEIGHT = 900;

	public static ActionRequest addRSS(ActionRequest actionRequest) {
	 

		String checkbox1 = ParamUtil.getString(actionRequest, "userType");
		String rssUrl = ParamUtil.getString(actionRequest, "rssUrl");
		String crudType = ParamUtil.getString(actionRequest, "crudType");
		long rssfeedId = ParamUtil.getLong(actionRequest, "rssfeedId");

		RSSfeed rssFeed = null;

		if (crudType.equals("add")) {
			_log.info("in Add");

			try {
				rssfeedId = CounterLocalServiceUtil.increment(RSSfeed.class
						.getName());
			} catch (SystemException e) {
				_log.error("-----Error While incrementing counter-----");
			}

			rssFeed = RSSfeedLocalServiceUtil.createRSSfeed(rssfeedId);
			rssFeed.setCompanyId(themeDispaly.getCompanyId());
			rssFeed.setGroupId(themeDispaly.getScopeGroupId());
			rssFeed.setUserId(themeDispaly.getUserId());
			
			if(themeDispaly.getDoAsGroupId()==0){
				rssFeed.setContentType(CONTENT_TYPE.POSTED);
			}
			else{
				rssFeed.setContentType(CONTENT_TYPE.ADMIN_ADDED);
			}
		} else if (crudType.equals("update")) {
			_log.info("rssfeedId before Update : " + rssfeedId);
			try {
				rssFeed = RSSfeedLocalServiceUtil.getRSSfeed(rssfeedId);
				rssFeed.setModifiedDate(PodEngineUtil
						.convertDateToUnixTimeStamp(new Date()));
			} catch (PortalException e) {
				_log.error(e.getMessage());
			} catch (SystemException e) {
				_log.error(e.getMessage());
			}
		}
		rssFeed.setFeedURL(rssUrl);
		try {
			RSSfeedLocalServiceUtil.updateRSSfeed(rssFeed);
			SessionMessages.add(actionRequest, "success");
		} catch (SystemException e) {
			_log.error("Error While Add RSS Feed");
		}
		rssFeed.setFeedURL(rssUrl);
		_log.info("rssfeedId : " + rssfeedId);

		String categoryIds = StringPool.BLANK;
		AssetVocabulary vocab = null;
		try {
			vocab = AssetVocabularyLocalServiceUtil.getGroupVocabulary(
					themeDispaly.getCompanyGroupId(), "Podengine Categories");
			categoryIds = ParamUtil.getString(actionRequest,
					"assetCategoryIds_" + vocab.getVocabularyId());
			String[] cats = StringUtil.split(categoryIds, ",");
			long categs[] = new long[cats.length];
			for (int i = 0; i < cats.length; i++) {
				categs[i] = Long.parseLong(cats[i]);
			}

			AssetEntry assetEntry = AssetEntryLocalServiceUtil.updateEntry(
					themeDispaly.getUserId(), themeDispaly.getScopeGroupId(),
					RSSfeed.class.getName(), rssFeed.getRssfeedId(), categs,
					null);
			assetEntry.setUrl(rssFeed.getFeedURL());
			assetEntry.setVisible(true);
			AssetEntryLocalServiceUtil.updateAssetEntry(assetEntry);

			actionRequest.setAttribute("curCategories", categoryIds);

			List<AssetCategory> categoeies = AssetCategoryLocalServiceUtil
					.getCategories(RSSfeed.class.getName(),
							rssFeed.getRssfeedId());

			if (Validator.isNotNull(categoeies)) {
				for (AssetCategory assetCategory : categoeies) {
					_log.info("Selected Categories ARe : "
							+ assetCategory.getName());
				}
			}
		} catch (PortalException | SystemException e) {
			_log.error(e.getMessage());
		}

		PodcastThreadUtil.start(rssFeed);
		return actionRequest;
	}

	public static void addPodecasts(RSSfeed rssFeed) {
		PodcastThreadUtil.start(rssFeed);
	}

	public static int add(int a, int b) {
		return a + b;
	}

	public static String getRedirectURL(String url) {

		HttpURLConnection con = null;
		try {
			con = (HttpURLConnection) (new URL(url).openConnection());
		} catch (MalformedURLException e) {
			_log.error(e.getMessage());
		} catch (IOException e) {
			_log.error(e.getMessage());
		}
		con.setInstanceFollowRedirects(false);
		try {
			con.connect();
		} catch (IOException e) {
			_log.error(e.getMessage());
		}
		String location = con.getHeaderField("Location");
		if (Validator.isNull(location)) {
			location = url;
		}
		// _log.info("---Redirected URL IS : "+location);
		return location;
	}

	/*
	 * returns String This method converts File to String
	 */
	public static String convertImageToString(File file){

		byte[] buffer = null;
		InputStream inputStream = null;
		
		try{
			inputStream = new FileInputStream(file);
			buffer = new byte[(int) file.length()];
			int bytesRead;
			ByteArrayOutputStream output = new ByteArrayOutputStream();
			while ((bytesRead = inputStream.read(buffer)) != -1) {
				output.write(buffer, 0, bytesRead);
			}
		}
		catch(IOException e ){
			_log.error(e.getMessage());
		}
		finally{
			closeInputStream(inputStream);
		}
		sun.misc.BASE64Encoder encoder = new sun.misc.BASE64Encoder();
		return encoder.encode(buffer);
	}
	public static void closeInputStream(InputStream is) {
	    try {
	        if (is != null) {
	            is.close();
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}

	/*
	 * returns String This method converts Blob to String
	 */
	public static String convertBlobToString(Blob blob) throws SQLException {
		byte[] imgDataR = null;		
		imgDataR = blob.getBytes(1, (int) blob.length());		
		sun.misc.BASE64Encoder encoder = new sun.misc.BASE64Encoder();
		return encoder.encode(imgDataR);
	}

	/*
	 * returns String This method converts Byte Array to String
	 */
	public static String convertByteArrayToString(byte[] byteArray) {
		sun.misc.BASE64Encoder encoder = new sun.misc.BASE64Encoder();
		return encoder.encode(byteArray);
	}

	/*
	 * returns blob This method converts file to blob
	 */
	public static Blob convertfileToBlob(File file) throws FileNotFoundException {
		InputStream inputStream = null;
		
			inputStream = new FileInputStream(file);
		
		OutputBlob blobData = new OutputBlob(inputStream, file.length());
		return blobData;
	}

	/*
	 * returns blob This method converts inputStream to blob
	 */
	public static Blob convertfileToBlob(InputStream inputStream) throws IOException {
		OutputBlob blobData = null;	
			blobData = new OutputBlob(inputStream, inputStream.available());		
		return blobData;
	}

	/*
	 * returns long This method converts Date to long
	 */
	public static Long convertDateToUnixTimeStamp(Date date) {
		return (long) date.getTime() / 1000;
	}

	/*
	 * returns Date This method converts Long to Date
	 */
	public static Date convertUnixTimeStampToDate(Long unixTime) {
		return new Date(unixTime * 1000);
	}

	/*
	 * returns boolean This method validates url
	 */
	@SuppressWarnings("deprecation")
	public static boolean validateURL(String url) {

		if (new UrlValidator().isValid(url)) {
			return true;
		} else {
			return false;
		}
	}

	public static void deleteRSS(long rssFeedId) {
		try {

			AssetEntryLocalServiceUtil.deleteEntry(RSSfeed.class.getName(),
					rssFeedId);
			RSSfeedLocalServiceUtil.deleteRSSfeed(rssFeedId);
			
			
			List<BR_RSSFeed> br_rssFeeds = BR_RSSFeedLocalServiceUtil.findBRByRSSFeedId(rssFeedId);
			for(BR_RSSFeed br_rssFeed:br_rssFeeds){
				BR_RSSFeedLocalServiceUtil.deleteBR_RSSFeed(br_rssFeed);
			}
			List<BR_Episode> br_EpisodeRSSFeeds = BR_EpisodeLocalServiceUtil.findByRSSFeedId(rssFeedId);
			for(BR_Episode br_EpisodeRSSFeed:br_EpisodeRSSFeeds){
				BR_EpisodeLocalServiceUtil.deleteBR_Episode(br_EpisodeRSSFeed);
			}
			
			List<Podcast> podcasts = PodcastLocalServiceUtil
					.findPodcastByRSSFeedId(rssFeedId);
			for (Podcast podcast : podcasts) {
				
				List<PodJockeyPlayList> podJockeyPlayLists = PodJockeyPlayListLocalServiceUtil.findByPodCastId(podcast.getPodcastId());
				for(PodJockeyPlayList PodJockeyPlayList:podJockeyPlayLists){
					PodJockeyPlayListLocalServiceUtil.deletePodJockeyPlayList(PodJockeyPlayList);
				}
				
				List<MyContent> myContents = MyContentLocalServiceUtil.findMyContentByPodcastId(podcast.getPodcastId());
				for (MyContent myContent : myContents) {
					MyContentLocalServiceUtil.deleteMyContent(myContent);
				}
				List<PlayList> podcastPlaylists = PlayListLocalServiceUtil.findPlaylistByPodcastId(podcast.getPodcastId());
				
				for (PlayList playList : podcastPlaylists) {
					PlayListLocalServiceUtil.deletePlayList(playList);
				}
				PodcastLocalServiceUtil.deletePodcast(podcast);
				
			}
		} catch (PortalException | SystemException e) {
			_log.error(e.getMessage());
		}
	}

	/*
	 * returns ThemeDisplay This method returns ThemeDisplay object
	 */
	public static ThemeDisplay getThemeDisplay(RenderRequest renderRequest) {
		themeDispaly = (ThemeDisplay) renderRequest
				.getAttribute(WebKeys.THEME_DISPLAY);
		return themeDispaly;
	}

	public static RSSfeed parseFeedXML(RSSfeed rssfeed, RSSFeedXML rssFeedXML)
			throws IOException {

		try {
			_log.info("RSSFeed URL  : " + rssFeedXML.getFeedURL());
			_log.info("Title : " + rssFeedXML.getTitle()+"Publish Date : " + rssFeedXML.getPubDate());
			_log.info("RSSFeed  Credentials >> UserId : "
					+ rssFeedXML.getOAuthUserName()+", Password : "+rssFeedXML.getOAuthPassword());

			rssfeed = RSSfeedLocalServiceUtil.fetchRSSfeed(rssfeed
					.getRssfeedId());
			rssfeed.setFeedURL(rssFeedXML.getFeedURL().toString());
			rssfeed.setTitle(rssFeedXML.getTitle());
			
			

			try{
				ImageConstants.DESCRIPTION=rssFeedXML.getDescription().split("<");
				   rssfeed.setDescription(ImageConstants.DESCRIPTION[0]);
			}catch(Exception e) {_log.error("Description Exception");}
			
			
			//rssfeed.setDescription(rssFeedXML.getDescription()!=null?rssFeedXML.getDescription().replace(rssFeedXML.getDescription().substring(rssFeedXML.getDescription().indexOf("<"), rssFeedXML.getDescription().lastIndexOf(">")+1), " "):rssFeedXML.getDescription());
			rssfeed.setPublishDate((rssFeedXML.getPubDate() == null) ? 0
					: convertDateToUnixTimeStamp(rssFeedXML.getPubDate()));			
			rssfeed.setUserName(rssFeedXML.getOAuthUserName());
			rssfeed.setPassword(rssFeedXML.getOAuthPassword());
			rssfeed.setKeywords((rssFeedXML.getKeywords() == null) ? null
					: rssFeedXML.getKeywords().toString());
			try{
				rssfeed.setRssFeedImage((convertByteArrayToString(compressImage(rssFeedXML.getImageURL().toString()))));			
				rssfeed.setImageURL( rssFeedXML.getImageURL().toString());
				}catch(Exception e){
					try {					
						rssfeed.setRssFeedImage(PodEngineUtil.convertBlobToString(PodEngineUtil.convertfileToBlob(new URL(themeDispaly.getPathThemeImages()+"/imageNotAvailable.png").openStream())));
						rssfeed.setImageURL(themeDispaly.getPathThemeImages()+"/imageNotAvailable.png");
					} catch (SQLException e1) {
						_log.error("image exception "+e.getMessage());
					}
				}
			RSSfeedLocalServiceUtil.updateRSSfeed(rssfeed);
		} catch (SystemException | MalformedURLException e) {
			_log.error(" Error in parseFeedXML method ");
		}

		return rssfeed;

	}

	/*
	 * returns long This Method Will Get The Duration Of MP3 Files from Its URL
	 */
	/*public static long getMP3DurationFromURL(String mp3URL) {
		MP3 mp3 = null;
		try {
			mp3 = new MP3(new URL(mp3URL));
		} catch (IOException e) {
			_log.error(e.getMessage());
		}
		long bitrate = mp3.getBitrate();
		long duration = ((mp3.getFileSize() / 1024) * 8) / bitrate;
		_log.info("duration: " + duration);
		return duration;
	}*/

	/*
	 * returns File This Method Will Get The AlbumArt Of MP3 Files from Its URL
	 */
	public static File getAlbumArt(String mp3url) throws IOException {

		File file = null;
		try {
			MP3 mp3 = new MP3(new URL(mp3url));
			if (!mp3.getPictures().isEmpty()) {
				List<AttachedPicture> pics = mp3.getPictures();
				for (AttachedPicture attachedPicture : pics) {
					byte[] atpic = attachedPicture.getImage();
					ByteArrayInputStream bis = new ByteArrayInputStream(atpic);
					Iterator<?> readers = ImageIO
							.getImageReadersByFormatName("jpg");
					ImageReader reader = (ImageReader) readers.next();
					Object source = bis;
					ImageInputStream iis = ImageIO
							.createImageInputStream(source);
					reader.setInput(iis, true);
					ImageReadParam param = reader.getDefaultReadParam();
					Image image = reader.read(0, param);
					BufferedImage bufferedImage = new BufferedImage(
							image.getWidth(null), image.getHeight(null),
							BufferedImage.TYPE_INT_RGB);
					Graphics2D g2 = bufferedImage.createGraphics();
					g2.drawImage(image, null, null);
					ByteArrayOutputStream baos = new ByteArrayOutputStream();
					ImageIO.write(bufferedImage, "jpg", baos);
					baos.flush();
					byte[] bytes = baos.toByteArray();
					file = FileUtil.createTempFile(bytes);
					baos.close();
				}
			} else {
				_log.info("No Album Art Present in the MP3 File");
			}
		} catch (IOException ex) {
			_log.error(ex.getMessage());
		}
		return file;
	}

	/*
	 * returns byte[] array This Method Will Get The Compressed Image from Its
	 * URL
	 */
	public static byte[] compressImage(String imageURL) throws IOException {
			URL url = new URL(imageURL);
			BufferedImage originalImage = ImageIO.read(url.openStream());
			int type = originalImage.getType() == 0? BufferedImage.TYPE_INT_ARGB : originalImage.getType();
			BufferedImage buffi = resizeImage(originalImage, type);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ImageOutputStream ios = ImageIO.createImageOutputStream(baos);
			Iterator<ImageWriter> writers = ImageIO
					.getImageWritersByFormatName("jpg");
			ImageWriter writer = writers.next();
			ImageWriteParam param = writer.getDefaultWriteParam();
			param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
			param.setCompressionQuality(0.05f);
			writer.setOutput(ios);
			writer.write(null, new IIOImage(buffi, null, null), param);
			byte[] data = baos.toByteArray();
			writer.dispose();
			return data;
	}

	 private static BufferedImage resizeImage(BufferedImage originalImage, int type){
			BufferedImage resizedImage = new BufferedImage(IMG_WIDTH, IMG_HEIGHT, type);
			Graphics2D g = resizedImage.createGraphics();
			g.drawImage(originalImage, 0, 0, IMG_WIDTH, IMG_HEIGHT, null);
			g.dispose();
			return resizedImage;
		    }
	
	
	public static String getVideoDuration(File file) {

		PlayerControl playerControl = PlayerFactory
				.createLightweightMPEG4Player();
		try {
			playerControl.open(file.toString());
		} catch (IllegalStateException e) {
			_log.info("IllegalStateException : " + e.getMessage());
		} catch (IOException e) {
			_log.info("IOException  : " + e.getMessage());
		}
		int sec = (int) ((playerControl.getDuration() / 1000) % 60);
		int min = (int) ((playerControl.getDuration() / 1000) / 60);
		_log.info("Duration is = " + min + ":" + sec);
		return min + ":" + sec;
	}

	public static String getDuration(double seconds) {
		int sec = (int) (seconds % 60);
		int min = (int) (seconds / 60);

		return null;

	}

	/**
	 * @param user
	 * @param request
	 * @param customFieldName
	 * @return
	 */
	public static String getUserRoleCustomFieldValue(User user,
			PortletRequest request, String customFieldName) {
		long companyId = PortalUtil.getCompanyId(request);

		_log.info("getUserRoleCustomFieldValue :ENTER");
		String customFieldValue = "No";
		String[] podRoles = getPodEngineRoles();
		try {
			List<Role> userRoles = RoleLocalServiceUtil.getUserRoles(user
					.getUserId());

			for (String podRole : podRoles) {
				Role role = RoleLocalServiceUtil.getRole(companyId, podRole);
				if (userRoles.contains(role)) {
					ExpandoValue expandoValue = ExpandoValueLocalServiceUtil
							.getValue(companyId, Role.class.getName(),
									AccountsConstants.CUSTOM_FIELD_TABLE_NAME,
									customFieldName, role.getRoleId());
					return expandoValue.getData();
				}
			}
		} catch (SystemException systemException) {
			_log.error("SystemException occured :"
					+ systemException.getMessage());
		} catch (PortalException portalException) {
			_log.error("PortalException occured :"
					+ portalException.getMessage());
		}

		_log.info("getUserRoleCustomFieldValue :EXIT");
		return customFieldValue;
	}

	/**
	 * This method return PodEngine Roles As String Array
	 * 
	 * @return String[]
	 */
	public static String[] getPodEngineRoles() {
		String podEngineRoles = PropsUtil
				.get(AccountsConstants.PODENGINE_ROLES);
		return podEngineRoles.split(StringPool.COMMA);
	}

	public static boolean isPodJockeyAllowed(PortletRequest request) {
		boolean beAPodjockey = false;
		String bePodJockeyValue = null;
		User user = getUser(request);
		bePodJockeyValue = getUserRoleCustomFieldValue(user, request,
				AccountsConstants.BE_A_PODJOCKEY);
		if (bePodJockeyValue.equalsIgnoreCase("Yes")) {
			beAPodjockey = true;
		}

		return beAPodjockey;
	}

	public static User getUser(PortletRequest request) {
		User user = null;
		try {
			user = PortalUtil.getUser(request);
		} catch (PortalException | SystemException e) {
			_log.error("Exception ocuured while fetching user object :"
					+ e.getMessage());
		}

		return user;
	}

	/**
	 * This method returns the current Role or Account Type of the user
	 * 
	 * @param portletRequest
	 * @return Role
	 */
	public static Role getPodUserRole(PortletRequest request) {

		String[] podEngineRoles = getPodEngineRoles();
		User user = getUser(request);
		Role userRole = null;

		try {
			HttpSession session = PortalUtil.getHttpServletRequest(request).getSession();
			
			Object userAccountTypeId = session.getAttribute(AccountsConstants.PODENGINE_ACCOUNTTYPE_ID);
			
			if(Validator.isNotNull(userAccountTypeId)){
				String roleId = (String)userAccountTypeId;
				userRole = RoleLocalServiceUtil.getRole(Long.parseLong(roleId));
			} else {
				List<Role> podUserRoles = RoleLocalServiceUtil.getUserRoles(user.getUserId());
	
				for (String podEngineRole : podEngineRoles) {
					userRole = RoleLocalServiceUtil.getRole(
							PortalUtil.getCompanyId(request), podEngineRole);
					if (podUserRoles.contains(userRole)) {
						session.setAttribute(AccountsConstants.PODENGINE_ACCOUNTTYPE_ID, String.valueOf(userRole.getRoleId()));
						return userRole;
					}
				}
				userRole = RoleLocalServiceUtil.getRole(PortalUtil.getCompanyId(request),AccountsConstants.FREE_ACCOUNT);
			}

		} catch (SystemException systemException) {
			_log.error("SystemException occured while accessing User roles "
					+ systemException.getMessage());
		} catch (PortalException portalException) {
			_log.error("PortalException occured while accessing User roles "
					+ portalException.getMessage());
		}

		return userRole;
	}
	/*
* 	Return type String
* 	Method Converts Seconds to time format HH:MM:SS
*/
	public static String timeConversion(long totalSeconds) {
		if(totalSeconds>0){
	    final int MINUTES_IN_AN_HOUR = 60;
	    final int SECONDS_IN_A_MINUTE = 60;
	    long seconds = totalSeconds % SECONDS_IN_A_MINUTE;
	    long totalMinutes = totalSeconds / SECONDS_IN_A_MINUTE;
	    long minutes = totalMinutes % MINUTES_IN_AN_HOUR;
	    long hours = totalMinutes / MINUTES_IN_AN_HOUR;
	    String hrStr;
	    if(hours != 0){
			  hrStr = (hours<10 ? "0" : "")+hours;
			  return hrStr + ":" + minutes + ":" + seconds ;
		  }
	    else{
			  return  minutes + ":" + seconds ;
		  }
		}else{
			return "No Duration";
		}
	    
	}
	/*
	 * returns long 
	 * s Method to Get The Duration Of any Media Files from Media file URL
	 */
	public static long getMediaDurationFromURL(String url) {
		if(url.contains(".mp3")){
		MP3 mp3 = null;
		try {
			mp3 = new MP3(new URL(url));
		} catch (IOException e) {
			_log.error(e.getMessage());
			return 0;
		}
		long bitrate = mp3.getBitrate();
		long duration = ((mp3.getFileSize() / 1024) * 8) / bitrate;
		return duration;
		}
		else{
			return 0;
		}
	}
	public static int getDurationValue(String durationString) {
		int hour = 0,min = 0,sec=0,value=0;
		if(durationString != null){
		String dur[]=durationString.split(":");
		if(dur.length == 3){
		 hour=Integer.parseInt(dur[0]);
		 min=Integer.parseInt(dur[1]);
		 sec=Integer.parseInt(dur[2]);
		 value=(hour*3600)+(min*60)+(sec);
		}
		if(dur.length == 2){
			 min=Integer.parseInt(dur[0]);
			 sec=Integer.parseInt(dur[1]);
			 value=(min*60)+(sec);
		}
		if(!durationString.contains(":")){
			 value= Integer.parseInt(durationString);
		}
		} 
		 return value;
	}
	public static ActionRequest addRSSForPost(ActionRequest actionRequest) {

		String checkbox1 = ParamUtil.getString(actionRequest, "userType");
		String rssUrl = ParamUtil.getString(actionRequest, "rssUrl");
		long rssfeedId = ParamUtil.getLong(actionRequest, "rssfeedId");
        _log.info("rssUrl"+rssUrl);   
        ServiceContext serviceContext = null;
		RSSfeed rssFeed = null;

		
			_log.info("in Add");

			try {
				rssfeedId = CounterLocalServiceUtil.increment(RSSfeed.class
						.getName());
			} catch (SystemException e) {
				_log.error("-----Error While incrementing counter-----");
			}

			rssFeed = RSSfeedLocalServiceUtil.createRSSfeed(rssfeedId);
			rssFeed.setCompanyId(themeDispaly.getCompanyId());
			rssFeed.setGroupId(themeDispaly.getScopeGroupId());
			rssFeed.setFeedURL(rssUrl);
			rssFeed.setWorkflowStatus(WorkflowConstants.STATUS_DRAFT);;
			rssFeed.setUserId(themeDispaly.getUserId());
			
			WorkflowDefinitionLink workflowDefinitionLink = null;
		try {
			RSSfeedLocalServiceUtil.updateRSSfeed(rssFeed);
			
			workflowDefinitionLink = WorkflowDefinitionLinkLocalServiceUtil.getDefaultWorkflowDefinitionLink(themeDispaly.getCompanyId(), 
					RSSfeed.class.getName(), 0, 0);
			serviceContext = ServiceContextFactory.getInstance(actionRequest);
			
			SessionMessages.add(actionRequest, "success");
		} catch (SystemException e) {
			_log.error("Error While Add RSS Feed");
		} catch (PortalException e) {
			_log.error("PortalException While Addin Rss in Post");
				if(e instanceof NoSuchWorkflowDefinitionLinkException){
				SessionMessages.add(actionRequest.getPortletSession(),"workflow-not-enabled");
				}
		}
		rssFeed.setFeedURL(rssUrl);
		_log.info("rssfeedId : " + rssfeedId);

		String categoryIds = StringPool.BLANK;
		AssetVocabulary vocab = null;
		try {
			vocab = AssetVocabularyLocalServiceUtil.getGroupVocabulary(
					themeDispaly.getCompanyGroupId(), "Podengine Categories");
			categoryIds = ParamUtil.getString(actionRequest,
					"assetCategoryIds_" + vocab.getVocabularyId());
			String[] cats = StringUtil.split(categoryIds, ",");
			long categs[] = new long[cats.length];
			for (int i = 0; i < cats.length; i++) {
				categs[i] = Long.parseLong(cats[i]);
			}
			
			if(rssFeed != null && workflowDefinitionLink != null){
				_log.info("rssFeed and workflowDefinitionLink not null go inside if");
				

			AssetEntry assetEntry = AssetEntryLocalServiceUtil.updateEntry(
					themeDispaly.getUserId(), themeDispaly.getScopeGroupId(),
					RSSfeed.class.getName(), rssFeed.getRssfeedId(), categs,
					null);
			assetEntry.setUrl(rssFeed.getFeedURL());
			assetEntry.setVisible(true);
			AssetEntryLocalServiceUtil.updateAssetEntry(assetEntry);

			serviceContext.getAssetCategoryIds();
			serviceContext.getAssetTagNames();
			WorkflowHandlerRegistryUtil.startWorkflowInstance(rssFeed.getCompanyId(), rssFeed.getGroupId(), themeDispaly.getUserId(),
					RSSfeed.class.getName(), rssFeed.getPrimaryKey(), rssFeed, serviceContext);
			
			}
			
	
			actionRequest.setAttribute("curCategories", categoryIds);

			List<AssetCategory> categoeies = AssetCategoryLocalServiceUtil
					.getCategories(RSSfeed.class.getName(),
							rssFeed.getRssfeedId());

			if (Validator.isNotNull(categoeies)) {
				for (AssetCategory assetCategory : categoeies) {
					_log.info("Selected Categories ARe : "
							+ assetCategory.getName());
				}
			}
		} catch (PortalException | SystemException e) {
			_log.error(e.getMessage());
		}

		addPodecasts(rssFeed);
		return actionRequest;
	}
	
	/**
	 * This method is used to get the subscription period of the account user selected.
	 * 
	 * @param request
	 * @return subscription period as String
	 * @throws PortalException
	 * @throws SystemException
	 */
	public static String getSubscriptionType(PortletRequest request) throws PortalException, SystemException{
		
		String subscriptionType = StringPool.BLANK;
		User user = PortalUtil.getUser(request);
		ExpandoValue columnValue = ExpandoValueLocalServiceUtil.getValue(PortalUtil.getCompanyId(request), User.class.getName(), 
				 ExpandoTableConstants.DEFAULT_TABLE_NAME, "subscriptionType", user.getUserId());
		//Object obj = user.getExpandoBridge().getAttribute("subscriptionType");
		if(Validator.isNotNull(columnValue)){
			subscriptionType = columnValue.getData();
		}
		_log.info("currentSubscriptionType :" + subscriptionType);
		return subscriptionType;
	}
	
	/**
	 * This method is used to update the user account current subscription period i.e. monthly,quarterly etc.
	 * 
	 * @param request
	 * @param subscriptionType
	 * @throws PortalException
	 * @throws SystemException
	 */
	public static void updateSubscriptionType(PortletRequest request,String subscriptionType) throws PortalException, SystemException{
		
		User user = PortalUtil.getUser(request);
		ExpandoColumn expandoColumn = ExpandoColumnLocalServiceUtil.getColumn(PortalUtil.getCompanyId(request), User.class.getName(),
				ExpandoTableConstants.DEFAULT_TABLE_NAME, "subscriptionType");
		if(Validator.isNull(expandoColumn)){
			_log.info("updateSubscriptionType expandoColumn is null");
			ExpandoTable expandoTable = ExpandoTableLocalServiceUtil.getDefaultTable(PortalUtil.getCompanyId(request), User.class.getName());
			expandoColumn = ExpandoColumnLocalServiceUtil.addColumn(expandoTable.getTableId(), "subscriptionType",ExpandoColumnConstants.STRING);
		}
		_log.info("updateSubscriptionType expandoColumn is null");
		ExpandoValue columnValue = ExpandoValueLocalServiceUtil.addValue(PortalUtil.getCompanyId(request), User.class.getName(), 
				 ExpandoTableConstants.DEFAULT_TABLE_NAME, expandoColumn.getName(), user.getUserId(), subscriptionType);
		_log.info("updatesubscriptionType :" + columnValue.getData());
	}
	
	/**
	 * This method returns the user current account validity.
	 * 
	 * @param request
	 * @return account validity date as String
	 * @throws PortalException
	 * @throws SystemException
	 */
	public static String getAccountValidity(PortletRequest request) throws PortalException, SystemException{
		
		String accountValidity = StringPool.BLANK;
		User user = PortalUtil.getUser(request);
		ExpandoValue columnValue = ExpandoValueLocalServiceUtil.getValue(PortalUtil.getCompanyId(request), User.class.getName(), 
				 ExpandoTableConstants.DEFAULT_TABLE_NAME, "accountValidity", user.getUserId());
		//Object obj =user.getExpandoBridge().getAttribute("accountValidity");
		if(Validator.isNotNull(columnValue)){
			accountValidity = columnValue.getData();
		}
		_log.info("accountValidity :" + accountValidity);
		return accountValidity;
	}
	
	/**
	 * This method update the account validity based on the subscription period (Monthly, quartly etc..) user selected.
	 * Value is kept in expando table
	 * 
	 * @param request
	 * @param subscriptionType
	 * @throws PortalException
	 * @throws SystemException
	 */
	public static void updateAccountValidity(PortletRequest request, String subscriptionType) throws PortalException, SystemException{
		
		User user = PortalUtil.getUser(request);
		String accountValidity = getAccountValidityDate(subscriptionType);
		ExpandoColumn expandoColumn = ExpandoColumnLocalServiceUtil.getColumn(PortalUtil.getCompanyId(request), User.class.getName(),
					ExpandoTableConstants.DEFAULT_TABLE_NAME, "accountValidity");
		if(Validator.isNull(expandoColumn)){
			ExpandoTable expandoTable = ExpandoTableLocalServiceUtil.getDefaultTable(PortalUtil.getCompanyId(request), User.class.getName());
			expandoColumn = ExpandoColumnLocalServiceUtil.addColumn(expandoTable.getTableId(), "accountValidity",ExpandoColumnConstants.STRING);
		}
		ExpandoValue columnValue = ExpandoValueLocalServiceUtil.addValue(PortalUtil.getCompanyId(request), User.class.getName(), 
				 ExpandoTableConstants.DEFAULT_TABLE_NAME, expandoColumn.getName(), user.getUserId(), accountValidity);
		
		_log.info("update accountValidity :" + columnValue.getData());
	}
	
	/**
	 * This method returns user current account selection e.g. Free Account, Pro Account , Value Account etc.
	 * 
	 * @param request
	 * @return user current account as String
	 * @throws PortalException
	 * @throws SystemException
	 */
	public static String getAccounyType(PortletRequest request) throws PortalException, SystemException{
		
		String accountType = StringPool.BLANK;
		User user = PortalUtil.getUser(request);
		ExpandoValue columnValue = ExpandoValueLocalServiceUtil.getValue(PortalUtil.getCompanyId(request), User.class.getName(), 
				 ExpandoTableConstants.DEFAULT_TABLE_NAME, "accountType", user.getUserId());
		//Object obj =user.getExpandoBridge().getAttribute("accountType");
		
		if(Validator.isNotNull(columnValue)){
			accountType = columnValue.getData();
		}
		_log.info("currentRole :" + accountType);
		return accountType;
	}
	
	
	
	/**
	 * This method update user current account type selection i.e. Pro Account, Value Account. The value is kept in expando table
	 * 
	 * @param request
	 * @param accountType
	 * @throws PortalException
	 * @throws SystemException
	 */
	public static void updateAccountType(PortletRequest request, String accountType) throws PortalException, SystemException{
		
		User user = PortalUtil.getUser(request);
		ExpandoColumn expandoColumn = ExpandoColumnLocalServiceUtil.getColumn(PortalUtil.getCompanyId(request), User.class.getName(),
				ExpandoTableConstants.DEFAULT_TABLE_NAME, "accountType");
		if(Validator.isNull(expandoColumn)){
			ExpandoTable expandoTable = ExpandoTableLocalServiceUtil.getDefaultTable(PortalUtil.getCompanyId(request), User.class.getName());
			expandoColumn = ExpandoColumnLocalServiceUtil.addColumn(expandoTable.getTableId(), "accountType",ExpandoColumnConstants.STRING);
		}
		
		ExpandoValue columnValue = ExpandoValueLocalServiceUtil.addValue(PortalUtil.getCompanyId(request), User.class.getName(), 
				 ExpandoTableConstants.DEFAULT_TABLE_NAME, expandoColumn.getName(), user.getUserId(), accountType);
		_log.info("currentRole :" + columnValue.getData());
	}
	
	/**
	 * This method is used to create the validity date of the account
	 * 
	 * @param subscriptionType
	 * @return date as String in formatted form eg. 19th Mar 2005
	 */
	private static String getAccountValidityDate(String subscriptionType){
		
		String validityDate = null;
		Calendar calendar = Calendar.getInstance();
		DateFormat dateFormat = new SimpleDateFormat("dd'th' MMM yyyy");
		validityDate = subscriptionValidity(subscriptionType,
				calendar, dateFormat);
		_log.info("validityDate :" + validityDate);
		return validityDate;
	}
	
	/**
	 * This method returns the user selected subscription amount based on the account and period user selected.
	 * 
	 * @param companyId
	 * @param subscriptionPeriod
	 * @param roleId
	 * @return subscriptionAmount as String
	 * @throws NumberFormatException
	 * @throws PortalException
	 * @throws SystemException
	 */
	public static String getSubscriptionAmount(long companyId,String subscriptionPeriod, String roleId) throws NumberFormatException, PortalException, SystemException{
		Role selectedRole = RoleLocalServiceUtil.getRole(Long.parseLong(roleId));
		String subscriptionAmount = (String) ExpandoValueLocalServiceUtil.getData(companyId, Role.class.getName(), ExpandoTableConstants.DEFAULT_TABLE_NAME, subscriptionPeriod, selectedRole.getRoleId());
		return subscriptionAmount;
		
	}
	
	/**
	 * This method update the account validity based on the subscription period (Monthly, quartly etc..) user selected.
	 * Value is kept in expando table
	 * 
	 * @param request
	 * @param subscriptionType
	 * @throws PortalException
	 * @throws SystemException
	 */
	public static void extendValidity(PortletRequest request, String subscriptionType) throws PortalException, SystemException{
		
		User user = PortalUtil.getUser(request);
		long companyId = PortalUtil.getCompanyId(request);
		String currentValidity = (String) ExpandoValueLocalServiceUtil.getData(companyId, User.class.getName(), ExpandoTableConstants.DEFAULT_TABLE_NAME, "accountValidity", user.getUserId());
		
		_log.info("currentValidity :" + currentValidity);
		
		String accountValidity = getValidityDate(currentValidity,subscriptionType);
		ExpandoColumn expandoColumn = ExpandoColumnLocalServiceUtil.getColumn(companyId, User.class.getName(),
					ExpandoTableConstants.DEFAULT_TABLE_NAME, "accountValidity");
		if(Validator.isNull(expandoColumn)){
			ExpandoTable expandoTable = ExpandoTableLocalServiceUtil.getDefaultTable(companyId, User.class.getName());
			expandoColumn = ExpandoColumnLocalServiceUtil.addColumn(expandoTable.getTableId(), "accountValidity",ExpandoColumnConstants.STRING);
		}
		ExpandoValue columnValue = ExpandoValueLocalServiceUtil.addValue(companyId, User.class.getName(), 
				 ExpandoTableConstants.DEFAULT_TABLE_NAME, expandoColumn.getName(), user.getUserId(), accountValidity);
		
		_log.info("update accountValidity :" + columnValue.getData());
	}
	
	private static String getValidityDate(String currentValidity,String subscriptionType){
		
		String validityDate = null;
		Calendar calendar = Calendar.getInstance();
		DateFormat dateFormat = new SimpleDateFormat("dd'th' MMM yyyy");
		Date currValidity = null;
		try {
			_log.info("currentValidity :" + currentValidity);
			if(Validator.isNotNull(currentValidity)){
					currValidity = dateFormat.parse(currentValidity);
					calendar.setTime(currValidity);
			}
				
			validityDate = subscriptionValidity(subscriptionType,calendar, dateFormat);
			_log.info("validityDate :" + validityDate);
		} catch (ParseException e) {
			_log.error("invalid current date " + e.getMessage());
		}
		return validityDate;
	}

	private static String subscriptionValidity(String subscriptionType,
			Calendar calendar, DateFormat dateFormat) {
		
		String validityDate = null;
		if(subscriptionType.equalsIgnoreCase("Monthly")){
				
			calendar.add(Calendar.DAY_OF_YEAR, 30);
			validityDate = dateFormat.format(calendar.getTime());
				
		} else if(subscriptionType.equalsIgnoreCase("Quarterly")){
				
			calendar.add(Calendar.DAY_OF_YEAR, 90);
			validityDate = dateFormat.format(calendar.getTime());
				
		} else if(subscriptionType.equalsIgnoreCase("Half Yearly")){
				
			calendar.add(Calendar.DAY_OF_YEAR, 180);
			validityDate = dateFormat.format(calendar.getTime());
				
		} else if(subscriptionType.equalsIgnoreCase("Yearly")){
				
			calendar.add(Calendar.DAY_OF_YEAR, 365);
			validityDate = dateFormat.format(calendar.getTime());
				
		}
		return validityDate;
	}

}
