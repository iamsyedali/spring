package com.podengine.portal.util.constants;
/**
 * @author Syed Ali
 */
public class ResourceKeys {
	public static final String CHECK = "check";
	public static final String UNCHECK = "unchecked";
	public static final String MYCONTENT_ADDEPISODE="addToPlaylist";
	public static final String BR_RSS_FEED_CHECK="br-rss-feed-check";
	public static final String BR_RSS_FEED_UNCHECK="br-rss-feed-uncheck";
	public static final String BR_EPISODE_CHECK="br-episode-check";
	public static final String BR_EPISODE_UNCHECK="br-episode-uncheck";
	public static final String BR_EPISODE_SORTING="br-episode-sorting";
	public static final String BR_RSSFEED_SORTING="br-rssFeed-sorting";	
	public static final String BR_GLOBAL_CHECKED_RSS="br-globalBrilliantCheckedRSS";
	public static final String BR_GLOBAL_UNCHECKED_RSS="br-globalBrilliantUnCheckedRSS";	
	public static final String User_Play_List="userPlayList";
	public static final String VALIDATE_RSS_FEED_URL="validate-rssfeed-url";
	public static final String PLAYLIST_SORTABLE="playlistsortable";                      //Play_list controller
	public static final String UPDATE_PLAYERTIMESTAMP="updatePlayerTimeStamp";            //Player controller
	public static final String PLAYER_TIMESTAMP="playerTimeStamp";                        //Player controller
	 
	public static final String GENERATE_CODE="generateCode";
	public static final String CHECK_PLAYLIST="checkPodJockeyPlayList";
	public static final String UNCHECK_PLAYLIST="UnCheckPodJockeyPlayList";
	
}
