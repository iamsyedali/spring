package com.podengine.portal.util.constants;

/**
 * @author Syed Ali
 */

public class PortletKeys extends com.liferay.portal.util.PortletKeys{
	
	public static final String PLAYER = "player_WAR_podengineportlet";
	
	public static final String FIND_CONTENT = "findcontent_WAR_podengineportlet";
	
	public static final String PLAYLIST = "playlist_WAR_podengineportlet";
	
	public static final String PODJOCKEY = "podjockey_WAR_podengineportlet";
	
	public static final String HOST_AND_POST = "hostandpost_WAR_podengineportlet";
	
	public static final String NAVIGATOR = "navigator_WAR_podengineportlet";
	
	public static final String ADDS = "adds_WAR_podengineportlet";
}
