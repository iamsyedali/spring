package com.podengine.portal.util.constants;

/**
 * @author Syed Ali
 */
public class DateTimeFormates {
	
	public static final String DD_MM_YY = "dd-mm-yy";

}
