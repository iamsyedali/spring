package com.podengine.portal.util.constants;
/**
 * @author Syed Ali
 */
public class POPUP_SIZE {
	
	public static final String PODJOCKEY_POPUP_WIDTH_PX = "800";
	
	public static final String PODJOCKEY_POPUP_HEIGHT_PIXEL = "500";
	
	public static final String FINDCONTENT_POPUP_WIDTH_PIXEL = "800";
	
	public static final String FINDCONTENT_POPUP_HEIGHT_PIXEL = "500";

}
