package com.podengine.portal.util.constants;

public class POPUP_ID {

	public static final String DELETE_PODJOCKEY = "delete_popUp";
	
	public static final String ADD_RSS = "add-edit-popup";
	
	public static final String DELETE_RSS = "delete_popUp";
	
	public static final String FIND_CONTENT = "rssFeed_ID";
	
	public static final String HOST_CONTENT = "host-popup";
	
	public static final String ACCESS_CODE = "accessCode-popup";
	
	public static final String MANAGE_PODJOCKEY = "manage-popup";
	
	public static final String BE_PODJOCKEY_POPUP = "bePodJockey-popup";
	
	public static final String SHOW_ACCESS_CODE_POPUP = "showAccessCode_popUp";
	
	public static final String DELETE_PODJOCKEY_POPUP = "delete_popUp";
	
	public static final String VIEW_SELECTED_PLAYLIST_POPUP = "delete_popUp";
	
}
