package com.podengine.portal.util.constants;
/**
 * @author Syed Ali
 */
public class PortletMode {
	public static final String VIEW = "VIEW";
	public static final String EDIT = "EDIT";
	public static final String HELP = "HELP";
}
