package com.podengine.portlet.admin;

import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.portlet.bind.annotation.ActionMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;
import org.springframework.web.portlet.bind.annotation.ResourceMapping;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.ListUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.util.PortalUtil;
import com.podengine.portal.util.constants.CMD;
import com.podengine.portal.util.constants.PortletMode;
import com.podengine.portal.util.constants.ResourceKeys;
import com.podengine.service.NoSuchBR_EpisodeException;
import com.podengine.service.model.BR_Episode;
import com.podengine.service.model.BR_RSSFeed;
import com.podengine.service.service.BR_EpisodeLocalServiceUtil;
import com.podengine.service.service.BR_RSSFeedLocalServiceUtil;

@Controller
@RequestMapping({PortletMode.VIEW})
public class BrilliantRecommendationsController {
	
	private static Log _log = LogFactoryUtil.getLog(BrilliantRecommendationsController.class);
	private static final String VIEW_JSP = "view";
	private static final String RSS_FEED_DESC_POPUP_JSP = "rss-feed-description-popup";
	private static final String EPISODE_POPUP_JSP = "episode-popup";
	
	@RenderMapping
	public String defaultRender(RenderRequest renderRequest,
			RenderResponse renderResponse) {
		_log.info("Default Render.....");
	    renderRequest.setAttribute("tabs1", "RSS Feeds");
		return VIEW_JSP;
	}
	
	@ActionMapping
	public void defaultAction(ActionRequest request,
			ActionResponse actionResponse) {
		_log.info("Default Action.....");
	}
	
	
	@RenderMapping(params = "action=rssFeed")
	public String rssfeedcontent(RenderRequest renderRequest,
			RenderResponse renderResponse) throws SystemException{
		String rssfeedId=ParamUtil.getString(renderRequest, "rssfeedId");
		String podCastId=ParamUtil.getString(renderRequest, "podCastId");
		String categoryId=ParamUtil.getString(renderRequest, "categoryId");
		renderRequest.setAttribute("podCastId", podCastId);
		renderRequest.setAttribute("rssfeedId", rssfeedId);
		renderRequest.setAttribute("categoryId", categoryId);
		
		return RSS_FEED_DESC_POPUP_JSP;
	}
	
	@RenderMapping(params = "action=episodes")
	public String episodescontent(RenderRequest renderRequest,
			RenderResponse renderResponse){
		String rssfeedId=ParamUtil.getString(renderRequest, "rssfeedId");
		String categoryId=ParamUtil.getString(renderRequest, "categoryId");
		renderRequest.setAttribute("rssfeedId", rssfeedId);
		renderRequest.setAttribute("categoryId", categoryId);
		return EPISODE_POPUP_JSP;
	
	}
	
	
	@ResourceMapping(value = ResourceKeys.BR_RSS_FEED_CHECK)
	public void rssFeedChecked(ResourceRequest resourceRequest,
			ResourceResponse resourceResponse) {
		_log.info("calling rssFeedChecked resource method");
		String rssFeed_category_Id = ParamUtil.getString(resourceRequest, "rssFeed_category_Id");
		long rssFeedId = 0;
		long categoryId = 0;
		String ids[] = rssFeed_category_Id.split(StringPool.COMMA);
		 for (int i = 0; i < ids.length; i++) {
			rssFeedId = Long.parseLong(ids[0]);
			categoryId = Long.parseLong(ids[1]);
		}
		 _log.info("rssFeedId -------"+rssFeedId +" categoryId------"+categoryId);
		BR_RSSFeed br_rssFeed = null;
		try {
			BR_RSSFeed availableBR = (BR_RSSFeed)BR_RSSFeedLocalServiceUtil.findBRByRSSFeedIdAndCategoryId(rssFeedId, categoryId);
			if(Validator.isNull(availableBR)){
				_log.info("Adding New BR....");
				br_rssFeed = BR_RSSFeedLocalServiceUtil.createBR_RSSFeed(CounterLocalServiceUtil.increment(BR_RSSFeed.class.getName()));
				br_rssFeed.setCategoryId(categoryId);
				br_rssFeed.setRssFeedId(rssFeedId);
				br_rssFeed.setUserId(PortalUtil.getUserId(resourceRequest));
				long maxPriority = 0;
				
				List<BR_RSSFeed> brilliantRSSFeeds = BR_RSSFeedLocalServiceUtil.findBR_RSSFeedByCategoyId(categoryId);
				_log.info("brilliantRSSFeeds Size : "+brilliantRSSFeeds.size());
				if(brilliantRSSFeeds.size()==0){
					br_rssFeed.setPriority(1);
				}
				else
				{
					for(BR_RSSFeed brilliantRSSFeed: brilliantRSSFeeds){
						if(brilliantRSSFeed.getPriority()>maxPriority){
							maxPriority = brilliantRSSFeed.getPriority();
						}
						br_rssFeed.setPriority(maxPriority+1);
					}
				}
				_log.info("Adding Now...");
				BR_RSSFeedLocalServiceUtil.updateBR_RSSFeed(br_rssFeed);
			}
			else
			{
				_log.info("BR Already Added!!!");
			}
		
		} catch (SystemException e) {
			_log.info("SystemException is getting "+e.getMessage());
		}
		
	}
	
	@ResourceMapping(value = ResourceKeys.BR_RSS_FEED_UNCHECK)
	public void rssFeedUnChecked(ResourceRequest resourceRequest,
			ResourceResponse resourceResponse) {
		_log.info("....rssFeedUNChecked resource method");
		String rssFeed_category_Id = ParamUtil.getString(resourceRequest, "rssFeed_category_Id");
		long rssFeedId = 0;
		long categoryId = 0;
		String ids[] = rssFeed_category_Id.split(StringPool.COMMA);
		 for (int i = 0; i < ids.length; i++) {
			rssFeedId = Long.parseLong(ids[0]);
			categoryId = Long.parseLong(ids[1]);
		}
		 _log.info("rssFeedId -------"+rssFeedId +" categoryId------"+categoryId);
		 try {
			 BR_RSSFeed availableBR = (BR_RSSFeed)BR_RSSFeedLocalServiceUtil.findBRByRSSFeedIdAndCategoryId(rssFeedId, categoryId);
			
			_log.info("BR Priority : "+availableBR.getPriority());
			
			List<BR_RSSFeed> allBRRSSFeeds = BR_RSSFeedLocalServiceUtil.findBR_RSSFeedByCategoyId(categoryId);
			
			for (BR_RSSFeed br_rssFeed : allBRRSSFeeds) {
				_log.info("PRIO : "+br_rssFeed.getPriority()+", CategoryId : "+br_rssFeed.getCategoryId());
			}
			
			_log.info("Index Of Deleted : "+allBRRSSFeeds.indexOf(availableBR));
			List<BR_RSSFeed> modifiableBRRSSFeedList = ListUtil.subList(allBRRSSFeeds,
					allBRRSSFeeds.indexOf(availableBR), allBRRSSFeeds.size());
			for (BR_RSSFeed br_rssFeed : modifiableBRRSSFeedList) {
				_log.info("categoryId : "+br_rssFeed.getCategoryId()+", Priority : "+br_rssFeed.getPriority());
				br_rssFeed.setPriority(br_rssFeed.getPriority()-1);
				BR_RSSFeedLocalServiceUtil.updateBR_RSSFeed(br_rssFeed);
			}
			BR_RSSFeedLocalServiceUtil.deleteBR_RSSFeed(availableBR);
		} catch (SystemException e) {
			_log.info("SystemException is getting "+e.getMessage());
		}
		
	}
	
	
	
	@ResourceMapping(value = ResourceKeys.BR_EPISODE_CHECK)
	public void episodeFeedChecked(ResourceRequest resourceRequest,
			ResourceResponse resourceResponse) {
		_log.info("calling episodeChecked resource method");
		String rssFeed_category_Id = ParamUtil.getString(resourceRequest, "episode_category_rss_Id");
		long episodeId = 0;
		long categoryId = 0;
		long rssFeedId = 0;
		String ids[] = rssFeed_category_Id.split(StringPool.COMMA);
		 for (int i = 0; i < ids.length; i++) {
			 episodeId = Long.parseLong(ids[0]);
			// categoryId = Long.parseLong(ids[1]);
			 rssFeedId =  Long.parseLong(ids[2]);
		}
		 _log.info("episodeId -------"+episodeId +" categoryId------"+categoryId);
		 
		    BR_Episode br_episode = null;
			try {
				BR_Episode availableBR = (BR_Episode)BR_EpisodeLocalServiceUtil.findBR_episodeByEpisodeIdAndCategoryId(episodeId, categoryId);
				if(Validator.isNull(availableBR)){
					_log.info("Adding New BR....");
					br_episode = BR_EpisodeLocalServiceUtil.createBR_Episode(CounterLocalServiceUtil.increment(BR_Episode.class.getName()));
					br_episode.setCategoryId(categoryId);
					br_episode.setEpisodeId(episodeId);
					br_episode.setRssFeedId(rssFeedId);
					br_episode.setUserId(PortalUtil.getUserId(resourceRequest));
					long maxPriority = 0;
					
					List<BR_Episode> brilliantEpisodes = BR_EpisodeLocalServiceUtil.findBR_episodeByCategoyId(categoryId);
					_log.info("brilliantEpisodes Size : "+brilliantEpisodes.size());
					if(brilliantEpisodes.size()==0){
						br_episode.setPriority(1);
					}
					else
					{
						for(BR_Episode brilliantEpisode: brilliantEpisodes){
							if(brilliantEpisode.getPriority()>maxPriority){
								maxPriority = brilliantEpisode.getPriority();
							}
							br_episode.setPriority(maxPriority+1);
						}
					}
					_log.info("Adding Now...");
					BR_EpisodeLocalServiceUtil.updateBR_Episode(br_episode);
				}
				else
				{
					_log.info("BR Already Added!!!");
				}
			
			} catch (SystemException e) {
				_log.info("SystemException is getting "+e.getMessage());
			}
	}
	
	
	@ResourceMapping(value = ResourceKeys.BR_EPISODE_UNCHECK)
	public void episodeFeedUnChecked(ResourceRequest resourceRequest,
			ResourceResponse resourceResponse) {
		
		_log.info("calling episodeUnChecked resource method");
		String episodeId_category_Id = ParamUtil.getString(resourceRequest, "episode_category_Id");
		long episodeId = 0;
		long categoryId = 0;
		String ids[] = episodeId_category_Id.split(StringPool.COMMA);
		 for (int i = 0; i < ids.length; i++) {
			 episodeId = Long.parseLong(ids[0]);
			 categoryId = Long.parseLong(ids[1]);
		}
		 _log.info("episodeId -------"+episodeId +" categoryId------"+categoryId);
		
		 try {
			 BR_Episode availableBR = (BR_Episode)BR_EpisodeLocalServiceUtil.findBR_episodeByEpisodeIdAndCategoryId(episodeId, categoryId);
				_log.info("BR Priority : "+availableBR.getPriority());
				
				List<BR_Episode> allBREpisodes = BR_EpisodeLocalServiceUtil.findBR_episodeByCategoyId(categoryId);
				
				for (BR_Episode br_episode : allBREpisodes) {
					_log.info("PRIO : "+br_episode.getPriority()+", CategoryId : "+br_episode.getCategoryId());
				}
				
				_log.info("Index Of Deleted : "+allBREpisodes.indexOf(availableBR));
				List<BR_Episode> modifiableBREpisodeList = ListUtil.subList(allBREpisodes,
						allBREpisodes.indexOf(availableBR), allBREpisodes.size());
				for (BR_Episode br_episode : modifiableBREpisodeList) {
					_log.info("categoryId : "+br_episode.getCategoryId()+", Priority : "+br_episode.getPriority());
					br_episode.setPriority(br_episode.getPriority()-1);
					BR_EpisodeLocalServiceUtil.updateBR_Episode(br_episode);
				}
				BR_EpisodeLocalServiceUtil.deleteBR_Episode(availableBR);
			} catch (SystemException e) {
				_log.info("SystemException is getting "+e.getMessage());
			}
	}
	
	
	@ResourceMapping(value = ResourceKeys.BR_EPISODE_SORTING)
	public void episodeSorting(ResourceRequest resourceRequest,
			ResourceResponse resourceResponse) {
		_log.info("calling episodeSorting resource method");
		String episodeIDS = ParamUtil.getString(resourceRequest, "episodesIDS");
		long newIndex = ParamUtil.getLong(resourceRequest, "indexEpisode");
		_log.info("episodeIDS :"+ episodeIDS +"  newIndex :"+newIndex);
		long categoryId = ParamUtil.getLong(resourceRequest,"categoryId");
		long episodeId = ParamUtil.getLong(resourceRequest, "episodeId");
		_log.info("categoryId------ :"+categoryId +" episodeId-------"+episodeId);
		
		
		try {
			List<BR_Episode> br_Episodes = BR_EpisodeLocalServiceUtil.findBR_episodeByCategoyId(categoryId);
			BR_Episode br_Episode = BR_EpisodeLocalServiceUtil.findBR_episodeByEpisodeIdAndCategoryId(episodeId, categoryId);
			_log.info("br_Episode---- :"+br_Episode.getPriority());
			long newPosition = newIndex;
			long currentPosition = br_Episodes.indexOf(br_Episode);
			
			if(newPosition > currentPosition){
				_log.info("move down");
				List<BR_Episode> subList = ListUtil.subList(br_Episodes, Integer.parseInt(String.valueOf(currentPosition))+1,
						Integer.parseInt(String.valueOf(newPosition)));
				br_Episode.setPriority(newPosition);
				_log.info("MPriority : "+br_Episode.getPriority());
				BR_EpisodeLocalServiceUtil.updateBR_Episode(br_Episode);
				
				for (BR_Episode br_Episode2 : subList) {
					br_Episode2.setPriority(br_Episode2.getPriority()-1);
					_log.info("Priority : "+br_Episode2.getPriority() +"episode id :"+br_Episode2.getEpisodeId());
					BR_EpisodeLocalServiceUtil.updateBR_Episode(br_Episode2);
				}
				
			}else if(newPosition < currentPosition){
				_log.info("move up");
				
				List<BR_Episode> subList = ListUtil.subList(br_Episodes,Integer.parseInt(String.valueOf(newPosition))-1, 
						Integer.parseInt(String.valueOf(currentPosition)));
				
				br_Episode.setPriority(newPosition);
				_log.info("MPriority : "+br_Episode.getPriority());
				BR_EpisodeLocalServiceUtil.updateBR_Episode(br_Episode);
				for (BR_Episode br_Episode2 : subList) {
					br_Episode2.setPriority(br_Episode2.getPriority()+1);
					_log.info("Priority : "+br_Episode2.getPriority());
					BR_EpisodeLocalServiceUtil.updateBR_Episode(br_Episode2);
				}
			}else{
				_log.info("same position");
				if(newPosition < br_Episode.getPriority()){
					List<BR_Episode> subList = ListUtil.subList(br_Episodes,Integer.parseInt(String.valueOf(newPosition))-1, 
							Integer.parseInt(String.valueOf(currentPosition)));
					
					br_Episode.setPriority(newPosition);
					_log.info("MPriority : "+br_Episode.getPriority());
					BR_EpisodeLocalServiceUtil.updateBR_Episode(br_Episode);
					for (BR_Episode br_Episode2 : subList) {
						br_Episode2.setPriority(br_Episode2.getPriority()+1);
						_log.info("Priority : "+br_Episode2.getPriority());
						BR_EpisodeLocalServiceUtil.updateBR_Episode(br_Episode2);
					}
				}
			}
			
		} catch (SystemException e) {
			_log.error("getting SystemException "+e.getMessage());
		}
	}
	
	
	@ResourceMapping(value = ResourceKeys.BR_RSSFEED_SORTING)
	public void rssFeedSorting(ResourceRequest resourceRequest,
			ResourceResponse resourceResponse) {
		
		_log.info("calling rssFeedSorting resource method");
		String rssFeedIDS = ParamUtil.getString(resourceRequest, "rssFeedIDS");
		long newIndex = ParamUtil.getLong(resourceRequest, "indexRssFeed");
		_log.info("rssFeedIDS :"+ rssFeedIDS +"  newIndex :"+newIndex);
		long categoryId = ParamUtil.getLong(resourceRequest,"categoryId");
		long rssFeedId = ParamUtil.getLong(resourceRequest, "rssFeedId");
		_log.info("categoryId------ :"+categoryId +" rssFeedId-------"+rssFeedId);
		
		
		try {
			List<BR_RSSFeed> br_rssFeeds = BR_RSSFeedLocalServiceUtil.findBR_RSSFeedByCategoyId(categoryId);
			BR_RSSFeed br_RSSFeed = BR_RSSFeedLocalServiceUtil.findBRByRSSFeedIdAndCategoryId(rssFeedId, categoryId);
			_log.info("br_RSSFeed---- :"+br_RSSFeed.getPriority());
			long newPosition = newIndex;
			long currentPosition = br_rssFeeds.indexOf(br_RSSFeed);
			
			if(newPosition > currentPosition){
				_log.info("move down");
				List<BR_RSSFeed> subList = ListUtil.subList(br_rssFeeds, Integer.parseInt(String.valueOf(currentPosition))+1,
						Integer.parseInt(String.valueOf(newPosition)));
				br_RSSFeed.setPriority(newPosition);
				_log.info("MPriority : "+br_RSSFeed.getPriority());
				BR_RSSFeedLocalServiceUtil.updateBR_RSSFeed(br_RSSFeed);
				
				for (BR_RSSFeed br_RSSFeed2 : subList) {
					br_RSSFeed2.setPriority(br_RSSFeed2.getPriority()-1);
					_log.info("Priority : "+br_RSSFeed2.getPriority() +"rssFeed id :"+br_RSSFeed2.getRssFeedId());
					BR_RSSFeedLocalServiceUtil.updateBR_RSSFeed(br_RSSFeed2);
				}
				
			}else if(newPosition < currentPosition){
				_log.info("move up");
				
				List<BR_RSSFeed> subList = ListUtil.subList(br_rssFeeds,Integer.parseInt(String.valueOf(newPosition))-1, 
						Integer.parseInt(String.valueOf(currentPosition)));
				
				br_RSSFeed.setPriority(newPosition);
				_log.info("MPriority : "+br_RSSFeed.getPriority());
				BR_RSSFeedLocalServiceUtil.updateBR_RSSFeed(br_RSSFeed);
				for (BR_RSSFeed br_RSSFeed2 : subList) {
					br_RSSFeed2.setPriority(br_RSSFeed2.getPriority()+1);
					_log.info("Priority : "+br_RSSFeed2.getPriority());
					BR_RSSFeedLocalServiceUtil.updateBR_RSSFeed(br_RSSFeed2);
				}
			}else{
				_log.info("same position");
				if(newPosition < br_RSSFeed.getPriority()){
					List<BR_RSSFeed> subList = ListUtil.subList(br_rssFeeds,Integer.parseInt(String.valueOf(newPosition))-1, 
							Integer.parseInt(String.valueOf(currentPosition)));
					
					br_RSSFeed.setPriority(newPosition);
					_log.info("MPriority : "+br_RSSFeed.getPriority());
					BR_RSSFeedLocalServiceUtil.updateBR_RSSFeed(br_RSSFeed);
					for (BR_RSSFeed br_RSSFeed2 : subList) {
						br_RSSFeed2.setPriority(br_RSSFeed2.getPriority()+1);
						_log.info("Priority : "+br_RSSFeed2.getPriority());
						BR_RSSFeedLocalServiceUtil.updateBR_RSSFeed(br_RSSFeed2);
					}
				}
			}
			
		} catch (SystemException e) {
			_log.error("getting SystemException "+e.getMessage());
		}
		
	}
	
	@ResourceMapping(value = ResourceKeys.BR_GLOBAL_CHECKED_RSS)
	public void globalCheckedRSS(ResourceRequest resourceRequest,
			ResourceResponse resourceResponse) {
		_log.info("Calling global checked rss resource method");
		long rssFeedId = ParamUtil.getLong(resourceRequest, "rssFeedId");
		long categoryId = 0;
		
		 _log.info("rssFeedId -------"+rssFeedId +" categoryId------"+categoryId);
		 
		 
		BR_RSSFeed br_rssFeed = null;
		try {
			BR_RSSFeed availableBR = (BR_RSSFeed)BR_RSSFeedLocalServiceUtil.findBRByRSSFeedIdAndCategoryId(rssFeedId, categoryId);
			if(Validator.isNull(availableBR)){
				_log.info("Adding New BR....");
				br_rssFeed = BR_RSSFeedLocalServiceUtil.createBR_RSSFeed(CounterLocalServiceUtil.increment(BR_RSSFeed.class.getName()));
				br_rssFeed.setCategoryId(categoryId);
				br_rssFeed.setRssFeedId(rssFeedId);
				br_rssFeed.setUserId(PortalUtil.getUserId(resourceRequest));
				long maxPriority = 0;
				
				List<BR_RSSFeed> brilliantRSSFeeds = BR_RSSFeedLocalServiceUtil.findBR_RSSFeedByCategoyId(categoryId);
				_log.info("brilliantRSSFeeds Size : "+brilliantRSSFeeds.size());
				if(brilliantRSSFeeds.size()==0){
					br_rssFeed.setPriority(1);
				}
				else
				{
					for(BR_RSSFeed brilliantRSSFeed: brilliantRSSFeeds){
						if(brilliantRSSFeed.getPriority()>maxPriority){
							maxPriority = brilliantRSSFeed.getPriority();
						}
						br_rssFeed.setPriority(maxPriority+1);
					}
				}
				_log.info("Adding Now...");
				BR_RSSFeedLocalServiceUtil.updateBR_RSSFeed(br_rssFeed);
			}
			else
			{
				_log.info("BR Already Added!!!");
			}
		
		} catch (SystemException e) {
			_log.info("SystemException is getting "+e.getMessage());
		}
	}
	
	
	@ResourceMapping(value = ResourceKeys.BR_GLOBAL_UNCHECKED_RSS)
	public void globalUncheckedRSS(ResourceRequest resourceRequest,
			ResourceResponse resourceResponse) {
		_log.info("Calling global unchecked rss resource method");
		long rssFeedId = ParamUtil.getLong(resourceRequest, "rssFeedId");
		long categoryId = 0;
		
		_log.info("rssFeedId -------"+rssFeedId +" categoryId------"+categoryId);
		 try {
			 BR_RSSFeed availableBR = (BR_RSSFeed)BR_RSSFeedLocalServiceUtil.findBRByRSSFeedIdAndCategoryId(rssFeedId, categoryId);
			
			_log.info("BR Priority : "+availableBR.getPriority());
			
			List<BR_RSSFeed> allBRRSSFeeds = BR_RSSFeedLocalServiceUtil.findBR_RSSFeedByCategoyId(categoryId);
			
			for (BR_RSSFeed br_rssFeed : allBRRSSFeeds) {
				_log.info("PRIO : "+br_rssFeed.getPriority()+", CategoryId : "+br_rssFeed.getCategoryId());
			}
			
			_log.info("Index Of Deleted : "+allBRRSSFeeds.indexOf(availableBR));
			List<BR_RSSFeed> modifiableBRRSSFeedList = ListUtil.subList(allBRRSSFeeds,
					allBRRSSFeeds.indexOf(availableBR), allBRRSSFeeds.size());
			for (BR_RSSFeed br_rssFeed : modifiableBRRSSFeedList) {
				_log.info("categoryId : "+br_rssFeed.getCategoryId()+", Priority : "+br_rssFeed.getPriority());
				br_rssFeed.setPriority(br_rssFeed.getPriority()-1);
				BR_RSSFeedLocalServiceUtil.updateBR_RSSFeed(br_rssFeed);
			}
			BR_RSSFeedLocalServiceUtil.deleteBR_RSSFeed(availableBR);
		} catch (SystemException e) {
			_log.info("SystemException is getting "+e.getMessage());
		}
	}
	
	
}