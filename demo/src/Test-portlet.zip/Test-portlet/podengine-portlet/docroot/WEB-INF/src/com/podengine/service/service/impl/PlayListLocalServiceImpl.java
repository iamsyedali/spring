/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.podengine.service.service.impl;

import java.util.List;

import com.liferay.portal.kernel.exception.SystemException;
import com.podengine.service.NoSuchPlayListException;
import com.podengine.service.model.PlayList;
import com.podengine.service.model.Podcast;
import com.podengine.service.service.base.PlayListLocalServiceBaseImpl;

/**
 * The implementation of the play list local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.podengine.service.service.PlayListLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author shamshuddin
 * @see com.podengine.service.service.base.PlayListLocalServiceBaseImpl
 * @see com.podengine.service.service.PlayListLocalServiceUtil
 */
public class PlayListLocalServiceImpl extends PlayListLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.podengine.service.service.PlayListLocalServiceUtil} to access the play list local service.
	 */
	
	public List<PlayList> findPlaylistByUserId(long userId) throws SystemException{
		return playListPersistence.findByPlaylistByUserId(userId);
	}
	public List<PlayList> findPlaylistByPodcastId(long PodcastId) throws SystemException{
		return playListPersistence.findByPodcastId(PodcastId);
	}
	public PlayList findByPodcastIdAndUserId(long podcastId, long userId) throws NoSuchPlayListException, SystemException{
		
		return playListPersistence.findBypodcastIdAndUserId(podcastId, userId);
	}
	
	
}