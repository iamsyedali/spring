package com.podengine.portlet.admin;

import java.io.IOException;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.portlet.bind.annotation.ActionMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;
import org.springframework.web.portlet.bind.annotation.ResourceMapping;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portlet.asset.model.AssetCategory;
import com.liferay.portlet.asset.service.AssetCategoryLocalServiceUtil;
import com.podengine.portal.rss.parser.XMLParser;
import com.podengine.portal.util.PodEngineUtil;
import com.podengine.portal.util.constants.POPUP_ID;
import com.podengine.portal.util.constants.PortletMode;
import com.podengine.portal.util.constants.ResourceKeys;
import com.podengine.service.NoSuchRSSfeedException;
import com.podengine.service.model.RSSfeed;
import com.podengine.service.service.RSSfeedLocalServiceUtil;

@Controller
@RequestMapping({PortletMode.VIEW})
public class RSSFeedController {

	private static Log _log = LogFactoryUtil.getLog(RSSFeedController.class);
	private static final String VIEW_JSP = "view";
	private static final String ADD_UPDATE_RSS_JSP = "add-edit-rss";
	private static final String DELETE_RSS_FEED_JSP = "delete-rss-feed";

	@ActionMapping
	public void defaultAction(ActionRequest request,
			ActionResponse actionResponse) {
		_log.info("Default Action.....");
	}

	@RenderMapping
	public String defaultRender(RenderRequest renderRequest,
			RenderResponse renderResponse) {
		PodEngineUtil.getThemeDisplay(renderRequest);
		_log.info("Default Render.....");
		String action = ParamUtil.getString(renderRequest, "action");
		_log.info("action in default render :" + action);

		if (action.equals("addRss")) {
			renderRequest.setAttribute("crudType", "add");
			return ADD_UPDATE_RSS_JSP;
		}
		if (action.equals("deleteRssPopUp")) {
			long rssFeedId = ParamUtil.getLong(renderRequest, "rssFeedId");
			RSSfeed rssFeed = null;
			try {
				rssFeed = RSSfeedLocalServiceUtil.getRSSfeed(rssFeedId);
				renderRequest.setAttribute("rssFeed", rssFeed);
			} catch (PortalException e) {
				_log.error("Portal Exception " + e.getMessage());
			} catch (SystemException e) {
				_log.error("System Exception " + e.getMessage());
			}
			return DELETE_RSS_FEED_JSP;
		}
		return VIEW_JSP;
	}

	@RenderMapping(params = "action=editRSS")
	public String editRSS(RenderRequest renderRequest,
			RenderResponse renderResponse) throws SystemException {
		
		long rssFeedId = ParamUtil.getLong(renderRequest, "rssFeedId");
		RSSfeed rssFeed = null;
		try {
			rssFeed = RSSfeedLocalServiceUtil.getRSSfeed(rssFeedId);
			_log.info("rssFeed URL IS : " + rssFeed.getFeedURL());
		} catch (PortalException e) {
			_log.error("PortalException " + e.getMessage());
		} catch (SystemException e) {
			_log.error("SystemException " + e.getMessage());
		}
		String currentCategories = StringPool.BLANK;
		List<AssetCategory> categories = AssetCategoryLocalServiceUtil
				.getCategories(RSSfeed.class.getName(), rssFeedId);
		for (AssetCategory assetCategory : categories) {
			currentCategories += assetCategory.getCategoryId() + ",";
		}
		renderRequest.setAttribute("rssFeed", rssFeed);
		renderRequest.setAttribute("crudType", "update");
		renderRequest.setAttribute("currentCategories", currentCategories);
		_log.info("action=editRSS Render..... currentCategories : "
				+ currentCategories);
		return ADD_UPDATE_RSS_JSP;
	}

	@ActionMapping(params = "action=addRss")
	public void addRss(ActionRequest actionRequest,
			ActionResponse actionResponse) {
		
		actionRequest = PodEngineUtil.addRSS(actionRequest);
		String checkbox1 = ParamUtil.getString(actionRequest, "userType");
		_log.info(checkbox1);
		_log.info("addRss Action.....");
		actionRequest.setAttribute("closePOPUPID", POPUP_ID.ADD_RSS);
	}

	@ActionMapping(params = "action=deleteRss")
	public void deleteRss(ActionRequest actionRequest,
			ActionResponse actionResponse) {

		long rssFeedId = ParamUtil.getLong(actionRequest, "rssFeedId");
		PodEngineUtil.deleteRSS(rssFeedId);
		SessionMessages.add(actionRequest, "delete");
		actionRequest.setAttribute("closePOPUPID", POPUP_ID.DELETE_RSS);
		
		_log.info("RSS Feed Deleted .....");
	}

	@ResourceMapping(value = ResourceKeys.VALIDATE_RSS_FEED_URL)
	public void validateUrl(ResourceRequest resourceRequest,
			ResourceResponse resourceResponse) {
		
		_log.info(ParamUtil.getString(resourceRequest, "stringURL"));
		try {
			if (PodEngineUtil.validateURL(ParamUtil.getString(resourceRequest,"stringURL"))) {
				RSSfeed rsSfeed = null;
				try {
					rsSfeed = RSSfeedLocalServiceUtil
							.findbyRSSfeedURL(ParamUtil.getString(
									resourceRequest, "stringURL"));
				} catch (NoSuchRSSfeedException | SystemException e) {
					_log.info(" NoSuchRSSfeedException ");
				}
				if (rsSfeed != null) {
					_log.info("url exists in DB");
					resourceResponse.getWriter().print(true);
				} else {
					if (ParamUtil.getString(resourceRequest, "userName").equalsIgnoreCase("notAvailable")) {
						boolean status = XMLParser.RSSFeedRootCheck(ParamUtil
								.getString(resourceRequest, "stringURL"),
								"notRequired", "notRequired", false);
						if (status == false) {
							_log.info(status);
							resourceResponse.getWriter().print("RootCheck");
						}
					} else {
						boolean status = XMLParser.RSSFeedRootCheck(ParamUtil
								.getString(resourceRequest, "stringURL"),
								ParamUtil.getString(resourceRequest, "userName"),
								ParamUtil.getString(resourceRequest, "passw0rd"),
								true);
						if (status == false) {
							resourceResponse.getWriter().print("RootCheck");
						}
					}
				}

			} else {
				_log.info("Url not in proper format");
				resourceResponse.getWriter().print(false);
			}
		} catch (IOException e) {
			_log.error("IO Exception");
			try {
				resourceResponse.getWriter().print("RootCheck");
			} catch (IOException e1) {
				_log.error("IO Exception in catch");
			}
		}

	}
}
