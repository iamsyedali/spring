package com.podengine.portal.util;

import java.util.Locale;

import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portlet.asset.model.BaseAssetRenderer;
import com.podengine.service.model.RSSfeed;

public class HostAndPostAssetRenderer extends BaseAssetRenderer{
	
	private RSSfeed _rssFeed;

	public HostAndPostAssetRenderer(RSSfeed rssFeed) {
		_rssFeed=rssFeed;
	}

	@Override
	public String getClassName() {
		// TODO Auto-generated method stub
		return RSSfeed.class.getName();
	}

	@Override
	public long getClassPK() {
		// TODO Auto-generated method stub
		return _rssFeed.getRssfeedId();
	}

	@Override
	public long getGroupId() {
		// TODO Auto-generated method stub
		return _rssFeed.getGroupId();
	}

	@Override
	public String getSummary(Locale arg0) {
		// TODO Auto-generated method stub
		return _rssFeed.getDescription();
	}

	@Override
	public String getTitle(Locale arg0) {
		// TODO Auto-generated method stub
		return _rssFeed.getTitle();
	}

	@Override
	public long getUserId() {
		// TODO Auto-generated method stub
		return _rssFeed.getUserId();
	}

	@Override
	public String getUserName() {
		String userName=null;
		try {
		userName= UserLocalServiceUtil.getUser(_rssFeed.getUserId()).getFullName();
		} catch (PortalException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		} catch (SystemException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return userName;
		}
		return userName;
	}

	@Override
	public String getUuid() {
		// TODO Auto-generated method stub
		return _rssFeed.getUuid();
	}

	@Override
	public String render(RenderRequest request, RenderResponse response, String template)
			throws Exception {
		if(template.equals(TEMPLATE_FULL_CONTENT)){
			request.setAttribute("rssFeedObject",_rssFeed);
			return "/view/find-content/view.jsp";
		}
		else
		{
			return null;
		}
	}

}
