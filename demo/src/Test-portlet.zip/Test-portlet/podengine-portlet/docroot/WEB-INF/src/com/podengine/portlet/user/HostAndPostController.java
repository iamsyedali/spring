package com.podengine.portlet.user;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletContext;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.portlet.bind.annotation.ActionMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;
import org.springframework.web.portlet.bind.annotation.ResourceMapping;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.upload.UploadPortletRequest;
import com.liferay.portal.kernel.util.HtmlUtil;
import com.liferay.portal.kernel.util.HttpUtil;
import com.liferay.portal.kernel.util.MimeTypesUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.Resource;
import com.liferay.portal.model.ResourceAction;
import com.liferay.portal.model.ResourceConstants;
import com.liferay.portal.model.ResourcePermission;
import com.liferay.portal.model.Role;
import com.liferay.portal.model.RoleConstants;
import com.liferay.portal.security.permission.ActionKeys;
import com.liferay.portal.service.ResourceActionLocalServiceUtil;
import com.liferay.portal.service.ResourceLocalServiceUtil;
import com.liferay.portal.service.ResourcePermissionLocalServiceUtil;
import com.liferay.portal.service.RoleLocalServiceUtil;
import com.liferay.portal.service.ServiceContext;
import com.liferay.portal.service.ServiceContextFactory;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portal.util.PortletKeys;
import com.liferay.portlet.asset.model.AssetEntry;
import com.liferay.portlet.asset.model.AssetVocabulary;
import com.liferay.portlet.asset.service.AssetEntryLocalServiceUtil;
import com.liferay.portlet.asset.service.AssetVocabularyLocalServiceUtil;
import com.liferay.portlet.documentlibrary.model.DLFileEntry;
import com.liferay.portlet.documentlibrary.model.DLFolder;
import com.liferay.portlet.documentlibrary.service.DLFileEntryLocalServiceUtil;
import com.liferay.portlet.documentlibrary.service.DLFolderLocalServiceUtil;
import com.podengine.portal.rss.parser.XMLParser;
import com.podengine.portal.util.PodEngineUtil;
import com.podengine.portal.util.constants.CMD;
import com.podengine.portal.util.constants.CONTENT_TYPE;
import com.podengine.portal.util.constants.POPUP_ID;
import com.podengine.portal.util.constants.PortletMode;
import com.podengine.portal.util.constants.RenderKeys;
import com.podengine.portal.util.constants.ResourceKeys;
import com.podengine.service.NoSuchRSSfeedException;
import com.podengine.service.model.Host;
import com.podengine.service.model.Podcast;
import com.podengine.service.model.RSSfeed;
import com.podengine.service.service.HostLocalServiceUtil;
import com.podengine.service.service.PodcastLocalServiceUtil;
import com.podengine.service.service.RSSfeedLocalServiceUtil;

@Controller
@RequestMapping({PortletMode.VIEW})
public class HostAndPostController {
	private static Log _log = LogFactoryUtil.getLog(HostAndPostController.class);
	private static final String VIEW_JSP = "view";
	private static final String POST = "post";
	private static final String ADDRSS_JSP = "add-rss";
	private static final String HOST = "host";
	public static ThemeDisplay themeDisplay;
	
	@ActionMapping
	public void defaultAction(ActionRequest request, ActionResponse actionResponse) {
		_log.info("Default Action.....");
	}
	
	@ActionMapping(params =CMD.ACTION+StringPool.EQUAL+com.podengine.portal.util.constants.ActionKeys.HOST_DATA)
	public void hostData(ActionRequest actionRequest, ActionResponse actionResponse)  {
		ThemeDisplay themeDisplay= (ThemeDisplay)actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		UploadPortletRequest uploadRequest=PortalUtil.getUploadPortletRequest(actionRequest);
		String showname=ParamUtil.getString(uploadRequest, "showName");
		File imagefile=uploadRequest.getFile("profImage");
		// File rssFeedImage=imagefile;
		
		String showDescribtion=ParamUtil.getString(uploadRequest, "showDescribtion");
		String accessType=ParamUtil.getString(uploadRequest, "accessType");
		String city=ParamUtil.getString(uploadRequest, "city");
		String state=ParamUtil.getString(uploadRequest, "state");
		String country=ParamUtil.getString(uploadRequest, "country");
		String language=ParamUtil.getString(uploadRequest, "language");
		String rowIndexes = ParamUtil.getString(uploadRequest, "rowIndexes");
		String webSiteUrl = ParamUtil.getString(uploadRequest, "webSiteUrl");
		String changeLog = "hi"; 
		DLFileEntry dlfileEntry = null;
		Host host=null;
		RSSfeed rssFeed = null;
		try{
			rssFeed = RSSfeedLocalServiceUtil.createRSSfeed(CounterLocalServiceUtil.increment(RSSfeed.class.getName()));
			
			rssFeed.setTitle(showname);
			rssFeed.setImageURL("data:image/png;base64,"+PodEngineUtil.convertBlobToString(PodEngineUtil.convertfileToBlob(imagefile)));
			rssFeed.setDescription(showDescribtion);
			rssFeed.setContentType(CONTENT_TYPE.HOSTED);
			if(PortalUtil.isOmniadmin(themeDisplay.getUserId()))
			{
				rssFeed.setContentType(CONTENT_TYPE.ADMIN_ADDED);
			}
			else
			{
				rssFeed.setContentType(CONTENT_TYPE.HOSTED);
			}
			rssFeed.setWebSiteUrl(webSiteUrl);
			rssFeed.setCompanyId(themeDisplay.getCompanyId());
			rssFeed.setGroupId(themeDisplay.getScopeGroupId());
			rssFeed.setRssFeedImage(PodEngineUtil.convertBlobToString(PodEngineUtil.convertfileToBlob(imagefile)));
			host=HostLocalServiceUtil.createHost(CounterLocalServiceUtil.increment(Host.class.getName()));
			host.setHostId(rssFeed.getRssfeedId());
			host.setShowName(showname);
			host.setShowImage(PodEngineUtil.convertBlobToString(PodEngineUtil.convertfileToBlob(imagefile)));
			host.setState(state);
			host.setShowDescribtion(showDescribtion);
			host.setAccessType(accessType);
			host.setCity(city);
			host.setCountry(country);
			host.setLanguage(language);
			host.setMediaDescribtion(showDescribtion);
			host.setCompanyId(themeDisplay.getCompanyId());
			host.setGroupId(themeDisplay.getScopeGroupId());
			host.setUserId(themeDisplay.getUserId());
			HostLocalServiceUtil.addHost(host);
			RSSfeedLocalServiceUtil.addRSSfeed(rssFeed);
			/*-----------File Entering in ddm-----------*/ 
			String durationPassing =StringPool.IS_NULL;
			String[] stringWithoutPeriod= new String[20];
			long podcastDuration;
			String[] indexOfRows = rowIndexes.split(",");
	        for (int i = 0; i < indexOfRows.length; i++) {
	        	File media =uploadRequest.getFile("media"+ indexOfRows[i]);
	        	durationPassing = GetDuration(actionRequest , media.getAbsolutePath());
	        	stringWithoutPeriod=durationPassing.split("\\.");
	        	podcastDuration=PodEngineUtil.getDurationValue(stringWithoutPeriod[0]);
	        	String mediaDescribtion=ParamUtil.getString(uploadRequest, "mediaDescribtion"+indexOfRows[i]);
	        	String mediaTitle = ParamUtil.getString(uploadRequest, "title"+indexOfRows[i]);
	        	String fileName=uploadRequest.getFileName("media"+ indexOfRows[i]);
	        	InputStream inputStream = new FileInputStream(media);
	 			long userId = themeDisplay.getUserId(); 
	 			long groupId = themeDisplay.getScopeGroupId(); 
	 			long repositoryId = themeDisplay.getScopeGroupId();
	 			String folderName = "PodEngine";
	 			String mimeType = MimeTypesUtil.getContentType(media); 
	 			String FileDescription = mediaDescribtion; 
	 			ServiceContext serviceContext = ServiceContextFactory.getInstance(DLFileEntry.class.getName(), actionRequest); 
     			serviceContext.setSignedIn(true);
     			serviceContext.setAddGroupPermissions(true);
     			serviceContext.setAddGuestPermissions(true);
     			serviceContext.setAssetEntryVisible(true);
     			serviceContext.setGroupPermissions(new String[] {ActionKeys.UPDATE, ActionKeys.VIEW, ActionKeys.ACCESS, ActionKeys.PERMISSIONS});
     			serviceContext.setGuestPermissions(new String[] {ActionKeys.UPDATE, ActionKeys.VIEW, ActionKeys.ACCESS, ActionKeys.PERMISSIONS});
     			DLFolder dlFolder = null;
     			DLFolder dlFolderChild = null;
     			List<DLFolder> childFolderlist =null;
     			DLFileEntry fileEntry=null;
				dlFolder = DLFolderLocalServiceUtil.getFolder(themeDisplay.getScopeGroupId(), 0, folderName);
				long podEngineId=dlFolder.getFolderId();
				childFolderlist=DLFolderLocalServiceUtil.getFolders(themeDisplay.getScopeGroupId(),podEngineId);
				dlFolderChild=DLFolderLocalServiceUtil.getFolder(themeDisplay.getScopeGroupId(), podEngineId, String.valueOf(themeDisplay.getUserId()));
				long fileEntryTypeId = dlFolder.getDefaultFileEntryTypeId();
				     			dlfileEntry = DLFileEntryLocalServiceUtil.addFileEntry(userId, groupId, repositoryId, 
				     						  dlFolderChild.getFolderId(), fileName+""+rssFeed.getRssfeedId(), mimeType, fileName+""+rssFeed.getRssfeedId(), 
				     						  FileDescription, changeLog,fileEntryTypeId, null, media, inputStream, media.length(), serviceContext);
				     			  fileEntry =DLFileEntryLocalServiceUtil.getFileEntry(dlfileEntry.getFileEntryId());
				long folderId = fileEntry.getFolderId();
     			String titleForFile = fileEntry.getTitle();
     			String fileUrl = themeDisplay.getPortalURL() + themeDisplay.getPathContext() 
     							 + "/documents/" + themeDisplay.getScopeGroupId() + "//" + folderId +  "//" 
     							 + HttpUtil.encodeURL(HtmlUtil.unescape(titleForFile));
     			HostAndPostController.setFilePermissions(fileEntry);
     			Resource resource=null;
	     		resource=ResourceLocalServiceUtil.getResource(dlfileEntry.getCompanyId(), DLFileEntry.class.getName(), 
 						 ResourceConstants.SCOPE_INDIVIDUAL, String.valueOf(dlfileEntry.getPrimaryKey()));
	     		
                ResourceLocalServiceUtil.addResources(dlfileEntry.getCompanyId(), themeDisplay.getScopeGroupId(), 0,
                    PortletKeys.DOCUMENT_LIBRARY, dlfileEntry.getFileEntryId(), true, true, true);
 		                 
                resource = ResourceLocalServiceUtil.getResource(dlfileEntry.getCompanyId(), DLFileEntry.class.getName(),
                ResourceConstants.SCOPE_INDIVIDUAL, String.valueOf(dlfileEntry.getPrimaryKey()));
 		                 
                Role userRole = RoleLocalServiceUtil.getRole(themeDisplay.getCompanyId(),RoleConstants.USER);
     			if(Validator.isNotNull(userRole))
     			{
     	            String[] actionIds = {"ADD_DISCUSSION","DELETE","DELETE_DISCUSSION","UPDATE","UPDATE_DISCUSSION","VIEW"};
	   	           ResourcePermissionLocalServiceUtil.setResourcePermissions(themeDisplay.getCompanyId(), DLFileEntry.class.getName(), ResourceConstants.SCOPE_INDIVIDUAL, "Testing", dlfileEntry.getPrimaryKey(), actionIds);
     	        }
     			Podcast podcast = PodcastLocalServiceUtil.createPodcast(CounterLocalServiceUtil.increment(Podcast.class.getName()));
     			podcast.setPodcastURL(fileUrl);
     			podcast.setPodcastTitle(mediaTitle);
     			podcast.setPodcastDescription(mediaDescribtion);
     			podcast.setPodcastSize(fileEntry.getSize());
     			podcast.setPodcastPublishDate(PodEngineUtil	.convertDateToUnixTimeStamp(fileEntry.getCreateDate()));
     			podcast.setRSSFeedId(rssFeed.getRssfeedId());
     			podcast.setPodcastImage(PodEngineUtil.convertBlobToString(PodEngineUtil.convertfileToBlob(imagefile)));
     			podcast.setPodcastDuration(podcastDuration);
     			PodcastLocalServiceUtil.addPodcast(podcast);
     			
     			AssetEntry assetEntry = AssetEntryLocalServiceUtil.updateEntry(themeDisplay.getUserId(), themeDisplay.getScopeGroupId(), DLFileEntry.class.getName(),
     					 				dlfileEntry.getFileEntryId(), null, null);
				assetEntry.setVisible(true);
				AssetEntryLocalServiceUtil.updateAssetEntry(assetEntry);
	        }
			/*--------file Entering End in ddm-----------*/
			
			String categoryIds = StringPool.BLANK;
			AssetVocabulary vocab = null;
		
			 vocab = AssetVocabularyLocalServiceUtil.getGroupVocabulary(themeDisplay.getCompanyGroupId(), "Podengine Categories");
			 categoryIds = ParamUtil.getString(uploadRequest,"_hostandpost_WAR_podengineportlet_assetCategoryIds_"+vocab.getVocabularyId());
			 String[] cats = StringUtil.split(categoryIds, ",");
			 long categs [] = new long[cats.length];
			 for (int i = 0; i < cats.length; i++)
			 {
				categs[i] = Long.parseLong(cats[i]);
			 }
			 AssetEntry assetEntry = AssetEntryLocalServiceUtil.updateEntry(themeDisplay.getUserId(), themeDisplay.getScopeGroupId(), RSSfeed.class.getName(),
				rssFeed.getRssfeedId(), categs, null);
			 assetEntry.setVisible(true);
			 AssetEntryLocalServiceUtil.updateAssetEntry(assetEntry);
			actionRequest.setAttribute("closePOPUPID", POPUP_ID.HOST_CONTENT);
		}catch( FileNotFoundException fileNotFoundException){
			_log.error("File not for Image in Host method ", fileNotFoundException);
			
		}catch(SQLException sqlException){
			_log.error("SQL Exception in Host method",sqlException);
			
		}catch(PortalException portalException){
			_log.error("Portal Exception in Host method"+portalException.getMessage());
			
		}
		catch(SystemException systemException){
			_log.error("System Exception in Host method"+systemException.getMessage());
			
		}catch(Exception exception){
			_log.error("Exception in Host method",exception);
		}
	}
	public static void setFilePermissions(DLFileEntry fileEntry) throws Exception
	{
		ResourcePermission resourcePermission = null;
		final Role siteMemberRole = RoleLocalServiceUtil.getRole(fileEntry.getCompanyId(), RoleConstants.USER);
		ResourceAction resourceAction = ResourceActionLocalServiceUtil.getResourceAction(DLFileEntry.class.getName(), ActionKeys.VIEW);
		try
		{
			resourcePermission = ResourcePermissionLocalServiceUtil.getResourcePermission(fileEntry.getCompanyId(),
			DLFileEntry.class.getName(), ResourceConstants.SCOPE_INDIVIDUAL, String.valueOf(fileEntry
			.getPrimaryKey()), siteMemberRole.getRoleId());
				if (Validator.isNotNull(resourcePermission))
					{
						resourcePermission.setActionIds(resourceAction.getBitwiseValue());
						ResourcePermissionLocalServiceUtil.updateResourcePermission(resourcePermission);
					}
		} 
		catch (com.liferay.portal.NoSuchResourcePermissionException e){
				resourcePermission = ResourcePermissionLocalServiceUtil
				.createResourcePermission(CounterLocalServiceUtil.increment());
				resourcePermission.setCompanyId(fileEntry.getCompanyId());
				resourcePermission.setName(DLFileEntry.class.getName());
				resourcePermission.setScope(ResourceConstants.SCOPE_INDIVIDUAL);
				resourcePermission.setPrimKey(String.valueOf(fileEntry.getPrimaryKey()));
				resourcePermission.setRoleId(siteMemberRole.getRoleId());
				resourcePermission.setActionIds(resourceAction.getBitwiseValue());
				ResourcePermissionLocalServiceUtil.addResourcePermission(resourcePermission);
		}
	}
	@RenderMapping
	  public String defaultRender(RenderRequest renderRequest, RenderResponse renderResponse) {
		PodEngineUtil.getThemeDisplay(renderRequest);
		String action = ParamUtil.getString(renderRequest, "action");
		_log.info("action in default render :" + action);
		if (action.equals(RenderKeys.ADD_RSS)) {
			renderRequest.setAttribute("crudType", "add");
			return POST;
		}
		return VIEW_JSP;
	 }

	 @RenderMapping(params="action=renderPost")
	 public String renderPostMethod(RenderRequest renderRequest, RenderResponse renderResponse) {
		 _log.info("Default Render.....");
		return ADDRSS_JSP;
	 }
	 @RenderMapping(params =CMD.ACTION+StringPool.EQUAL+com.podengine.portal.util.constants.RenderKeys.POST)
	  public String postOneMethod(RenderRequest renderRequest, RenderResponse renderResponse) {
		 _log.info("Default Render.....");
		return POST;
	 }
	 @RenderMapping(params =CMD.ACTION+StringPool.EQUAL+com.podengine.portal.util.constants.RenderKeys.HOST)
	  public String hostOneMethod(RenderRequest renderRequest, RenderResponse renderResponse) {
		 _log.info("Default Render.....");
		return HOST;
	 }
	 @ActionMapping(params =CMD.ACTION+StringPool.EQUAL+com.podengine.portal.util.constants.ActionKeys.ADD_RSS)
		public void addRss(ActionRequest actionRequest,
				ActionResponse actionResponse) {
			actionRequest = PodEngineUtil.addRSSForPost(actionRequest);
			
			String checkbox1 = ParamUtil.getString(actionRequest, "userType");
			_log.info(checkbox1);
			actionRequest.setAttribute("closePOPUPID", "post-popup");
		}
	 @ResourceMapping(value = ResourceKeys.VALIDATE_RSS_FEED_URL)
		public void validateUrl(ResourceRequest resourceRequest,
				ResourceResponse resourceResponse) {
		 _log.info("In Resource URL validate Rss");
			
			_log.info(ParamUtil.getString(resourceRequest, "stringURL"));
			try {
				if (PodEngineUtil.validateURL(ParamUtil.getString(resourceRequest,"stringURL"))) {
					RSSfeed rsSfeed = null;
					try {
						rsSfeed = RSSfeedLocalServiceUtil
								.findbyRSSfeedURL(ParamUtil.getString(
										resourceRequest, "stringURL"));
					} catch (NoSuchRSSfeedException | SystemException e) {
						_log.info(" NoSuchRSSfeedException ");
					}
					if (rsSfeed != null) {
						_log.info("url exists in DB");
						resourceResponse.getWriter().print(true);
					} else {
						if (ParamUtil.getString(resourceRequest, "userName").equalsIgnoreCase("notAvailable")) {
							boolean status = XMLParser.RSSFeedRootCheck(ParamUtil
									.getString(resourceRequest, "stringURL"),
									"notRequired", "notRequired", false);
							if (status == false) {
								_log.info(status);
								resourceResponse.getWriter().print("RootCheck");
							}
						} else {
							boolean status = XMLParser.RSSFeedRootCheck(ParamUtil
									.getString(resourceRequest, "stringURL"),
									ParamUtil.getString(resourceRequest, "userName"),
									ParamUtil.getString(resourceRequest, "passw0rd"),
									true);
							if (status == false) {
								resourceResponse.getWriter().print("RootCheck");
							}
						}
					}

				} else {
					_log.info("Url not in proper format");
					resourceResponse.getWriter().print(false);
				}
			} catch (IOException e) {
				_log.error("IO Exception");
				try {
					resourceResponse.getWriter().print("RootCheck");
				} catch (IOException e1) {
					_log.error("IO Exception in catch");
				}
			}

		}
	 public static String GetDuration(ActionRequest actionRequest, final String sVideoInput) 
		    { 
		        String duration = "";
		        PortletContext portletContext = actionRequest.getPortletSession().getPortletContext();
		        String pathOfExe=portletContext.getRealPath("/ffmpeg.exe");
		        try
		        {
		            Process child = null;
		            child = Runtime.getRuntime().exec(pathOfExe + " -i \"" + sVideoInput + "\"");
		            InputStream lsOut = child.getErrorStream();
		            InputStreamReader inputStreamReader = new InputStreamReader(lsOut);
		            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
		            String line;
		            while ((line = bufferedReader.readLine()) != null)
		            {
		                if(line.contains("Duration:"))
		                {
		                    line = line.replaceFirst("Duration: ", ""); 
		                    line = line.trim();
		                    duration = line.substring(0, 11);
		                    break;
		                }
		            }
		        }
		        catch(Exception e)
		        {
		        _log.error("In GetDuration Method of Host and Post"+e);
		        }
				return duration;
		    }
	 }
