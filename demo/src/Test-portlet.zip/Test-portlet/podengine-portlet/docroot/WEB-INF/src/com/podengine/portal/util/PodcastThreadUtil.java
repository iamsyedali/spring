package com.podengine.portal.util;

import com.podengine.service.model.RSSfeed;

public class PodcastThreadUtil {
	
	public static void start (RSSfeed rssFeed) {
		PodcastThread podcastThread = new PodcastThread(rssFeed);
		podcastThread.setName("podcastThread");
		podcastThread.start();
	}
}
