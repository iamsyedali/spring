package com.podengine.portal.util.constants;
/**
 * @author Syed Ali
 */
public class PropsKeys implements com.liferay.portal.kernel.util.PropsKeys {

}
