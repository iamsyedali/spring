package com.podengine.portlet.user;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.portlet.bind.annotation.ActionMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.podengine.portal.util.constants.CMD;
import com.podengine.portal.util.constants.PortletMode;
import com.podengine.service.service.ContactUsLocalServiceUtil;

/**
 * Portlet implementation class ContactUs
 */
@RequestMapping({PortletMode.VIEW})
public class ContactUs {
	
	private static Log _log = LogFactoryUtil.getLog(ContactUs.class);
	private static final String VIEW_JSP = "view";
	
	@ActionMapping(params =CMD.ACTION+StringPool.EQUAL+com.podengine.portal.util.constants.ActionKeys.CONTACT_US)
	public void defaultAction(ActionRequest  actionRequest, ActionResponse actionResponse) {
		
		String contactUsName=ParamUtil.getString(actionRequest, "contactUsName");
		String contactUsEmail=ParamUtil.getString(actionRequest, "contactUsEmail");
		String contactUsphoneNumber=ParamUtil.getString(actionRequest, "contactUsphoneNumber");
		String contactUsaddress=ParamUtil.getString(actionRequest, "contactUsaddress");
		String contactUsDescription=ParamUtil.getString(actionRequest, "contactUsDescription");
		ContactUsLocalServiceUtil.addContactUsData(contactUsName, contactUsEmail, contactUsphoneNumber, contactUsaddress, contactUsDescription);
		SessionMessages.add(actionRequest, "success");
	    
		
		
		
		
		
		
	}
	
	@RenderMapping
	  public String defaultRender(RenderRequest renderRequest, RenderResponse renderResponse) {
		 _log.info("Default Render.....");
		return VIEW_JSP;
	 }
 

}
