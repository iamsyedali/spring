package com.podengine.portlet.user;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;
import javax.servlet.http.Cookie;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.portlet.bind.annotation.ActionMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;
import org.springframework.web.portlet.bind.annotation.ResourceMapping;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.podengine.portal.util.PodEngineUtil;
import com.podengine.portal.util.constants.PortletMode;
import com.podengine.portal.util.constants.ResourceKeys;
import com.podengine.service.NoSuchPlayerStatusException;
import com.podengine.service.model.AutoPlay_Slider;
import com.podengine.service.model.PlayList;
import com.podengine.service.model.PlayerStatus;
import com.podengine.service.model.PlayerTimeStamp;
import com.podengine.service.model.Podcast;
import com.podengine.service.model.impl.PlayerStatusImpl;
import com.podengine.service.service.AutoPlay_SliderLocalServiceUtil;
import com.podengine.service.service.ClpSerializer;
import com.podengine.service.service.PlayListLocalServiceUtil;
import com.podengine.service.service.PlayerStatusLocalServiceUtil;
import com.podengine.service.service.PlayerTimeStampLocalServiceUtil;
import com.podengine.service.service.PodcastLocalServiceUtil;

@Controller
@RequestMapping({PortletMode.VIEW})
public class PlayerController {
	static ClassLoader classLoader = (ClassLoader) PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),"portletClassLoader");
	private static Log _log = LogFactoryUtil.getLog(PlayerController.class);
	private static final String VIEW_JSP = "view";
	
	@ActionMapping
	public void defaultAction(ActionRequest request, ActionResponse actionResponse) {
		
	}
	
	@RenderMapping
	  public String defaultRender(RenderRequest renderRequest, RenderResponse renderResponse) {
		 Cookie[] cookies=renderRequest.getCookies();
		 if (cookies != null) {
			  for (Cookie cookie : cookies) {
			    if (cookie.getName().equals("podCastId")) {
			    	renderRequest.setAttribute("podCastId", cookie.getValue());
			    	  cookie.setMaxAge(0);
			    	  renderResponse.addProperty(cookie);
			     }
			   }
		 }
		return VIEW_JSP;  
	 }

	
	// to get user default playlist
	@ResourceMapping(value=ResourceKeys.User_Play_List)
	 public void getUserPlaylist(ResourceRequest request,ResourceResponse response)
	 {
		try {
			long userId=PortalUtil.getUserId(request);
			long podcastId=0;
			JSONObject playListObject=new JSONObject();
            JSONArray  playListArray=new JSONArray();
			List<PlayList> getPlaylist=PlayListLocalServiceUtil.findPlaylistByUserId(userId);
			 for(PlayList userPlaylist:getPlaylist)
			 {
				podcastId = userPlaylist.getPodcastId();
				Podcast podcast = PodcastLocalServiceUtil.getPodcast(podcastId);
				playListObject.put("title",podcast.getPodcastTitle());
				playListObject.put("url", podcast.getPodcastURL());
				playListObject.put("podCastId",podcast.getRSSFeedId());
				
				playListObject.put("podCastDuration",PodEngineUtil.timeConversion(podcast.getPodcastDuration()));
            	playListObject.put("poster", podcast.getPodcastImageLink());
            	playListArray.put(playListObject);
            	playListObject=new JSONObject();
				
			 }
            try {
				PrintWriter out=response.getWriter();
				out.print(playListArray);
			 } catch (IOException e) {
				 _log.error(e.getMessage());
			}
	     	} catch (SystemException e) {
	   		_log.error(e.getMessage());
		   } catch (PortalException e) {
			e.printStackTrace();
		   } catch (JSONException e) {
			e.printStackTrace();
		   }
	 }   
	
	@SuppressWarnings("null")
	@ResourceMapping(value = ResourceKeys.UPDATE_PLAYERTIMESTAMP)
		public void updatePlayerTimeStamp(ResourceRequest resourceRequest,ResourceResponse resourceResponse) throws SystemException {
		 long totalPlayerTime = ParamUtil.getLong(resourceRequest,"totalPlayerDuration");
		 
			ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);
			long userId = themeDisplay.getUserId();
			PlayerTimeStamp playerStampId = null;
			try {
				playerStampId = PlayerTimeStampLocalServiceUtil.findByPlayerTimeUserId(userId);
				totalPlayerTime = playerStampId.getUsedDuration()+ totalPlayerTime;
			} catch (Exception e) {
				playerStampId = PlayerTimeStampLocalServiceUtil.createPlayerTimeStamp(CounterLocalServiceUtil.increment(PlayerTimeStamp.class.getName()));
			}
			try {
	
				playerStampId.setUserId(userId);
				playerStampId.setUsedDuration(totalPlayerTime);
				PlayerTimeStampLocalServiceUtil.updatePlayerTimeStamp(playerStampId);
	
			} catch (SystemException e) {
				_log.error(e.getMessage()); 
			}
		}
	@ResourceMapping(value =ResourceKeys.PLAYER_TIMESTAMP)
		public void playerTimeStamp(ResourceRequest resourceRequest,ResourceResponse resourceResponse) throws IOException {
		ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);
		long userId = themeDisplay.getUserId();
		long leftduration = 0;
		long usedduration = 0;
		PlayerTimeStamp useridplayertimestamp = null;
		com.liferay.portal.kernel.json.JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
		com.liferay.portal.kernel.json.JSONArray jsonArray = JSONFactoryUtil.createJSONArray();
		try{
			useridplayertimestamp = PlayerTimeStampLocalServiceUtil.findByPlayerTimeUserId(userId);
			leftduration = useridplayertimestamp.getAvailableDuration();
			usedduration = useridplayertimestamp.getUsedDuration();
			jsonObject.put("leftduration", leftduration);
			jsonObject.put("usedduration", usedduration);
			jsonArray.put(jsonObject);
			}catch(Exception e){
			}
		PrintWriter pw = resourceResponse.getWriter();
		pw.print(jsonArray);
	
	}
	
	@ResourceMapping(value ="playPlayerURl")
	public void playPleyerUsingUrl(ResourceRequest request,ResourceResponse response)
	{
		long podCastId=ParamUtil.getLong(request,"MypodCastId");
		JSONObject playListObject=new JSONObject();
        JSONArray  playListArray=new JSONArray();
           if(podCastId!=0)
           {
		try {
			Podcast podCast=PodcastLocalServiceUtil.getPodcast(podCastId);
			try {
				playListObject.put("Title",podCast.getPodcastTitle());
				playListObject.put("url",podCast.getPodcastURL());
				playListObject.put("rssFieldID",podCast.getRSSFeedId());
				playListObject.put("Poster","data:image/jpg;base64,"+podCast.getPodcastImage());
				playListArray.put(playListObject);
				PrintWriter out=response.getWriter();
				out.println(playListArray);
			} catch (JSONException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (PortalException e) {
			e.printStackTrace();
		} catch (SystemException e) {
			e.printStackTrace();
		}
           }
	}

	@ResourceMapping(value ="savePlayerStatus")
	public void savePlayerStatus(ResourceRequest request,ResourceResponse response)
	{
		 
		long songIndex=ParamUtil.getLong(request,"CurrentsongIndex");
		String CurrentSongTime=ParamUtil.getString(request,"getcurrentSongTime");
		long UserID=ParamUtil.getLong(request,"userId");
		
		PlayerStatus playerStatusUserId=null;
		try {
			 playerStatusUserId=PlayerStatusLocalServiceUtil.getPlayerStatusByUserId(UserID);
		} catch (NoSuchPlayerStatusException e1) {
			// TODO Auto-generated catch block
		} catch (SystemException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		  if(playerStatusUserId!=null)
		  {
			    PlayerStatus playerStatus=null;
				try {
					playerStatus = PlayerStatusLocalServiceUtil.getPlayerStatus(playerStatusUserId.getPlayerStatusId());
				} catch (PortalException e) {
					e.printStackTrace();
				} catch (SystemException e) {
					e.printStackTrace();
				}
				playerStatus.setSongNumber(songIndex);	
				playerStatus.setUserId(UserID);
				playerStatus.setSliderPostion(CurrentSongTime);
				try {
					PlayerStatusLocalServiceUtil.updatePlayerStatus(playerStatus);
				} catch (SystemException e) {
					e.printStackTrace();
				}
		  }
		  else{
			    PlayerStatus playerStatus=new PlayerStatusImpl();
				playerStatus.setSongNumber(songIndex);	
				playerStatus.setUserId(UserID);
				playerStatus.setSliderPostion(CurrentSongTime);
				try {
					 PlayerStatusLocalServiceUtil.addPlayerStatus(playerStatus);
				} catch (SystemException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}  
		  }
		
	}
	@ResourceMapping(value ="userPlayerStatus")
	public void getUserPlayerStatus(ResourceRequest request,ResourceResponse response)
	{
		try {
			PlayerStatus playerStatus= PlayerStatusLocalServiceUtil.getPlayerStatusByUserId(ParamUtil.getLong(request,"userId"));
			JSONObject playListObject=new JSONObject();
	        JSONArray  playListArray=new JSONArray();
	        try {
				playListObject.put("songIndex", playerStatus.getSongNumber());
				playListObject.put("songTime", playerStatus.getSliderPostion());
	        } catch (JSONException e) {
				e.printStackTrace();
			}
	        playListArray.put(playListObject);
			try {
				response.getWriter().print(playListArray);
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (PortalException e) {
			e.printStackTrace();
		} catch (SystemException e) {
			e.printStackTrace();
		}		
	}
	
	@ResourceMapping(value ="AutoPlayURL")
	public void AutoPlayURL(ResourceRequest request,ResourceResponse response) throws IOException{
		ThemeDisplay themeDisplay = (ThemeDisplay) request.getAttribute(WebKeys.THEME_DISPLAY);
		String autoPlay_ON=ParamUtil.getString(request,"autoPlay_ON");
		long userID=themeDisplay.getUserId();
		AutoPlay_Slider Autopla_Slider = null;
			try {
				Autopla_Slider = AutoPlay_SliderLocalServiceUtil.findByautoplay_userId(userID);
			} 
			catch (Exception e){
				try {
					Autopla_Slider = AutoPlay_SliderLocalServiceUtil.createAutoPlay_Slider(CounterLocalServiceUtil.increment(AutoPlay_Slider.class.getName()));
				} 
				catch (com.liferay.portal.kernel.exception.SystemException e1) {
					  _log.error(e1.getMessage());
				}
			}
			try {
				Autopla_Slider.setUserId(userID);
				Autopla_Slider.setAutoPlay(autoPlay_ON);
				AutoPlay_SliderLocalServiceUtil.updateAutoPlay_Slider(Autopla_Slider);
			} 
			catch (SystemException e) {
				_log.error(e.getMessage()); 
			}
		 } 
}
