package com.podengine.portal.util.constants;

/**
 * @author Syed Ali
 */
public class PlayerConstants {
	
	public static final String PLAY  = "play";
	
	public static final String PLAY_CAPITALISED  = "PLAY";

}
