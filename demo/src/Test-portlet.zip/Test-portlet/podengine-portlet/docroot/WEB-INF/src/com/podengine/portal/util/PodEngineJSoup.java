/*package com.podengine.portal.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.SortedSet;
import java.util.TreeSet;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.podengine.portal.util.PodEngineUtil;

public class PodEngineJSoup {
	
	private static Log _log = LogFactoryUtil.getLog(PodEngineJSoup.class);
	static int haveChannels = 0;
	static int haveNoChannels = 0;
	static int errored = 0;
	static int count=0;
	static long itemFound=0;
	static long itemNotFound=0;
	static boolean linksFoundFlag=false;
	static SortedSet<Integer> linksFound=new TreeSet<Integer>();
	static SortedSet<Integer> linksNotFound=new TreeSet<Integer>();
	static SortedSet<Integer> redirectedlinksFoundRSS=new TreeSet<Integer>();
	static SortedSet<Integer> redirectedlinksNotRequiredFoundRSS=new TreeSet<Integer>();
	static String tempLink = null;
	static String tempRedirectLink = null;
	static long mp3LinksCount = 0;
	static long nonMP3LinksCount = 0;
	

	public static void main(String[] args) {
		readTextFile("D:\\tahir.txt");
	}
	
	public static String readTextFile(String path) {
		 haveChannels = 0;
		haveNoChannels = 0;
		count=0;
		
		String returnString="";
		BufferedReader br = null;
		try {
			String sCurrentLine;
			br = new BufferedReader(new FileReader(path));
			
			while ((sCurrentLine = br.readLine()) != null) {
					returnString+=sCurrentLine;
					count++;
					JSoupScrap(sCurrentLine.trim());
			}
		
			_log.info("Total : " + count + ", haveChannels : " + haveChannels
					+ ", haveNoChannels : " + haveNoChannels + ", errored : "
					+ errored + ", itemFound : " + itemFound
					+ ", itemNotFound : " + itemNotFound + ", linksFound : "
					+ linksFound.size() + ", linksNotFound : "
					+ linksNotFound.size()
					+ ", redirectedlinksNotRequiredFoundRSS : "
					+ redirectedlinksNotRequiredFoundRSS.size()
					+ ", redirectedlinksFoundRSS : "
					+ redirectedlinksFoundRSS.size() + ", mp3Count : "
					+ mp3LinksCount + ", nonMP3Count : " + nonMP3LinksCount);

		} catch (IOException e) {
			_log.error(e.getMessage());
		} finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				_log.info("IOException In file : "+ex.getMessage());
			}
		}
		return returnString;
	}

	public static void JSoupScrap(String URL) {
		try {
			Connection connection = Jsoup.connect(URL);
			Document document = Jsoup.connect(URL).get();
			Elements channel = document.getElementsByTag("channel");
		if(channel.isEmpty())
		{
			haveNoChannels++;
			//System.out.println("DONT HAVE CHANNELS : "+count);
		}
		else
		{
			haveChannels++;
			checkItems(channel);
			
			linksFoundFlag = false;
			//System.out.println(" YES HAVE CHANNELS : "+count);
		}
		} 
		
		catch(IllegalArgumentException ie){
			_log.error("PE Error : "+ie.getMessage());
			errored++;
		}

		catch (MalformedURLException e) {
			_log.error("PE Error : "+e.getMessage());
			errored++;
		}
		catch (IOException e) {
			_log.error("PE Error : "+e.getMessage());
			errored++;
		}
	}

	private static void checkItems(Elements channel) {
		Elements items =null;
		for (Element element : channel) {
			 items = element.getElementsByTag("item");
			
			if(items.isEmpty())
			{
				itemNotFound++;
				//System.out.println("DONT HAVE ITEMS : "+count);
			}
			else
			{
				itemFound++;
				//System.out.println("YES HAVE ITEMS : "+count);
				fetchFromItems(items);
			}
			items =null;
		}
	}

	private static void fetchFromItems(Elements items) {
		for (Element item : items) {
			Elements links = item.getElementsByTag("link");
			if(!links.isEmpty()){
			for (Element link : links) {
				tempLink = link.text();
				tempRedirectLink = PodEngineUtil.getRedirectURL(tempLink.trim());
				if(!tempRedirectLink.equals(link.text().trim())){
					redirectedlinksFoundRSS.add(new Integer(count));
				}
				else
				{
					redirectedlinksNotRequiredFoundRSS.add(new Integer(count));
				}
				//System.out.println(""+link.text());
			linksFound.add(new Integer(count));
			if(tempLink.endsWith("mp3")){
				mp3LinksCount++;
			}
			else{
				nonMP3LinksCount++;
			}
			}
			}
			else{
				//System.out.println("*****Have No Links!!!!*****");
				linksNotFound.add(new Integer(count));
			}
		
			
			_log.info("RSS : 230/" + count + ", Channels : " + haveChannels
					+ ", No Channels : " + haveNoChannels + ", errored : "
					+ errored + ", item : " + itemFound
					+ ", No item : " + itemNotFound+errored + ", links : "
					+ linksFound.size() + ", No Links : "
					+ linksNotFound.size()+errored
					+ ", DirectLink+Errored : "
					+ redirectedlinksNotRequiredFoundRSS.size()+errored
					+ ", Redirected links : "
					+ redirectedlinksFoundRSS.size() + ", mp3Count : "
					+ mp3LinksCount + ", nonMP3Count : " + nonMP3LinksCount);
		}
	}
}
*/