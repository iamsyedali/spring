package com.podengine.portlet.user;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;

import javax.imageio.ImageIO;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletContext;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.portlet.bind.annotation.ActionMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;
import org.springframework.web.portlet.bind.annotation.ResourceMapping;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.upload.UploadPortletRequest;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.Image;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.asset.model.AssetEntry;
import com.liferay.portlet.asset.model.AssetVocabulary;
import com.liferay.portlet.asset.service.AssetEntryLocalServiceUtil;
import com.liferay.portlet.asset.service.AssetVocabularyLocalServiceUtil;
import com.podengine.portal.util.PodEngineUtil;
import com.podengine.portal.util.constants.ActionKeys;
import com.podengine.portal.util.constants.CMD;
import com.podengine.portal.util.constants.POPUP_ID;
import com.podengine.portal.util.constants.RenderKeys;
import com.podengine.portal.util.constants.ResourceKeys;
import com.podengine.service.NoSuchPodJockeyException;
import com.podengine.service.NoSuchPodJockeyPlayListException;
import com.podengine.service.NoSuchprivatePodJockeyException;
import com.podengine.service.model.PodJockey;
import com.podengine.service.model.PodJockeyPlayList;
import com.podengine.service.model.privatePodJockey;
import com.podengine.service.model.impl.privatePodJockeyImpl;
import com.podengine.service.service.PodJockeyLocalServiceUtil;
import com.podengine.service.service.PodJockeyPlayListLocalServiceUtil;
import com.podengine.service.service.privatePodJockeyLocalServiceUtil;

@Controller
@RequestMapping({"VIEW"})
public class PodJockeyController {
 
	private static Log _log = LogFactoryUtil.getLog(PodJockeyController.class);
	private static final String VIEW_JSP = "view";
	private static final String MY_PODJOCKEY = "my-podJockey";
	private static final String BE_PODJOCKEY = "be-a-podJockey";
	private static final String DELETE_PODJOCKEY = "delete-podJockey";
	private static final String SHOW_ACCESS_CODE = "show-access-code";
	private static final String ACCESS_CODE = "access-code";
	private static final String MANAGE_JSP = "manage";
	private static final String VIEW_SELECTED_PLAYLIST = "view-selected-list";
	private static final String PODJOCKEY_DESCRIPTION = "podjockey-description";
	private static final String SHOW_PODJOCKEY_PODCASTS = "show-podjockey-podcasts";
	
	@ActionMapping
	public void defaultAction(ActionRequest request, ActionResponse actionResponse) {
		_log.info("Default Action.....");
	}
	
	@RenderMapping
	  public String defaultRender(RenderRequest renderRequest, RenderResponse renderResponse) {
		 _log.info("Default Render for PodJockey.....");
		 ThemeDisplay themeDispaly= (ThemeDisplay)renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		 String action = ParamUtil.getString(renderRequest, "action");
		 
		 if(action.equals(RenderKeys.MY_PODJOCKEY)){
			try {
				List<PodJockey> podJockeys = PodJockeyLocalServiceUtil.findPodjockiesByUserId(themeDispaly.getUserId());
				renderRequest.setAttribute("podJockeys", podJockeys);
			} catch (SystemException e) {
				_log.error("Error is getting while fetching podjockey list");
			}
			 
			 return MY_PODJOCKEY;
		 }
		 else if(action.equals(RenderKeys.BE_PODJOCKEY)){
			 try {
				AssetVocabulary vocab = AssetVocabularyLocalServiceUtil.getGroupVocabulary(themeDispaly.getCompanyGroupId(), "Podengine Categories");
				renderRequest.setAttribute("vocab", vocab.getVocabularyId());
			} catch (PortalException | SystemException e) {
				_log.error("error while getting vocabulary id : "+e.getMessage());
			}
			 return BE_PODJOCKEY;
			 
		 }else if(action.equals(RenderKeys.DELETEPODJEOCKEY_POPUP)){
			 long podJockeyId = ParamUtil.getLong(renderRequest, "podJockeyId");
			 PodJockey podJockey = null;
			 try {
				 podJockey = PodJockeyLocalServiceUtil.getPodJockey(podJockeyId);
				 renderRequest.setAttribute("podJockey", podJockey);
			} catch (PortalException | SystemException e) {
				_log.error("While getting podjockey  " + e.getMessage());
			}
			 return DELETE_PODJOCKEY;
			 
		 }else if(action.equals(RenderKeys.DELETE_PODJOCKEY)){
			 ThemeDisplay themeDisplay= (ThemeDisplay)renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
			 long podjockeyId = ParamUtil.getLong(renderRequest, "podJockeyId");
			 try {
				PodJockeyLocalServiceUtil.deletePodJockey(podjockeyId);
				AssetEntryLocalServiceUtil.deleteEntry(PodJockey.class.getName(), podjockeyId);
				List<privatePodJockey> privatePodJockeyLists = privatePodJockeyLocalServiceUtil.searchByPodJockeyId(podjockeyId);
				if(!privatePodJockeyLists.isEmpty()){
					for(privatePodJockey privatePodJockeyList:privatePodJockeyLists){
						privatePodJockeyLocalServiceUtil.deleteprivatePodJockey(privatePodJockeyList);
					}
				}
				List<PodJockeyPlayList> podJockeyPlayLists= PodJockeyPlayListLocalServiceUtil.findByPodJockeyId(podjockeyId);
					for(PodJockeyPlayList podJockeyPlayList:podJockeyPlayLists){
						PodJockeyPlayListLocalServiceUtil.deletePodJockeyPlayList(podJockeyPlayList);
					}
				
				List<PodJockey> podJockeys = PodJockeyLocalServiceUtil.findPodjockiesByUserId(themeDispaly.getUserId());
				renderRequest.setAttribute("podJockeys", podJockeys);
				renderRequest.setAttribute("closePOPUPID", POPUP_ID.DELETE_PODJOCKEY);
				
			} catch (PortalException | SystemException e) {
				_log.error("Erro While deleting Podjockey");
			}
			 return MY_PODJOCKEY;
			 
		 }else if(action.equals(RenderKeys.SHOW_ACCESS_CODE)){
			 long podJockeyId = ParamUtil.getLong(renderRequest, "podJockeyId");
			 PodJockey podJockey = null;
			 try {
				 podJockey = PodJockeyLocalServiceUtil.getPodJockey(podJockeyId);
				renderRequest.setAttribute("podJockey", podJockey);
			} catch (PortalException | SystemException e) {
				_log.error("While getting podjockey  " + e.getMessage());
			}
			 return SHOW_ACCESS_CODE;
			 
		 }else if(action.equals(RenderKeys.ACCESS_CODE)){
			 
			 return ACCESS_CODE;
		 }else if(action.equals(RenderKeys.MANAGE_PODJOCKEY)){
			 
			 return MANAGE_JSP;
		 }else if(action.equals(RenderKeys.VIEW_SELECTED_PLAYLIST)){
			 
			 return VIEW_SELECTED_PLAYLIST;
		 }else if(action.equals(RenderKeys.PODJOCKEY_DESCRIPTION)){
			 
			 return PODJOCKEY_DESCRIPTION;
		 }else if(action.equals(RenderKeys.DELETE_PRIVATE_PODJOCKEY)){
			long privatePodJockeyId = ParamUtil.getLong(renderRequest, "privatePodJockeyId");
		 try {
			 _log.info("private podjockey deleting");
			privatePodJockey podJockeyId = privatePodJockeyLocalServiceUtil.fetchprivatePodJockey(privatePodJockeyId);
			privatePodJockeyLocalServiceUtil.deleteprivatePodJockey(podJockeyId);
			} catch (SystemException | NullPointerException e) {
				_log.error("SystemException error And nullPointerException  "+e.getMessage());
			}
			 return VIEW_JSP;
		 	}else if(action.equals(RenderKeys.SHOW_PODJOCKEY_PODCASTS)){
		 		
		 		return SHOW_PODJOCKEY_PODCASTS;
		 	}
		 
		 return VIEW_JSP;
	 }
	
	@ActionMapping(params = CMD.ACTION+StringPool.EQUAL+ActionKeys.ADD_BE_PODJOCKEY)
	public void addBePodJockey(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException {
		ThemeDisplay themeDisplay= (ThemeDisplay)actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		UploadPortletRequest uploadRequest=PortalUtil.getUploadPortletRequest(actionRequest);
		
		 String nameOfPodJockey=ParamUtil.getString(uploadRequest, "nameOfPodJockey");
		 File file= uploadRequest.getFile("image");
		 String accessType=ParamUtil.getString(uploadRequest, "accessType");
		 String accessCode=ParamUtil.getString(uploadRequest, "accessCode");
		 String country=ParamUtil.getString(uploadRequest, "country");
		 String state=ParamUtil.getString(uploadRequest, "state");
		 String city=ParamUtil.getString(uploadRequest, "city");
		 String description=ParamUtil.getString(uploadRequest, "description");
		 
		 PodJockey podjockey=null;
		 
		 try {
		 podjockey = PodJockeyLocalServiceUtil.createPodJockey(CounterLocalServiceUtil.increment(PodJockey.class.getName()));
		 podjockey.setUserId(themeDisplay.getUserId());
		 podjockey.setNameOfPodJockey(nameOfPodJockey);
		 if(file.length()!=0){
		 podjockey.setImage(PodEngineUtil.convertBlobToString(PodEngineUtil.convertfileToBlob(file)));
		 }else{
			URL url=new URL(themeDisplay.getPathThemeImages() + "/podengine-images/profile-default.png");
			podjockey.setImage(PodEngineUtil.convertBlobToString(PodEngineUtil.convertfileToBlob(url.openStream())));
		 }
		 podjockey.setAccessType(accessType);
		 podjockey.setAccessCode(accessCode);
		 podjockey.setCountry(country);
		 podjockey.setState(state);
		 podjockey.setCity(city);
		 podjockey.setDescription(description);
		 podjockey.setCompanyId(themeDisplay.getCompanyId());
		 podjockey.setGroupId(themeDisplay.getScopeGroupId());
		 
			PodJockeyLocalServiceUtil.addPodJockey(podjockey);
			SessionMessages.add(actionRequest, "success");
			actionRequest.setAttribute("closePOPUPID", POPUP_ID.BE_PODJOCKEY_POPUP);
			actionResponse.setRenderParameter("action", "myPodJockey");
			
		} catch (SystemException e) {
			_log.error("Erro while creating podjockey");
		} catch (SQLException e) {
			_log.error(e.getMessage());
		}
			
		 String categoryIds = StringPool.BLANK;
			AssetVocabulary vocab = null;;
			try {
				 vocab = AssetVocabularyLocalServiceUtil.getGroupVocabulary(themeDisplay.getCompanyGroupId(), "Podengine Categories");
				 categoryIds = ParamUtil.getString(uploadRequest,"assetCategoryIds_"+vocab.getVocabularyId());
				 String[] cats = StringUtil.split(categoryIds, ",");
				 long categs [] = new long [cats.length];
				for (int i = 0; i < cats.length; i++) {
					categs[i] = Long.parseLong(cats[i]);
				}
				
			AssetEntry assetEntry = AssetEntryLocalServiceUtil.updateEntry(themeDisplay.getUserId(), themeDisplay.getScopeGroupId(), PodJockey.class.getName(),
					podjockey.getPodJockeyId(), categs, null);
			assetEntry.setVisible(true);
			AssetEntryLocalServiceUtil.updateAssetEntry(assetEntry);
			} catch (PortalException | SystemException e) {
				_log.error("Error While Adding Catgeories : "+e.getMessage());
			}
			
	}
	
	@ActionMapping(params = CMD.ACTION+StringPool.EQUAL+ActionKeys.PRIVATE_ACCESS)
	public void privateAccessCode(ActionRequest actionRequest,
			ActionResponse actionResponse) throws SystemException {
		ThemeDisplay themeDisplay= (ThemeDisplay)actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		try
		{ 
			actionRequest.setAttribute("closePOPUPID", POPUP_ID.ACCESS_CODE);
		    String accessCode = ParamUtil.getString(actionRequest, "privateAccessCode");
		    _log.info("accessCode----"+accessCode);
		    PodJockey privatepodJockey = PodJockeyLocalServiceUtil.searchByAccessCode(accessCode);
		    long podJockeyId = privatepodJockey.getPodJockeyId();
		    List<privatePodJockey> validatePrivatePodJockey=privatePodJockeyLocalServiceUtil.getprivatePodJockeies(-1, -1);
		    _log.info("validatePrivatePodJockey------------"+validatePrivatePodJockey);
		    boolean booleanPrivatePodJockey=false;
			for(privatePodJockey checkPrivatePodJockey:validatePrivatePodJockey)
			{
				if(checkPrivatePodJockey.getAccessCode()==accessCode&&PortalUtil.getUserId(actionRequest)==checkPrivatePodJockey.getUserId())
				{
					booleanPrivatePodJockey=true;
				}
			}
			if(booleanPrivatePodJockey==true)
			{
				  actionRequest.setAttribute("privatePodJockeyExists", "privatePodJockeyExists");
				  actionRequest.setAttribute("closePOPUPID", POPUP_ID.ACCESS_CODE);
			}
			else
			{
				
				privatePodJockey privatePodJockeyId = privatePodJockeyLocalServiceUtil.searchByPodJockeyIdAndUserId(podJockeyId, themeDisplay.getUserId());
			    if(privatePodJockeyId == null && privatepodJockey.getUserId() != themeDisplay.getUserId()){
				privatePodJockey privatepdJockey=new privatePodJockeyImpl();
				
				privatepdJockey.setPrivatePodJockeyId(CounterLocalServiceUtil.increment(privatePodJockey.class.getName()));
				privatepdJockey.setPodJockeyId(podJockeyId);
				privatepdJockey.setAccessCode(accessCode);
				privatepdJockey.setUserId(PortalUtil.getUserId(actionRequest));
				
				privatePodJockeyLocalServiceUtil.updateprivatePodJockey(privatepdJockey);
				actionRequest.setAttribute("closePOPUPID", POPUP_ID.ACCESS_CODE);
			    }else{
			    SessionErrors.add(actionRequest, "errorPriavtePodjockeyAlreadyAdded");
			    SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
			    actionResponse.setRenderParameter(CMD.ACTION, RenderKeys.ACCESS_CODE);
			    }
			}
		}
		catch (NoSuchPodJockeyException e)
		{
			SessionErrors.add(actionRequest, "NoSuchPrivatePodjockey");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
			actionResponse.setRenderParameter(CMD.ACTION, RenderKeys.ACCESS_CODE);
		} 
		 
	}
	
	@ResourceMapping(value=ResourceKeys.GENERATE_CODE)
	public void generateCode(ResourceRequest resourceRequest, ResourceResponse resourceResponse) {
		ThemeDisplay themeDisplay=(ThemeDisplay)resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);
		JSONObject jsonObj2=null;
		try{
		String code=String.valueOf(CounterLocalServiceUtil.increment(PodJockey.class.getClass().toString(), 1));
		String s=new String(String.valueOf(themeDisplay.getUserId()));
		String str=s.concat(code);
		jsonObj2=JSONFactoryUtil.createJSONObject();
		jsonObj2.put("accessCode", str);
		resourceResponse.getWriter().write(jsonObj2.toString());
		}
		catch(SystemException | IOException e){
			_log.error(e.getMessage());
		}
	}
	
	
	@ResourceMapping(value=ResourceKeys.CHECK_PLAYLIST)
	public void checkPodJockeyPlayList(ResourceRequest resourceRequest, ResourceResponse resourceResponse) {
		ThemeDisplay themeDispaly= (ThemeDisplay)resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);
		
		long podcastId = ParamUtil.getLong(resourceRequest, "podcastId");
		long podJockeyId = ParamUtil.getLong(resourceRequest, "podJockeyId");
		
		try {
			PodJockeyPlayList podJockeyPlayList = PodJockeyPlayListLocalServiceUtil.createPodJockeyPlayList(CounterLocalServiceUtil.increment(PodJockeyPlayList.class.getName()));
			podJockeyPlayList.setPodJockeyId(podJockeyId);
			podJockeyPlayList.setPodcastId(podcastId);
			podJockeyPlayList.setUserId(themeDispaly.getUserId());
			PodJockeyPlayListLocalServiceUtil.addPodJockeyPlayList(podJockeyPlayList);
		} catch (SystemException e) {
			_log.error("Error SystemException "+e.getMessage());
		}
	}
	
	
	@ResourceMapping(value=ResourceKeys.UNCHECK_PLAYLIST)
	public void unCheckPodJockeyPlayList(ResourceRequest resourceRequest, ResourceResponse resourceResponse) {
		ThemeDisplay themeDisplay= (ThemeDisplay)resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);
		
		long podcastId = ParamUtil.getLong(resourceRequest, "podcastId");
		long podJockeyId = ParamUtil.getLong(resourceRequest, "podJockeyId");
		
		try {
			PodJockeyPlayList podJockeyPlayList = PodJockeyPlayListLocalServiceUtil.findByPodJockeyIdAndUserIdAndPodcastId(podJockeyId, themeDisplay.getUserId(), podcastId);
			PodJockeyPlayListLocalServiceUtil.deletePodJockeyPlayList(podJockeyPlayList);
		} catch (NoSuchPodJockeyPlayListException | SystemException e) {
			_log.error("Error NoSuchPodJockeyPlayListException | SystemException "+e.getMessage());
		}
	}
	
}
