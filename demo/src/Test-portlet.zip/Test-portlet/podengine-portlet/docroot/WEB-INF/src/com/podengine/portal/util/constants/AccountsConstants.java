package com.podengine.portal.util.constants;

/**
 * @author Syed Ali
 */
public class AccountsConstants {
	
	public static final String PODENGINE_ACCOUNTTYPE_ID= "pod_accountType_id";
	
	public static final String ACCOUNT_TYPE = "Account Type";

	public static final String WATCH_AND_LISTEN = "Watch And Listen";

	public static final String COMMERCIALS_FREE = "Commercials Free";

	public static final String BE_A_PODJOCKEY = "Be A Pod Jockey";

	public static final String HOST_OWN_PODCAST = "Host Own Podcast";

	public static final String UNLIMITED_POSTING = "Unlimited Posting";

	public static final String ACCESS_TO_TOTAL_PODENGINE = "Access To Total Podengine";

	public static final String SHARE_CONTENT = "Share Content";

	public static final String MONTHLY = "Monthly";

	public static final String QUARTERLY = "Quarterly";

	public static final String HALF_YEARLY = "halfYearly";
	public static final String YEARLY = "yearly";
	public static final String UNLIMITED = "Unlimited";
	

	
/*********************************************************	
	USER ACCOUNT TYPES 
*********************************************************/
	
	public static final String FREE_ACCOUNT = "Free Account";
	
	public static final String PRO_ACCOUNT = "Pro Account";
	
	public static final String PREMIUIM_ACCOUNT = "Premium Account";
	
	public static final String VALUE_ACCOUNT = "Value Account";
	
	public static final String PODENGINE_ROLES= "system.roles";
	
	public static final String ACCORDIAN_COUNT = "One,Two,Three,Four,Five,Six,Seven,Eight,Nine,Ten";
	
	public static final String CUSTOM_FIELD_TABLE_NAME = "CUSTOM_FIELDS";
	
	public static final String[] PERIOD_NAMES= {"Monthly","Quarterly","Half Yearly","Yearly"};
	
	public static final String SELECTED_ROLE ="selectedRole";
	
	public static final String SUBSCRIPTION_ACCOUNT = "accountType";
	public static final String SUBSCRIPTION_VALIDITY = "accountValidity";
	public static final String SUBSCRIPTION_PERIOD = "subscriptionType";

}
