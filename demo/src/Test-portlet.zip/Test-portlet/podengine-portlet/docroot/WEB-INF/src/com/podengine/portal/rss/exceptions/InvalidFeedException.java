package com.podengine.portal.rss.exceptions;

public class InvalidFeedException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidFeedException(String message, Throwable throwable) {
		super(message, throwable);
	}
}
