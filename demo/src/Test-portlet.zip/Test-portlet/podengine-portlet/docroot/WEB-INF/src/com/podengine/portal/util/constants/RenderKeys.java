package com.podengine.portal.util.constants;
/**
 * @author Syed Ali
 */
public class RenderKeys {
	
	public static final String ADD_EDIT_ROLE = "ADD_EDIT_ROLE";

	public static final String RSS_FEED="rssFeed";
	public static final String EPISODES="episodes";
	public static final String ADD_PLAYLIST="Addplaylist";
	public static final String DELETE_MYCONTENT="deletemycontent";
	public static final String ADD_RSS =  "addRss";
	public static final String EDIT_RSS_FEED =  "editRSS";
	public static final String DELETE_RSS_FEED_POPUP =  "deleteRssPopUp";
	public static final String EPISODES_CONTENT = "episodesContent";
	public static final String UPDATE_USER_ROLE = "updateUserRole";
	public static final String RSS_FEED_CONTENT = "rssFeedContent";
	public static final String CATEGORY_CONTENT = "categoryContent";
	public static final String SUB_CATEGORY_CONTENT = "subCategoryContent";
	public static final String GRANDSUB_CATEGORY_CONTENT = "grandSubCategoryContent";
	public static final String DELETE_PLAYLIST="deleteplaylist";
	
	public static final String BE_PODJOCKEY="bePodJockey";
	public static final String ACCESS_CODE="accessCode";
	public static final String SHOW_ACCESS_CODE="showAccessCode";
	public static final String DELETEPODJEOCKEY_POPUP="deletePodJockeyPopUp";
	public static final String MY_PODJOCKEY="myPodJockey";
	public static final String MANAGE_PODJOCKEY="manage";
	public static final String DELETE_PODJOCKEY = "deletePodJockey";
	public static final String VIEW_SELECTED_PLAYLIST="view-selected-playList";
	public static final String PODJOCKEY_DESCRIPTION="podJockey-description";
	public static final String DELETE_PRIVATE_PODJOCKEY="delete-private-podJockey";
	public static final String SHOW_PODJOCKEY_PODCASTS ="show-podjockey-podcasts";
	
	
	public static final String POST="posting";
	public static final String HOST="hosting";
	
}
