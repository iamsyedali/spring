package com.podengine.portal.util;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.util.Iterator;
import java.util.List;

import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;

import com.beaglebuddy.id3.pojo.AttachedPicture;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.FileUtil;


public class RequiredCodeSnippets {

	private static Log _log = LogFactoryUtil.getLog(RequiredCodeSnippets.class);
public static int getDurationValue(String durationString) {
	int hour = 0,min = 0,sec=0,value=0;
	if(durationString != null){
	String dur[]=durationString.split(":");
	if(dur.length == 3){
	 hour=Integer.parseInt(dur[0]);
	 min=Integer.parseInt(dur[1]);
	 sec=Integer.parseInt(dur[2]);
	 value=(hour*3600)+(min*60)+(sec);
	}
	if(dur.length == 2){
		 min=Integer.parseInt(dur[0]);
		 sec=Integer.parseInt(dur[1]);
		 value=(min*60)+(sec);
	}
	if(!durationString.contains(":")){
		 value= Integer.parseInt(durationString);
	}
	} 
	 return value;
}

public static String getDurationString(long value) {

	long seconds=value;
	String hrStr = "";
	  long hr = (int)(seconds/3600);
	  long rem = (int)(seconds%3600);
	  long mn = rem/60;
	  long sec = rem%60;
	  if(hr != 0){
		  hrStr = (hr<10 ? "0" : "")+hr+":";
	  }
	  String mnStr = (mn<10 ? "0" : "")+mn;
	  String secStr = (sec<10 ? "0" : "")+sec; 
	  String res=hrStr+mnStr+":"+secStr;
	  return res;
}

public static String addDuartion(String x, String y) {
	int val1=0, val2=0;
	val1=getDurationValue(x);
	val2=getDurationValue(y);
	return getDurationString(val1+val2);
}


public static String substractDuartion(String x, String y) {
	int val=getDurationValue(x)-getDurationValue(y);
	return getDurationString(val);
}

	public static String fixDurationStringLength(String badString) {
		String res = "";
		int count = 0;
		for (int i = 0; i < badString.length() - 1; i++) {
			if (badString.charAt(i) == ':')
				count += 1;
		}
		if (count == 1) {
			res = "00:" + badString;
		} else if (count == 0) {
			res = "00:00:" + badString;
		} else
			res = badString;
		return res;
	}

public static String readTextFile(String path) {
	String returnString="";
	BufferedReader br = null;
	try {
		String sCurrentLine;
		br = new BufferedReader(new FileReader(path));
		while ((sCurrentLine = br.readLine()) != null) {
				returnString+=sCurrentLine;
		}
	} catch (IOException e) {
		_log.error(e.getMessage());
	} finally {
		try {
			if (br != null)br.close();
		} catch (IOException e) {
			_log.error(e.getMessage());
		}
	}
	return returnString;
}
public static String parseCategories(String categories[]) {
	StringBuilder category = new StringBuilder();
	for (int i = 0; i < categories.length; i++) {
		category.append(categories[i].toString() + ",");
	}

	return category.toString();

}

public static File getAlbumArt(String url) throws IOException {

	File file = null;
	try {
		com.beaglebuddy.mp3.MP3 mp3 = new com.beaglebuddy.mp3.MP3(new URL(url));
		if (!mp3.getPictures().isEmpty()) {
			List<AttachedPicture> pics = mp3.getPictures();
			pics.iterator();
			for (AttachedPicture attachedPicture : pics) {
				byte[] atpic = attachedPicture.getImage();
				ByteArrayInputStream bis = new ByteArrayInputStream(atpic);
				Iterator<?> readers = ImageIO.getImageReadersByFormatName("jpg");
				ImageReader reader = (ImageReader) readers.next();
				Object source = bis;
				ImageInputStream iis = ImageIO
						.createImageInputStream(source);
				reader.setInput(iis, true);
				ImageReadParam param = reader.getDefaultReadParam();
				Image image = reader.read(0, param);
				BufferedImage bufferedImage = new BufferedImage(
						image.getWidth(null), image.getHeight(null),
						BufferedImage.TYPE_INT_RGB);
				Graphics2D g2 = bufferedImage.createGraphics();
				g2.drawImage(image, null, null);

				// convert buffrered image to byte array
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				ImageIO.write(bufferedImage, "jpg", baos);
				baos.flush();
				byte[] bytes = baos.toByteArray();
				 file = FileUtil.createTempFile(bytes);
				baos.close();
			}
		} 
		
		else
			_log.info("No Album Art Present in the MP3 File");
	} catch (IOException e) {
		_log.error(e.getMessage());
	} 
	return file;
}

public static long getCurrentEpochTime() {
	return System.currentTimeMillis()/1000;
}

	public static long humanTimeToEpoch() {
		long epoch = 0;
		try {
			epoch = new java.text.SimpleDateFormat("MM/dd/yyyy HH:mm:ss")
					.parse("01/01/1970 01:00:00").getTime() / 1000;
		} catch (ParseException e) {
			_log.error(e.getMessage());
		}
		return epoch;
	}

}
