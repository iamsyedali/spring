/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.podengine.service.service.impl;

import java.util.List;

import com.liferay.portal.kernel.exception.SystemException;
import com.podengine.service.NoSuchPodcastException;
import com.podengine.service.model.Podcast;
import com.podengine.service.service.base.PodcastLocalServiceBaseImpl;
import com.podengine.service.service.persistence.PodcastUtil;

/**
 * The implementation of the podcast local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.podengine.service.service.PodcastLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author shamshuddin
 * @see com.podengine.service.service.base.PodcastLocalServiceBaseImpl
 * @see com.podengine.service.service.PodcastLocalServiceUtil
 */
public class PodcastLocalServiceImpl extends PodcastLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.podengine.service.service.PodcastLocalServiceUtil} to access the podcast local service.
	 */
	
	public List<Podcast> findPodcastByRSSFeedId(long RSSFeedId) throws SystemException{
		return podcastPersistence.findByRSSFeedId(RSSFeedId);
	}
	public Podcast findByPodCastRecentPublistDate(long PodcastPublishDate) throws NoSuchPodcastException, SystemException
	{
		return PodcastUtil.findByPodCastRecentPublistDate(PodcastPublishDate);
	}
	public List<Podcast> findPodcastByPoscastIds(long[] PodcastIds) throws SystemException
	{
		return PodcastUtil.findByPodcastId(PodcastIds);
	}
	
	public Podcast findPodcastByPodcastURLFromXML(String PodcastURLFromXML) throws SystemException
	{
		return PodcastUtil.fetchByPodcastURLFromXML(PodcastURLFromXML);
	}
 }