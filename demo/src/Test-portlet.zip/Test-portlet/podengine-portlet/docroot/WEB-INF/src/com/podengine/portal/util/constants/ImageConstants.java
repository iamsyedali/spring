package com.podengine.portal.util.constants;

/**
 * @author Syed Ali
 */
public class ImageConstants extends com.liferay.portal.model.ImageConstants {
public static String[] DESCRIPTION;
public static String[] PODCAST_DESCRIPTION;
}
