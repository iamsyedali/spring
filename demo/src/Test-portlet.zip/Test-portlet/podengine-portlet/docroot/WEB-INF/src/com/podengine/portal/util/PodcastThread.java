package com.podengine.portal.util;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;

import org.dom4j.DocumentException;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.theme.ThemeDisplay;
import com.podengine.portal.rss.exceptions.MalformedFeedException;
import com.podengine.portal.rss.model.Episode;
import com.podengine.portal.rss.model.RSSFeedXML;
import com.podengine.portal.util.constants.ImageConstants;
import com.podengine.service.model.Podcast;
import com.podengine.service.model.RSSfeed;
import com.podengine.service.service.PodcastLocalServiceUtil;

public class PodcastThread extends Thread {
	private static Log _log = LogFactoryUtil.getLog(PodcastThread.class);
	private static String rssFeedUrl = null;
	private static RSSfeed rssFeed = null;
	public static ThemeDisplay themeDispaly;

	@SuppressWarnings("static-access")
	public PodcastThread(RSSfeed rssFeed) {
		rssFeedUrl = rssFeed.getFeedURL();
		this.rssFeed = rssFeed;
	}

	@Override
	public void run() {
		
		try {
			Thread.currentThread();
			Thread.sleep(2000);
			_log.info("-------thread Strted-------");
			try {
				RSSFeedXML xmlFeed = new RSSFeedXML(new URL(rssFeedUrl));
				rssFeed = PodEngineUtil.parseFeedXML(rssFeed, xmlFeed);
				List<Episode> episodes = xmlFeed.getEpisodes();

				_log.info("The Episodes Size Is : " + episodes.size());

				int count = 0;
				for (Episode episode : episodes) {
					count++;
					_log.info("Eisodes : "+episodes.size()+"/"+count+" , Title : "+episode.getTitle()+" , rssFeed : "+rssFeed.getFeedURL());
					/*_log.info("Title " + episode.getTitle());
					_log.info("PodcastURLFromXML " + episode.getLink());
					_log.info("PODcat URL: "+ PodEngineUtil.getRedirectURL(episode.getLink().toString()));
					_log.info("getDuration "+ RequiredCodeSnippets.getDurationValue(episode.getDuration()));
					_log.info("getImageLink "+ RequiredCodeSnippets.getAlbumArt(episode.getLink().toString()));
					_log.info("getPubDate " + episode.getPubDate());
					_log.info("Type " + episode.getCategories());
					_log.info("getDescription " + episode.getDescription());
					_log.info("getAuthor " + episode.getAuthor());
					_log.info("getSourceLink " + episode.getSourceLink());
					_log.info("getGuid " + episode.getGuid());
					_log.info("EncodedContent " + episode.getEncodedContent());
					_log.info("sourceLink " + episode.getSourceLink());
					_log.info("rssFeed " + rssFeed.getFeedURL());
					_log.info("getRssfeedId " + rssFeed.getRssfeedId());
					_log.info("PodcastSize " + episode.getMediaLength());
					_log.info("getImageLink " + episode.getImageLink());*/
					Podcast podcast = null;
					try {
						podcast = PodcastLocalServiceUtil.findPodcastByPodcastURLFromXML(episode.getLink().toString());
						
						if(Validator.isNull( podcast )){
							podcast = PodcastLocalServiceUtil.createPodcast(CounterLocalServiceUtil.increment(Podcast.class.getName()));
						}
						
					} catch (SystemException e1) {
						_log.error(e1.getMessage());
					}
					podcast.setPodcastURL(PodEngineUtil.getRedirectURL(episode.getLink().toString()));
					podcast.setPodcastURLFromXML(episode.getLink().toString());
					podcast.setPodcastTitle(episode.getTitle());
					podcast.setPodcastAuthor(episode.getAuthor());
					podcast.setFeedURL(rssFeed.getFeedURL());
					
					try{
					ImageConstants.PODCAST_DESCRIPTION=episode.getDescription().split("<");
					podcast.setPodcastDescription(ImageConstants.PODCAST_DESCRIPTION[0]);
					}catch(Exception e) {_log.error("Description Exception");}
					//podcast.setPodcastDescription(episode.getDescription()!=null?episode.getDescription().replace(episode.getDescription().substring(episode.getDescription().indexOf("<"), episode.getDescription().lastIndexOf(">")+1), " "):episode.getDescription());
					podcast.setRSSFeedId(rssFeed.getRssfeedId());
					podcast.setSourceLink((episode.getSourceLink() == null) ? null: episode.getSourceLink().toString());
					podcast.setPodcastSize(episode.getMediaLength());
					podcast.setEncodedContent(episode.getEncodedContent());
					podcast.setPodcastDuration(PodEngineUtil.getMediaDurationFromURL(PodEngineUtil.getRedirectURL(episode.getLink().toString())));
					podcast.setPodcastPublishDate(PodEngineUtil	.convertDateToUnixTimeStamp(episode.getPubDate()));
					if (episode.getImageLink() != null) {
						try {							
							podcast.setPodcastImage(PodEngineUtil.convertByteArrayToString(PodEngineUtil.compressImage(episode.getImageLink().toString())));
							podcast.setPodcastImageLink(episode.getImageLink().toString());							
						} catch (IOException e) {
							
							try {
								podcast.setPodcastImage(PodEngineUtil.convertBlobToString(PodEngineUtil.convertfileToBlob(new URL(themeDispaly.getPathThemeImages()+"/imageNotAvailable.png").openStream())));
								podcast.setPodcastImageLink(themeDispaly.getPathThemeImages()+"/imageNotAvailable.png");
							} catch (SQLException e1) {
								_log.error("image "+e1.getMessage());
							}
						}
					} 
					else 
					{
						if (episode.getImageLink() == null) {
							File file = PodEngineUtil.getAlbumArt(episode.getLink().toString());
							if (file != null) {
								try {
									podcast.setPodcastImage(PodEngineUtil.convertBlobToString(PodEngineUtil.convertfileToBlob(file)));
								} catch (SQLException e) {
									_log.error("image "+e.getMessage());
								}
							}
							else if (rssFeed.getImageURL() != null) {	
								try {							
									podcast.setPodcastImage(PodEngineUtil.convertByteArrayToString(PodEngineUtil.compressImage(rssFeed.getImageURL().toString())));
									podcast.setPodcastImageLink(rssFeed.getImageURL().toString());							
								} catch (IOException e) {
									
									try {
										podcast.setPodcastImage(PodEngineUtil.convertBlobToString(PodEngineUtil.convertfileToBlob(new URL(themeDispaly.getPathThemeImages()+"/imageNotAvailable.png").openStream())));
										podcast.setPodcastImageLink(themeDispaly.getPathThemeImages()+"/imageNotAvailable.png");
									} catch (SQLException e1) {
										_log.error("image "+e1.getMessage());
									}
								}					
								
							} 
							else {
								URL url = new URL(themeDispaly.getPathThemeImages()+"/imageNotAvailable.png");
								try {
									podcast.setPodcastImage(PodEngineUtil.convertBlobToString(PodEngineUtil.convertfileToBlob(url.openStream())));
								} catch (SQLException e) {
									_log.error("image "+e.getMessage());
								}
							}
						}
					}
					try {
						PodcastLocalServiceUtil.updatePodcast(podcast);
					} 
					catch (SystemException e) {
						_log.error("Error While Adding/Updating Podcast : "+ e.getMessage());
					}
				}

			} catch (IOException | MalformedFeedException | DocumentException e) {
				_log.error("Error While Adding Podcast : " + e.getMessage());
			}

		} catch (InterruptedException e) {
			_log.error(e.getMessage());
		}
		_log.info("-----Podcast Thread Completed Sucessfully-----");
		super.run();
	}
}
