package com.podengine.portal.util;

import com.liferay.portlet.BaseControlPanelEntry;

import com.liferay.portal.model.Group;
import com.liferay.portal.model.Portlet;
import com.liferay.portal.security.permission.PermissionChecker;

public class ControlPanelEntryHandler extends BaseControlPanelEntry{
	
	 @Override
	 public boolean hasAccessPermission(PermissionChecker permissionChecker, Group group, Portlet portlet) throws Exception {
	 if(group.isUser()){
		 return true;
	 }
	 return false;
	 }

}
