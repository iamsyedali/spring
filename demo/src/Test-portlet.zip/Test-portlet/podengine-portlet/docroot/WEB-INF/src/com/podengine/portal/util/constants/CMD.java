package com.podengine.portal.util.constants;

public class CMD {

	public static final String ACTION = "action";
}
