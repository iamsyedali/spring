package com.podengine.portlet.admin;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletRequest;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.Role;
import com.liferay.portal.model.User;
import com.liferay.portal.service.RoleLocalServiceUtil;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.expando.model.ExpandoTableConstants;
import com.liferay.portlet.expando.service.ExpandoValueLocalServiceUtil;
import com.podengine.portal.util.PodEngineUtil;
import com.podengine.portal.util.constants.AccountsConstants;
import com.podengine.portal.util.constants.PortletMode;
import com.podengine.service.model.PlayerTimeStamp;
import com.podengine.service.service.PlayerTimeStampLocalServiceUtil;

@Controller
@RequestMapping({PortletMode.VIEW})
public class SubscriptionsController {

	private static Log _log = LogFactoryUtil.getLog(SubscriptionsController.class);
	private static final String VIEW_JSP = "view";
	private static final String CHECKOUT_JSP = "checkout";
	
	private List<String> cookies;
	private HttpsURLConnection conn;
	private final String USER_AGENT = "Mozilla/5.0";
	
	private static String url = "https://sandbox.braintreegateway.com/login?_ga=1.5736432.2122169270.1453958782";
	
	static final String LOGON_SITE = "https://www.google.com";
    static final int    LOGON_PORT = 80;
    
    private static final String POST_CONTENT_TYPE = "application/x-www-form-urlencoded";
    private static final String LOGIN_USER_NAME_PARAMETER_NAME = "login";
    private static final String LOGIN_PASSWORD_PARAMETER_NAME = "password";
    private static final String LOGIN_ACTION_NAME = "/session";
    private static final String LOGIN_USER_NAME = "zaheershaik";
    private static final String LOGIN_PASSWORD = "zaheershaik7";
    
    private String website="https://sandbox.braintreegateway.com/merchants/3w5mmypsv6chmtym/transactions/new";


    private static final String TARGET_URL = "https://sandbox.braintreegateway.com/login?_ga=1.5736432.2122169270.1453958782/session";
	
	@RenderMapping
	public String defaultRender(RenderRequest renderRequest,
			RenderResponse renderResponse) {
		_log.info("Default Render.....");
		return VIEW_JSP;
	}
	
	@RenderMapping(params="action=renew")
	public String renew(RenderRequest request,
			RenderResponse response) {
		
		_log.info("Default Render.....");
		String cmd = ParamUtil.getString(request, "cmd");
		
		String currentAccountType;
		try {
			User user = PortalUtil.getUser(request);
			currentAccountType = (String) ExpandoValueLocalServiceUtil.getData(PortalUtil.getCompanyId(request), User.class.getName(), 
					ExpandoTableConstants.DEFAULT_TABLE_NAME, AccountsConstants.SUBSCRIPTION_ACCOUNT, user.getUserId());
			
			String currentSubscriptionPeriod = (String) ExpandoValueLocalServiceUtil.getData(PortalUtil.getCompanyId(request), User.class.getName(), 
					ExpandoTableConstants.DEFAULT_TABLE_NAME, AccountsConstants.SUBSCRIPTION_PERIOD, user.getUserId());
			_log.info("currentAccountType :" + currentAccountType);
			_log.info("currentSubscriptionPeriod :" + currentSubscriptionPeriod);
			
			String clientToken = PaymentUtil.getClientToken();
			Role role = RoleLocalServiceUtil.getRole(PortalUtil.getCompanyId(request), currentAccountType);
			//currentSubscriptionType = 
			
			String subscriptionAmount = (String) ExpandoValueLocalServiceUtil.getData(PortalUtil.getCompanyId(request), 
					Role.class.getName(), ExpandoTableConstants.DEFAULT_TABLE_NAME, currentSubscriptionPeriod, role.getRoleId());
			
			request.setAttribute("roleId", GetterUtil.getObject(String.valueOf(role.getRoleId()), StringPool.BLANK));
			request.setAttribute("subscriptionPeriod", GetterUtil.getObject(currentSubscriptionPeriod, StringPool.BLANK));
			request.setAttribute("subscriptionAmount", GetterUtil.getObject(subscriptionAmount, StringPool.BLANK));
			request.setAttribute("cmd","renew");
			request.setAttribute("clientToken",GetterUtil.getObject(clientToken, StringPool.BLANK));
		} catch (PortalException e) {
			_log.error("Portalexception occured :" + e.getMessage());
			SessionErrors.add(request, "technical-failure");
			return VIEW_JSP;
		} catch (SystemException e) {
			_log.error("SystemException occured :" + e.getMessage());
			SessionErrors.add(request, "technical-failure");
			return VIEW_JSP;
		}
		
		return CHECKOUT_JSP;
	}
	
	/**
	 * This method is used for subscription payment on the account.
	 * 
	 * @param request
	 * @param response
	 * @return 
	 */
	@RenderMapping(params="action=subscribe")
	public String payment(RenderRequest request, RenderResponse response){
		_log.info("pay method Render....."); 
		
		String clientToken = null;
		String currentSubscriptionType;
		String currentAccountType;
		String roleId = ParamUtil.getString(request, "roleId");
		String subscriptionAmount = ParamUtil.getString(request, "subscriptionAmount");
		String subscriptionPeriod = ParamUtil.getString(request, "subscriptionPeriod");
		String cvv = ParamUtil.getString(request, "cvv");
		String cmd = ParamUtil.getString(request, "cmd");
		
		_log.info("roleId :" + roleId);
		_log.info("subscriptionAmount :" + subscriptionAmount);
		_log.info("subscriptionPeriod :" + subscriptionPeriod);
		_log.info("cmd :" + cmd);
		_log.info("cvv :" + cvv);
		try {
			
			if(Validator.isNotNull(cmd)){
				
				if(cmd.equalsIgnoreCase("subscribe")){
					
					subscribeAccount(request, roleId, subscriptionPeriod);
					
				} else {
					renewAccount(request,roleId);
				}
				return VIEW_JSP;
			} else {
				
				// check if the user is already subscribed user for same aacount and same period(like monthly,quarterly);
				currentAccountType = PodEngineUtil.getAccounyType(request);
				currentSubscriptionType = PodEngineUtil.getSubscriptionType(request);
				Role role = RoleLocalServiceUtil.getRole(Long.parseLong(roleId));
				if(currentAccountType.equalsIgnoreCase(role.getName()) && currentSubscriptionType.equalsIgnoreCase(subscriptionPeriod)){
					SessionMessages.add(request, "already-subscribed");
					request.setAttribute("already-subscribed", "Already Subscribed for "+currentSubscriptionType+StringPool.SPACE+currentAccountType);
					return VIEW_JSP;
				} else {
					_log.info("proceed for checkout");
					clientToken = PaymentUtil.getClientToken();
					
					subscriptionAmount = PodEngineUtil.getSubscriptionAmount(PortalUtil.getCompanyId(request), subscriptionPeriod, roleId);
					_log.info("subscriptionAmount :" + subscriptionAmount);
					request.setAttribute("roleId", GetterUtil.getObject(roleId, StringPool.BLANK));
					request.setAttribute("subscriptionPeriod", GetterUtil.getObject(subscriptionPeriod, StringPool.BLANK));
					request.setAttribute("subscriptionAmount", GetterUtil.getObject(subscriptionAmount, StringPool.BLANK));
					request.setAttribute("cmd","subscribe");
					request.setAttribute("clientToken",GetterUtil.getObject(clientToken, StringPool.BLANK));
				}
			}
		} catch (PortalException e) {
			_log.error("Portalexception occured :" + e.getMessage());
			SessionErrors.add(request, "technical-failure");
			return VIEW_JSP;
		} catch (SystemException e) {
			_log.error("SystemException occured :" + e.getMessage());
			SessionErrors.add(request, "technical-failure");
			return VIEW_JSP;
		}
		
		return CHECKOUT_JSP;
	}
	
	/**
	 * This method is used to make payment for renew subscription of pod engine account. It updates the validity 
	 * based on subscription period(monthly,quarterly etc).
	 * 
	 * @param request
	 * @param roleId 
	 * @param roleId
	 * @param subscriptionType
	 * @throws PortalException
	 * @throws SystemException
	 */
	private void renewAccount(PortletRequest request, String roleId) throws PortalException, SystemException {
		
		boolean paymentStatus;
		String currentSubscriptionType;
		String currentAccountType;
		_log.info("renew for payment");
		String subscriptionAmount = ParamUtil.getString(request, "subscriptionAmount");
		currentSubscriptionType = PodEngineUtil.getSubscriptionType(request);
		paymentStatus = PaymentUtil.getPaymentStatus(request, subscriptionAmount);
		PodEngineUtil.extendValidity(request, currentSubscriptionType);
		// code to be written to update validity of the in expando table based on the user
		
		
	}

	/**
	 * This method is used to make payment for subscription of pod engine account. It updates the validity 
	 * based on subscription period(monthly,quarterly etc). It will also update if user is switching from 
	 * one account type to another.
	 * 
	 * @param request
	 * @param roleId
	 * @param subscriptionType
	 * @throws PortalException
	 * @throws SystemException
	 */
	private void subscribeAccount(RenderRequest request, String roleId,
			String subscriptionType) throws PortalException, SystemException {
		
		boolean paymentStatus;
		String currentSubscriptionType;
		String currentAccountType;
		String subscriptionAmount = ParamUtil.getString(request, "subscriptionAmount");
		_log.info("proceed for payment");
		currentSubscriptionType = PodEngineUtil.getSubscriptionType(request);
		currentAccountType = PodEngineUtil.getAccounyType(request);
		_log.info(currentSubscriptionType);
		
		//check for current account tyep and subscription type to decide whther payment will be done or user will be informed that account alredy subscribed
		
		Role selectedRole = RoleLocalServiceUtil.getRole(Long.valueOf(roleId));
		_log.info("currentAccountType :" + currentAccountType + "selectedRole :" + selectedRole.getName());
			paymentStatus = PaymentUtil.getPaymentStatus(request,subscriptionAmount);
			PodEngineUtil.updateAccountValidity(request, subscriptionType);
			PodEngineUtil.updateSubscriptionType(request, subscriptionType);
			
			if(!currentAccountType.equalsIgnoreCase(selectedRole.getName())){
				updateUserRole(request, selectedRole);
			}
	}
	
	/**
	 * This method is used to changed the user account type i.e. moving from one account to another.
	 * 
	 * @param request
	 * @param selectedRole
	 */
	private void updateUserRole(PortletRequest request, Role selectedRole){
		_log.info("updateUserRole : ENTER");
		
		//String selectedRoleName = ParamUtil.getString(request, AccountsConstants.SELECTED_ROLE);
		String[] podRoles = { AccountsConstants.FREE_ACCOUNT, AccountsConstants.VALUE_ACCOUNT,
				AccountsConstants.PREMIUIM_ACCOUNT, AccountsConstants.PRO_ACCOUNT };
		List<Role> userRoles;
		try {
			//PortalUtil.getCompanyId(request), selectedRoleName.replace(CharPool.UNDERLINE, CharPool.SPACE));
			User user = PortalUtil.getUser(request);
			userRoles = RoleLocalServiceUtil.getUserRoles(user.getUserId());
			
			if(!userRoles.contains(selectedRole)){
				boolean checkRole= true;
				for(int i=0; i<podRoles.length;i++){
					for(Role userRole : userRoles){
						if(podRoles[i].equalsIgnoreCase(userRole.getName())){
							_log.info("User is a " + userRole.getName() + " holder");
							UserLocalServiceUtil.deleteRoleUser(userRole.getRoleId(), user.getUserId());
							checkRole =false;
							break;
						}
					}
					if(!checkRole){
						break;
					}
				}
				UserLocalServiceUtil.addRoleUser(selectedRole.getRoleId(), user.getUserId());
				HttpSession session = PortalUtil.getHttpServletRequest(request).getSession();
				session.setAttribute(AccountsConstants.PODENGINE_ACCOUNTTYPE_ID, String.valueOf(selectedRole.getRoleId()));
				PodEngineUtil.updateAccountType(request, selectedRole.getName());
				_log.info("Successfully user accountType changed to " + selectedRole.getName());
				
			} else {
				//SessionMessages.add(request, "user");
				_log.info("User already " + selectedRole.getName() + " holder");
			}
			
			String watchAndListen = PodEngineUtil.getUserRoleCustomFieldValue(user, request, AccountsConstants.WATCH_AND_LISTEN);
			_log.info("watchAndListen-----------"+watchAndListen);
			PlayerTimeStamp userPlayerTimeStamp  = PlayerTimeStampLocalServiceUtil.findByPlayerTimeUserId(user.getUserId());
			if(watchAndListen.equals("Unlimited(24/7)")){
				_log.info("Add -1 to DB");
				userPlayerTimeStamp.setAvailableDuration(-1);
				userPlayerTimeStamp.setUsedDuration(0);
			}
			else if(watchAndListen.equals("30min")){
				_log.info("Add 1800 to DB");
				userPlayerTimeStamp.setAvailableDuration(1800);
				userPlayerTimeStamp.setUsedDuration(0);
			}
			PlayerTimeStampLocalServiceUtil.updatePlayerTimeStamp(userPlayerTimeStamp);
			
		} catch (PortalException | SystemException e) {
			_log.error(e.getMessage());
		}
		_log.info("updateUserRole : EXIT");
		//return VIEW_JSP;
	}
	
	
	/**********
	 *  Below codes commented as it was written for payment gateway testing & intergration related activity.
	 *   Code is kept for future reference
	 ************/
	
//	
//	final String redirectUrl = "https://www.google.com";
//	@RenderMapping("google")
//	public String goToGoogle()
//	{
//		_log.info("google");
//		return redirectUrl;
//	}
//	
//	@ActionMapping(params="action=brainTreeLoginPage")
//	public  void  brainTreeLoginPage(ActionRequest request, ActionResponse responce) throws Exception
//	{
//	
//	   _log.info("brainTreeLoginPage method start4");
//	  
//	   //App.main(null); 
//	   //responce.sendRedirect(redirectUrl);
//	   //goToGoogle();
//         
//	  _log.info("brainTreeLoginPage method end4");
//		
//	}      
// 
// 
//	 
///*	@ActionMapping(params="action=brainTreeLoginPage")
//		public  void  brainTreeLoginPage(ActionRequest request) throws Exception
//		{
//		
//		   _log.info("brainTreeLoginPage method start3");
//		   System.out.println("Running the program...\n");
//		   SubscriptionsController httpUrlBasicAuthentication = new SubscriptionsController();
//	       httpUrlBasicAuthentication.httpPostLogin();
//		   _log.info("brainTreeLoginPage method end3");
//			
//		}   
//	 */
//	  
// 
//	
//	/* @ActionMapping(params="action=brainTreeLoginPage")
//	public  void  brainTreeLoginPage() throws Exception
//	{
//		_log.info("brainTreeLoginPage method start2");
//		
//		 // Create an instance of HttpClient.
//	    HttpClient client = new HttpClient();
//
//	    // Create a method instance.
//	    GetMethod method = new GetMethod(url);
//	    
//	    // Provide custom retry handler is necessary
//	    method.getParams().setParameter(HttpMethodParams.RETRY_HANDLER, 
//	    		new DefaultHttpMethodRetryHandler(3, false)); 
//
//	    try {
//	      // Execute the method.
//	      int statusCode = client.executeMethod(method);
//
//	      if (statusCode != HttpStatus.SC_OK) {
//	        System.err.println("Method failed: " + method.getStatusLine());
//	      }
//
//	      // Read the response body.
//	      byte[] responseBody = method.getResponseBody();
//
//	      // Deal with the response.
//	      // Use caution: ensure correct character encoding and is not binary data
//	      System.out.println(new String(responseBody));
//
//	    } catch (HttpException e) {
//	      System.err.println("Fatal protocol violation: " + e.getMessage());
//	      e.printStackTrace();
//	    } catch (IOException e) {
//	      System.err.println("Fatal transport error: " + e.getMessage());
//	      e.printStackTrace();
//	    } finally {
//	      // Release the connection.
//	      method.releaseConnection();
//	    }
//		  
//		_log.info("brainTreeLoginPage method end2");
//		
//	} */
//	
//	
//	/* below code commented as present implentatiopn is under further development */
//	@ActionMapping(params="action=brainTreeLoginPage1")
//	public  void  brainTreeLoginPage1() throws Exception
//	{
//		_log.info("brainTreeLoginPage method start");
//		 
//		String url = "https://accounts.google.com/ServiceLoginAuth";
//		String gmail = "https://mail.google.com/mail/";
//
//		//HttpUrlConnectionExample http = new HttpUrlConnectionExample();
//		
//		SubscriptionsController http=new SubscriptionsController();
//
//		// make sure cookies is turn on
//		CookieHandler.setDefault(new CookieManager());
//
//		// 1. Send a "GET" request, so that you can extract the form's data.
//		String page = http.GetPageContent(url);
//		String postParams = http.getFormParams(page, "username@gmail.com", "password");
//
//		// 2. Construct above post's content and then send a POST request for
//		// authentication
//		http.sendPost(url, postParams); 
//
//		// 3. success then go to gmail.
//		String result = http.GetPageContent(gmail);
//		System.out.println(result);
//		   
// 
//			 
//		
//		_log.info("brainTreeLoginPage method end");
//		 
//	}
//	 
//	  
//	
//	@ActionMapping(params="action=cardPay")  
//	public void payCard(ActionRequest request, ActionResponse response) throws IOException{ 
//		_log.info("payCard called :ENTER"); 
//		
//		System.out.println(" payCard credit card method");
//		response.sendRedirect("https://www.google.com"); 
//		
//	 
//		/*String message = PaymentUtil.getPayment().creditCardPay(request, response, null);
//	    
//		if(message.equals("1"))
//		{
//			SessionMessages.add(request,"success-msg","success");
//			System.out.println(message+"1111111111");
//		}
//		if(message.equals("-1"))
//		{
//			SessionMessages.add(request,"success-msg1","success1");
//			System.out.println(message+"----1111111111");
//		}*/
//	 
//	 
//		_log.info("message after paymwent zaheer:" + "message"); 
//		_log.info("payCard called :EXIT");  
//		
//		 
//	}  
//	
//	@ActionMapping
//	public void defaultAction(ActionRequest actionRequest, ActionResponse actionResponse) {
//		_log.info("Default Action.....");
//	}
//	
//	
//	/*=========================================================*/
//	
//	 private void sendPost(String url, String postParams) throws Exception {
//
//			URL obj = new URL(url);
//			conn = (HttpsURLConnection) obj.openConnection();
//
//			// Acts like a browser
//			conn.setUseCaches(false);
//			conn.setRequestMethod("POST");
//			conn.setRequestProperty("Host", "accounts.google.com");
//			conn.setRequestProperty("User-Agent", USER_AGENT);
//			conn.setRequestProperty("Accept",
//				"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
//			conn.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
//			for (String cookie : this.cookies) {
//				conn.addRequestProperty("Cookie", cookie.split(";", 1)[0]);
//			}
//			conn.setRequestProperty("Connection", "keep-alive");
//			conn.setRequestProperty("Referer", "https://accounts.google.com/ServiceLoginAuth");
//			conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
//			conn.setRequestProperty("Content-Length", Integer.toString(postParams.length()));
//
//			conn.setDoOutput(true);
//			conn.setDoInput(true);
//
//			// Send post request
//			DataOutputStream wr = new DataOutputStream(conn.getOutputStream());
//			wr.writeBytes(postParams);
//			wr.flush();
//			wr.close();
//
//			int responseCode = conn.getResponseCode();
//			System.out.println("\nSending 'POST' request to URL : " + url);
//			System.out.println("Post parameters : " + postParams);
//			System.out.println("Response Code : " + responseCode);
//
//			BufferedReader in = 
//		             new BufferedReader(new InputStreamReader(conn.getInputStream()));
//			String inputLine;
//			StringBuffer response = new StringBuffer();
//
//			while ((inputLine = in.readLine()) != null) {
//				response.append(inputLine);
//			}
//			in.close();
//			// System.out.println(response.toString());
//
//		  }
//
//		  private String GetPageContent(String url) throws Exception {
//
//			URL obj = new URL(url);
//			conn = (HttpsURLConnection) obj.openConnection();
//
//			// default is GET
//			conn.setRequestMethod("GET");
//
//			conn.setUseCaches(false);
//
//			// act like a browser
//			conn.setRequestProperty("User-Agent", USER_AGENT);
//			conn.setRequestProperty("Accept",
//				"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
//			conn.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
//			if (cookies != null) {
//				for (String cookie : this.cookies) {
//					conn.addRequestProperty("Cookie", cookie.split(";", 1)[0]);
//				}
//			}
//			int responseCode = conn.getResponseCode();
//			System.out.println("\nSending 'GET' request to URL : " + url);
//			System.out.println("Response Code : " + responseCode);
//
//			BufferedReader in = 
//		            new BufferedReader(new InputStreamReader(conn.getInputStream()));
//			String inputLine;
//			StringBuffer response = new StringBuffer();
//
//			while ((inputLine = in.readLine()) != null) {
//				response.append(inputLine);
//			}
//			in.close();
//
//			// Get the response cookies
//			setCookies(conn.getHeaderFields().get("Set-Cookie"));
//
//			return response.toString();
//
//		  }
//
//		  public String getFormParams(String html, String username, String password)
//				throws UnsupportedEncodingException {
//
//			System.out.println("Extracting form's data...");
//
//			Document doc = Jsoup.parse(html);
//
//			// Google form id
//			Element loginform = doc.getElementById("gaia_loginform");
//			Elements inputElements = loginform.getElementsByTag("input");
//			List<String> paramList = new ArrayList<String>();
//			for (Element inputElement : inputElements) {
//				String key = inputElement.attr("name");
//				String value = inputElement.attr("value");
//
//				if (key.equals("Email"))
//					value = username;
//				else if (key.equals("Passwd"))
//					value = password;
//				paramList.add(key + "=" + URLEncoder.encode(value, "UTF-8"));
//			}
//
//			// build parameters list
//			StringBuilder result = new StringBuilder();
//			for (String param : paramList) {
//				if (result.length() == 0) {
//					result.append(param);
//				} else {
//					result.append("&" + param);
//				}
//			}
//			return result.toString();
//		  }
//
//		  public List<String> getCookies() {
//			return cookies;
//		  }
//
//		  public void setCookies(List<String> cookies) {
//			this.cookies = cookies;
//		  }
//		  
//		  
//		  /*============================================================*/
//		  
//
//		 /**
//	     * The single public method of this class that
//	     * 1. Prepares a login message
//	     * 2. Makes the HTTP POST to the target URL
//	     * 3. Reads and returns the response
//	     *
//	     * @throws IOException
//	     * Any problems while doing the above.
//	     *
//	     */
//	    public void httpPostLogin ()
//	    {
//	        try
//	        {
//	            // Prepare the content to be written
//	            // throws UnsupportedEncodingException
//	            String urlEncodedContent = preparePostContent(LOGIN_USER_NAME, LOGIN_PASSWORD);
//	            System.out.println("urlEncodedContent :"+urlEncodedContent);
//	            HttpURLConnection urlConnection = doHttpPost(TARGET_URL, urlEncodedContent);
//	            System.out.println("urlConnection  1:"+urlConnection); 
//	            String response = readResponse(urlConnection);
//	            System.out.println("Successfully made the HTPP POST.");
//	            System.out.println("Recevied response is: '/n" + response + "'");
//	 
//	        }
//	        catch(IOException ioException)
//	        {
//	            System.out.println("Problems encounterd.");
//	        }
//	    }
//	 
//	    /**
//	     * Using the given username and password, and using the static string variables, prepare
//	     * the login message. Note that the username and password will encoded to the
//	     * UTF-8 standard.
//	     *
//	     * @param loginUserName
//	     * The user name for login
//	     *
//	     * @param loginPassword
//	     * The password for login
//	     *
//	     * @return
//	     * The complete login message that can be HTTP Posted
//	     *
//	     * @throws UnsupportedEncodingException
//	     * Any problems during URL encoding
//	     */
//	    private String preparePostContent(String loginUserName, String loginPassword) throws UnsupportedEncodingException
//	    {
//	        // Encode the user name and password to UTF-8 encoding standard
//	        // throws UnsupportedEncodingException
//	        String encodedLoginUserName = URLEncoder.encode(loginUserName, "UTF-8");
//	        String encodedLoginPassword = URLEncoder.encode(loginPassword, "UTF-8");
//	 
//	         String content = "commit=" + LOGIN_ACTION_NAME +" &" + LOGIN_USER_NAME_PARAMETER_NAME +"="
//	        + encodedLoginUserName + "&" + LOGIN_PASSWORD_PARAMETER_NAME + "=" + encodedLoginPassword; 
//	 
//	        /*String content = LOGIN_USER_NAME_PARAMETER_NAME +"="
//	        + encodedLoginUserName + "&" + LOGIN_PASSWORD_PARAMETER_NAME + "=" + encodedLoginPassword;*/
//	 
//	        return content;
//	 
//	    }
//	 
//	    /**
//	     * Makes a HTTP POST to the target URL by using an HttpURLConnection.
//	     *
//	     * @param targetUrl
//	     * The URL to which the HTTP POST is made.
//	     *
//	     * @param content
//	     * The contents which will be POSTed to the target URL.
//	     *
//	     * @return
//	     * The open URLConnection which can be used to read any response.
//	     *
//	     * @throws IOException
//	     */
//	    public HttpURLConnection doHttpPost(String targetUrl, String content) throws IOException
//	    {
//	        HttpURLConnection urlConnection = null;
//	        DataOutputStream dataOutputStream = null;
//	        try
//	        {
//	            // Open a connection to the target URL
//	            // throws IOException
//	            urlConnection = (HttpURLConnection)(new URL(targetUrl).openConnection());
//	 
//	            // Specifying that we intend to use this connection for input
//	            urlConnection.setDoInput(true);
//	 
//	            // Specifying that we intend to use this connection for output
//	            urlConnection.setDoOutput(true);
//	 
//	            // Specifying the content type of our post
//	            urlConnection.setRequestProperty("Content-Type", POST_CONTENT_TYPE);
//	            urlConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-GB; rv:1.9.2.8) Gecko/20100722 Firefox/3.6.8");
//	 
//	            HttpURLConnection.setFollowRedirects(true);
//	            // Specifying the method of HTTP request which is POST
//	            // throws ProtocolException
//	            urlConnection.setRequestMethod("POST");
//	 
//	            // Prepare an output stream for writing data to the HTTP connection
//	            // throws IOException
//	            dataOutputStream = new DataOutputStream(urlConnection.getOutputStream());
//	 System.out.println(content+"   : content");
//	            // throws IOException
//	  
//	            dataOutputStream.writeBytes(content);
//	            dataOutputStream.flush();
//	            dataOutputStream.close();
//	 
//	            return urlConnection;
//	        }
//	        catch(IOException ioException)
//	        {
//	            System.out.println("I/O problems while trying to do a HTTP post.");
//	            ioException.printStackTrace();
//	 
//	            // Good practice: clean up the connections and streams
//	            // to free up any resources if possible
//	            if (dataOutputStream != null)
//	            {
//	                try
//	                {
//	                    dataOutputStream.close();
//	                }
//	                catch(Throwable ignore)
//	                {
//	                    // Cannot do anything about problems while
//	                    // trying to clean up. Just ignore
//	                }
//	            }
//	            if (urlConnection != null)
//	            {
//	                urlConnection.disconnect();
//	            }
//	 
//	            // throw the exception so that the caller is aware that
//	            // there was some problems
//	            throw ioException;
//	        }
//	    }
//	 
//	    /**
//	     * Read response from the URL connection
//	     *
//	     * @param urlConnection
//	     * The URLConncetion from which the response will be read
//	     *
//	     * @return
//	     * The response read from the URLConnection
//	     *
//	     * @throws IOException
//	     * When problems encountered during reading the response from the
//	     * URLConnection.
//	     */
//	    private String readResponse(HttpURLConnection urlConnection) throws IOException
//	    {
//	 
//	        BufferedReader bufferedReader = null;
//	        try
//	        {
//	            // Prepare a reader to read the response from the URLConnection
//	            // throws IOException
//	            bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
//	            String responeLine;
//	 
//	            // Good Practice: Use StringBuilder in this case
//	            StringBuilder response = new StringBuilder();
//	 
//	            // Read until there is nothing left in the stream
//	            // throws IOException
//	            while ((responeLine = bufferedReader.readLine()) != null)
//	            {
//	                response.append(responeLine);
//	            }
//	 
//	            return response.toString();
//	        }
//	        catch(IOException ioException)
//	        {
//	            System.out.println("Problems while reading the response");
//	            ioException.printStackTrace();
//	 
//	            // throw the exception so that the caller is aware that
//	            // there was some problems
//	            throw ioException;
//	 
//	        }
//	        finally
//	        {
//	            // Good practice: clean up the connections and streams
//	            // to free up any resources if possible 
//	            if (bufferedReader != null)
//	            {
//	                try
//	                {
//	                    // throws IOException
//	                    bufferedReader.close();
//	                }
//	                catch(Throwable ignore)
//	                {
//	                    // Cannot do much with exceptions doing clean up
//	                    // Ignoring all exceptions
//	                }
//	            }
//	 
//	        }
//	    }
	
}
