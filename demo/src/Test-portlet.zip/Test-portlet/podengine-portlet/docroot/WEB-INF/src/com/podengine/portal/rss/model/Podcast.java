package com.podengine.portal.rss.model;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;
import java.util.List;

import com.podengine.portal.rss.exceptions.*;

public interface Podcast {

	public String getOAuthUserName();

	public String getOAuthPassword();

	public String getTitle();

	public String getDescription();

	public URL getLink() throws MalformedURLException;

	public String getLanguage();

	public String getCopyright();

	public String getManagingEditor();

	public String getWebMaster();

	public Date getPubDate();

	public Date getLastBuildDate();

	public String[] getCategories();

	public String getGenerator();

	public URL getDocs() throws MalformedURLException;

	public Object getCloud();

	public int getTTL();

	public URL getImageURL() throws MalformedURLException;

	public String[] getKeywords();

	public boolean isExplicit();

	// Episodes
	public List<Episode> getEpisodes() throws MalformedURLException,
			MalformedFeedException;

	public String getXMLData();

	public URL getFeedURL();

}