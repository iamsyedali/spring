package com.podengine.portal.rss.parser;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import sun.misc.BASE64Encoder;

import com.podengine.portal.util.PodEngineUtil;

public class XMLParser {
	/*
	 * Returns boolean
	 * Method will check whether rssFeed Url has media file or Not
	 * */

	public static boolean RSSFeedRootCheck(String rssFeedURL, String userName, String password, boolean aurhorizationRequired)
			throws IOException {
		BASE64Encoder enc = new sun.misc.BASE64Encoder();
		Document document = null;
		if (aurhorizationRequired) {
			String encodedAuthorization = enc.encode((userName + ":" + password).getBytes());
			document = Jsoup.connect(rssFeedURL).header("Authorization", "Basic " + encodedAuthorization).get();
		} else {
			document = Jsoup.connect(rssFeedURL).get();
		}

		Elements channel = document.getElementsByTag("channel");
		if (!channel.isEmpty()) {
			for (Element element : channel) {
				Elements items = element.getElementsByTag("item");

				if (!items.isEmpty()) {
					for (Element item : items) {
						Elements links = item.getElementsByTag("link");
						if (!links.isEmpty()) {
							for (Element link : links) {
								if (link.text().substring(link.text().lastIndexOf("/")).contains(".mp3")
								          || link.text().substring(link.text().lastIndexOf("/")).contains(".mp4")
								          || PodEngineUtil.getRedirectURL(link.text()).substring(PodEngineUtil.getRedirectURL(link.text()).lastIndexOf("/")).contains(".mp3")) 
								{
								   return true;
								}
								
							}
						}
					}
				}
			}
		}
		return false;
	}
}
