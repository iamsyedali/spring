package com.podengine.portal.util.constants;
/**
 * @author Syed Ali
 */
public class ActionKeys extends com.liferay.portal.security.permission.ActionKeys {
	
	public static final String ADD_ROLE = "addRoleAction";
	public static final String DELETE_RSS_FEED = "deleteRSS";
	public static final String EDIT_RSS_FEED = "editRSS";
	public static final String ADDRSS_RSS_FEED = "addRss";
	
	public static final String PRIVATE_ACCESS = "privateAccessCode";
	
	public static final String ADD_BE_PODJOCKEY = "addBePodJockey";
	 
	public static final String HOST_DATA = "hostData";
	public static final String ADD_RSS = "addRss";
	public static final String CONTACT_US= "contactus";
	
    
}
