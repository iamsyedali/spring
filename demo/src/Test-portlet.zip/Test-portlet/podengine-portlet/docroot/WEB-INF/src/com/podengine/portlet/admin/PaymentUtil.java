package com.podengine.portlet.admin;

import java.math.BigDecimal;
import java.util.HashMap;

import javax.portlet.PortletRequest;
import javax.portlet.PortletResponse;

import com.braintreegateway.BraintreeGateway;
import com.braintreegateway.Environment;
import com.braintreegateway.Result;
import com.braintreegateway.Transaction;
import com.braintreegateway.TransactionCreditCardRequest;
import com.braintreegateway.TransactionRequest;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;

public class PaymentUtil {
	
	private static final Log _log = LogFactoryUtil.getLog(PaymentUtil.class);

	private static BraintreeGateway gateway = new BraintreeGateway(Environment.SANDBOX, "3w5mmypsv6chmtym", "hh6zctftwwcyc6g3", "5976187e7094aa72de48a8aa2380b07c");
	
	//private static PaymentUtil paymentUtil; 

	/**
	 * This method generates client token for payment
	 * 
	 * @return clientToken as String
	 */
	public static String getClientToken(){
		return gateway.clientToken().generate();
	}
	
	/**
	 * @param request
	 * @return
	 */
	public static boolean getPaymentStatus(PortletRequest request, String subscriptionAmount){
		
		boolean paymentStatus = false;
		String payment_method_nonce = request.getParameter("payment_method_nonce");
		_log.info("payment_method_nonce :" + payment_method_nonce);
		TransactionRequest transactionRequest = new TransactionRequest();
		transactionRequest.amount(new BigDecimal(subscriptionAmount));
		transactionRequest.paymentMethodNonce(payment_method_nonce);
		transactionRequest.options().done();
		
		Result<Transaction> result = gateway.transaction().sale(transactionRequest);
		if(result.isSuccess()){
			request.setAttribute("transactionId","Payment done successfully with Transaction Id :" + result.getTarget().getId());
			SessionMessages.add(request, "payment-success");
			paymentStatus = true;
		} else {
			_log.info("payment-failed :" + result.getMessage());
			request.setAttribute("transactionId","Payment failed due to " + result.getMessage());
			SessionErrors.add(request, "payment-failed");
		}
		
		return paymentStatus;
	}

	@SuppressWarnings("null")
	public static String creditCardPay(PortletRequest request,PortletResponse response, String paymentType) {
	
		String cardNumber = ParamUtil.getString(request, "number");
		String cardHolderName = ParamUtil.getString(request, "cardHolderName");
		String cvv = ParamUtil.getString(request, "cvv");
		String expiryMonth = ParamUtil.getString(request, "month");
		String expiryYear = ParamUtil.getString(request, "year");
		String message=null;
		 
		_log.info("cardNumber :" + cardNumber);
		_log.info("cardHolderName :" + cardHolderName);
		_log.info("cvv :" + cvv);
		_log.info("expiryMonth :" + expiryMonth);
		_log.info("expiryYear :" + expiryYear);
		
		TransactionRequest transactionRequest = new TransactionRequest()
				.amount(new BigDecimal("90.00"));
		 
		TransactionCreditCardRequest creditCardRequest = transactionRequest.creditCard();
		
		creditCardRequest.cvv(cvv)
					.number(cardNumber)
					.cardholderName(cardHolderName)
					.expirationMonth(expiryMonth)
					.expirationYear(expiryYear).done();
		transactionRequest.options().done();

		Result<Transaction> result = gateway.transaction().sale(
				transactionRequest);
		String trans;
		SubscriptionsController sc=new SubscriptionsController();
		try{
			  trans= result.getTarget().getId();
			_log.info("Success! Transaction ID: " + trans);
			 trans="1";
			 System.out.println("message"+message); 
		}
		catch(Exception e)
		{
			 trans="-1";
			 //sc.pay();
		}
		
		  
		
		 
		
//		_log.info("Success! Transaction ID: " + result.getTarget().getId());
//		response.type("text/html");
//		if (result.isSuccess()) {
//			return "<h1>Success! Transaction ID: " + result.getTarget().getId()
//					+ "</h1>";
//		} else {
//			return "<h1>Error: " + result.getMessage() + "</h1>";
//		}
		 return trans; 
		 
	}
	
	public static void setPaymentRedirect(PortletRequest request,PortletResponse response){
		String braintreeUrl = gateway.transparentRedirect().url();
        TransactionRequest trParams = new TransactionRequest()
                .type(Transaction.Type.SALE)
                .amount(new BigDecimal("1000.00"))
                .options()
                    .submitForSettlement(true)
                    .done();

        String trData = gateway.transparentRedirect().trData(trParams, "http://localhost:4567/braintree");

        // return HTML with braintreeUrl and trData intermixed
        HashMap<String, String> valuesMap = new HashMap<String, String>();
        valuesMap.put("braintreeUrl", braintreeUrl);
        valuesMap.put("trData", trData);
       // renderHtml("views/form.html", valuesMap);
	}
	
	public static void creditCardVerify(){
		
		StringBuilder builder = new StringBuilder();
        builder.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        builder.append("<api-error-response>");
        builder.append("  <verification>");
        builder.append("    <avs-error-response-code nil=\"true\"></avs-error-response-code>");
        builder.append("    <avs-postal-code-response-code>I</avs-postal-code-response-code>");
        builder.append("    <status>processor_declined</status>");
        builder.append("    <processor-response-code>2000</processor-response-code>");
        builder.append("    <avs-street-address-response-code>I</avs-street-address-response-code>");
        builder.append("    <processor-response-text>Do Not Honor</processor-response-text>");
        builder.append("    <cvv-response-code>M</cvv-response-code>");
        builder.append("  </verification>");
        builder.append("  <errors>");
        builder.append("    <errors type=\"array\"/>");
        builder.append("  </errors>");
        builder.append("</api-error-response>");

         
	}
	

}
