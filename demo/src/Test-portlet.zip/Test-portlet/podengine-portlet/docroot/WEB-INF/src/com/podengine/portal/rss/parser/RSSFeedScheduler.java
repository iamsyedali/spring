package com.podengine.portal.rss.parser;

import java.util.ArrayList;
import java.util.List;

import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.messaging.MessageListener;
import com.liferay.portal.kernel.messaging.MessageListenerException;
import com.liferay.portal.kernel.util.ListUtil;
import com.podengine.portal.util.PodEngineUtil;
import com.podengine.portal.util.PodcastThreadUtil;
import com.podengine.portal.util.constants.CONTENT_TYPE;
import com.podengine.service.model.RSSfeed;
import com.podengine.service.service.RSSfeedLocalServiceUtil;
import com.podengine.service.service.persistence.PodcastUtil;
import com.podengine.service.service.persistence.RSSfeedUtil;

public class RSSFeedScheduler implements MessageListener{

	private static Log _log = LogFactoryUtil.getLog(RSSFeedScheduler.class);
	
	@Override
	public void receive(Message message) throws MessageListenerException {
		_log.info("Scheduler Triggered....");
		
		_log.info("Message DATA : "+message.toString());
		try {
			List<RSSfeed> rssFeeds = new ArrayList<RSSfeed>();
			 rssFeeds = RSSfeedLocalServiceUtil.findRSSFeedsByContentType(CONTENT_TYPE.ADMIN_ADDED);
			//rssFeeds.addAll(RSSfeedLocalServiceUtil.findRSSFeedsByContentType(CONTENT_TYPE.POSTED));
			_log.info("RSSFeeds Size : "+rssFeeds.size());
			if (!rssFeeds.isEmpty()) {
				_log.info("Syncing RSSFeeds.....");
				for (RSSfeed rssFeed : rssFeeds) {
					_log.info("Syncing RSSFeed..... : "+rssFeed.getFeedURL());
					PodcastThreadUtil.start(rssFeed);
				}
			} else {
				_log.info("No RSSFeeds in DataBase To Sync.....");
			}
		} catch (SystemException e) {
			_log.error(e.getMessage());
		}
	}

}
