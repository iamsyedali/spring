package com.podengine.portlet.user;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.portlet.bind.annotation.ActionMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;

import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.podengine.portal.util.constants.PortletMode;

@Controller
@RequestMapping({PortletMode.VIEW})
public class NavigatorController {
 
	private static Log _log = LogFactoryUtil.getLog(NavigatorController.class);
	private static final String VIEW_JSP = "view";
	
	@ActionMapping
	public void defaultAction(ActionRequest actionRequest, ActionResponse actionResponse) {
		_log.debug("Default Action.....");
	}
	
	@RenderMapping
	  public String defaultRender(RenderRequest renderRequest, RenderResponse renderResponse) {
		 _log.debug("Default Render.....");
		return VIEW_JSP;
	 }
}
