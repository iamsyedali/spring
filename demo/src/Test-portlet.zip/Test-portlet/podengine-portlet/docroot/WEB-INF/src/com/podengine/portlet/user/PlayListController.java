package com.podengine.portlet.user;

import java.io.PrintWriter;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.portlet.bind.annotation.ActionMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;
import org.springframework.web.portlet.bind.annotation.ResourceMapping;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.ListUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.theme.ThemeDisplay;
import com.podengine.portal.util.constants.CMD;
import com.podengine.portal.util.constants.Constants;
import com.podengine.portal.util.constants.PortletMode;
import com.podengine.portal.util.constants.RenderKeys;
import com.podengine.portal.util.constants.ResourceKeys;
import com.podengine.service.NoSuchPlayListException;
import com.podengine.service.NoSuchPodJockeyPlayListException;
import com.podengine.service.model.MyContent;
import com.podengine.service.model.PlayList;
import com.podengine.service.model.PodJockeyPlayList;
import com.podengine.service.model.impl.MyContentImpl;
import com.podengine.service.model.impl.PlayListImpl;
import com.podengine.service.service.ClpSerializer;
import com.podengine.service.service.MyContentLocalServiceUtil;
import com.podengine.service.service.PlayListLocalServiceUtil;
import com.podengine.service.service.PodJockeyPlayListLocalServiceUtil;

@Controller
@RequestMapping({PortletMode.VIEW})
public class PlayListController {
	static ClassLoader classLoader = (ClassLoader) PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),"portletClassLoader");
	private static Log _log = LogFactoryUtil.getLog(PlayListController.class);
	private static final String VIEW_JSP = "view";
	
	@ActionMapping
	public void defaultAction(ActionRequest request, ActionResponse actionResponse) {
		_log.info("Default Action.....");
	}
	
	@SuppressWarnings("unchecked")
	@RenderMapping
	public String defaultRender(RenderRequest renderRequest,RenderResponse renderResponse)
	{
	  String action = ParamUtil.getString(renderRequest, CMD.ACTION);
	  if (action.equals(RenderKeys.DELETE_MYCONTENT)) 
	    {
		   long podcastId = ParamUtil.getLong(renderRequest, "podCastId");
		   ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
		   long userId = themeDisplay.getUserId();
    	   DynamicQuery dynamicQueryevent = DynamicQueryFactoryUtil.forClass(MyContent.class, classLoader);
		   dynamicQueryevent.add(PropertyFactoryUtil.forName("PodcastId").eq(podcastId));
		   dynamicQueryevent.add(PropertyFactoryUtil.forName("userId").eq(userId));
		   List<MyContent> mycontentdeleteimg;
		   try
		   {
			  mycontentdeleteimg = PlayListLocalServiceUtil.dynamicQuery(dynamicQueryevent);
			  long imgprimaryid = 0;
			  for (MyContent imgprimaryidlist : mycontentdeleteimg)
			  {
			     imgprimaryid = imgprimaryidlist.getMyContentId();
				}
				MyContentLocalServiceUtil.deleteMyContent(imgprimaryid);
			} 
		   catch (SystemException | PortalException e) 
		   {
			  _log.error(e.getMessage());
			}
		 }
		return VIEW_JSP;
	 }
	
		@SuppressWarnings("unchecked")
		@RenderMapping(params = CMD.ACTION + StringPool.EQUAL + RenderKeys.ADD_PLAYLIST)
		public String Addplaylistc(RenderRequest renderRequest, RenderResponse renderResponse) throws SystemException 
		{
		   String action = ParamUtil.getString(renderRequest, CMD.ACTION);
		   if (action.equals(RenderKeys.ADD_PLAYLIST)) 
		   {
		    long podcastId = ParamUtil.getLong(renderRequest, "podCastId");
			ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
			long userId = themeDisplay.getUserId();
			
			  DynamicQuery dynamicQueryevent = DynamicQueryFactoryUtil.forClass(PlayList.class, classLoader);
			  dynamicQueryevent.add(PropertyFactoryUtil.forName("PodcastId").eq(podcastId));
			  dynamicQueryevent.add(PropertyFactoryUtil.forName("userId").eq(userId));
			  
			List<PlayList> pList = PlayListLocalServiceUtil.dynamicQuery(dynamicQueryevent);
			if (pList.isEmpty()) 
			{
			 PlayList playerlist = null;
			 playerlist = new PlayListImpl();
			 try 
			 {
			  playerlist.setPlayListId(CounterLocalServiceUtil.increment(MyContent.class.getName()));
			 } catch (com.liferay.portal.kernel.exception.SystemException e) 
			 {
			   _log.error(e.getMessage());
			 }
			 
			playerlist.setPodcastId(podcastId);
			playerlist.setUserId(userId);
			long maxPriority = 0;
			
			List<PlayList> playLists = PlayListLocalServiceUtil.findPlaylistByUserId(userId);
			if (playLists.size() == 0) 
                {
					playerlist.setPriority(1);
				} else 
                {
					for (PlayList playList : playLists) {
						if (playList.getPriority() > maxPriority) {
							maxPriority = playList.getPriority();
						}
						playerlist.setPriority(maxPriority + 1);
					}
				}
					
			PlayListLocalServiceUtil.updatePlayList(playerlist);
		  }
			 DynamicQuery dynamicQueryeventdel = DynamicQueryFactoryUtil.forClass(MyContent.class, classLoader);
			 dynamicQueryeventdel.add(PropertyFactoryUtil.forName("PodcastId").eq(podcastId));
			 dynamicQueryeventdel.add(PropertyFactoryUtil.forName("userId").eq(userId));
			   List<MyContent> mycontentdeleteimg;
			   try
			   {
				  mycontentdeleteimg = PlayListLocalServiceUtil.dynamicQuery(dynamicQueryeventdel);
				  long imgprimaryid = 0;
				  for (MyContent imgprimaryidlist : mycontentdeleteimg)
				  {
				     imgprimaryid = imgprimaryidlist.getMyContentId();
					}
					MyContentLocalServiceUtil.deleteMyContent(imgprimaryid);
				} 
			   catch (SystemException | PortalException e) 
			   {
				  _log.error(e.getMessage());
				}
				
		 }
		return VIEW_JSP;
		}
	
		@SuppressWarnings("unchecked")
		@RenderMapping(params = CMD.ACTION+StringPool.EQUAL+RenderKeys.DELETE_PLAYLIST)
		
		public String s_deleteplay(RenderRequest renderRequest,RenderResponse renderResponse) throws SystemException 
		{
		   String action = ParamUtil.getString(renderRequest, CMD.ACTION);
		   if (action.equals(RenderKeys.DELETE_PLAYLIST)) 
		   {
			 long podcastId = ParamUtil.getLong(renderRequest, "podCastId");
			 ThemeDisplay themeDisplay = (ThemeDisplay) renderRequest.getAttribute(WebKeys.THEME_DISPLAY);
			 long userId = themeDisplay.getUserId();
			 
			 
			try {
			PlayList selectedPlayList = PlayListLocalServiceUtil.findByPodcastIdAndUserId(podcastId, userId);
			 
			List<PlayList>	playLists= PlayListLocalServiceUtil.findPlaylistByUserId(userId);
			 
			List<PlayList> modifiyinglist = ListUtil.subList(playLists, playLists.indexOf(selectedPlayList), playLists.size());
			
			for (PlayList modifiedlist : modifiyinglist){
				modifiedlist.setPriority(modifiedlist.getPriority()-1);
				PlayListLocalServiceUtil.updatePlayList(modifiedlist);
			}
			PlayListLocalServiceUtil.deletePlayList(selectedPlayList);
			
			
			DynamicQuery dynamicQueryeventa = DynamicQueryFactoryUtil.forClass(MyContent.class, classLoader);
			dynamicQueryeventa.add(PropertyFactoryUtil.forName("PodcastId").eq(podcastId));
			dynamicQueryeventa.add(PropertyFactoryUtil.forName("userId").eq(userId));
			  try {
				List<MyContent> pList =MyContentLocalServiceUtil.dynamicQuery(dynamicQueryeventa);
				
				if(pList.isEmpty()){
				
					MyContent playerlist= null;
					
					playerlist	= new  MyContentImpl();
					
					try {
						playerlist.setMyContentId(CounterLocalServiceUtil.increment(MyContent.class.getName()));
					} 
					catch (com.liferay.portal.kernel.exception.SystemException e) {
						
					}
					playerlist.setPodcastId(podcastId);
					playerlist.setUserId(userId);
					try {
						MyContentLocalServiceUtil.addMyContent(playerlist);
					} catch (com.liferay.portal.kernel.exception.SystemException e) { 
						
					}
					
					
				}else{
					
					
				}
				
			} catch (com.liferay.portal.kernel.exception.SystemException e1) {
				_log.error(""+e1.getMessage());
			
			}
			//PodJockeyPlayList podJockeyPlayList = PodJockeyPlayListLocalServiceUtil.findByuserIdAndPodcastId(podcastId, userId);
			//PodJockeyPlayListLocalServiceUtil.deletePodJockeyPlayList(podJockeyPlayList);
			} catch (NoSuchPlayListException e) {
				_log.error("NoSuchPlayListException error "+e.getMessage());
			}
		   }
		  return VIEW_JSP;
		  }
	
	
	@ResourceMapping(value = ResourceKeys.PLAYLIST_SORTABLE)
	public void episodeSorting(ResourceRequest resourceRequest, ResourceResponse resourceResponse) 
	{
	 ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);
	 long playlistId = ParamUtil.getLong(resourceRequest, "playlistId");
	 long playlistIndex = ParamUtil.getLong(resourceRequest, "playlistIndex");
	 long newPosition = playlistIndex;

		try {
			PlayList playlistItem = PlayListLocalServiceUtil
					.getPlayList(playlistId);
			List<PlayList> userPlaylist = PlayListLocalServiceUtil
					.findPlaylistByUserId(themeDisplay.getUserId());
			long currentPosition = userPlaylist.indexOf(playlistItem);
			if (newPosition > currentPosition) {
				List<PlayList> modifiablePlaylist = ListUtil.subList( 
						userPlaylist,
						Integer.parseInt(String.valueOf(currentPosition)) + 1,
						Integer.parseInt(String.valueOf(newPosition)));

				playlistItem.setPriority(newPosition);
				PlayListLocalServiceUtil.updatePlayList(playlistItem); 

				for (PlayList playlist : modifiablePlaylist) {
					playlist.setPriority(playlist.getPriority() - 1);
					PlayListLocalServiceUtil.updatePlayList(playlist);
				}

			} else if (newPosition < currentPosition) {

				List<PlayList> modifiablePlaylist = ListUtil.subList(
						userPlaylist,
						Integer.parseInt(String.valueOf(newPosition)) - 1,
						Integer.parseInt(String.valueOf(currentPosition)));
				playlistItem.setPriority(newPosition);
				PlayListLocalServiceUtil.updatePlayList(playlistItem);
				for (PlayList playlist2 : modifiablePlaylist) {
					playlist2.setPriority(playlist2.getPriority() + 1);
					PlayListLocalServiceUtil.updatePlayList(playlist2);

				}

			} else {
				if (newPosition < playlistItem.getPriority()) {
					List<PlayList> subList = ListUtil.subList(userPlaylist,
							Integer.parseInt(String.valueOf(newPosition)) - 1,
							Integer.parseInt(String.valueOf(currentPosition)));

					playlistItem.setPriority(newPosition);
					PlayListLocalServiceUtil.updatePlayList(playlistItem);
					for (PlayList playlist3 : subList) {
						playlist3.setPriority(playlist3.getPriority() + 1);
						PlayListLocalServiceUtil.updatePlayList(playlist3);
					}
				}

			}
		} catch (PortalException e) {
			_log.error(e.getMessage());

		} catch (SystemException e) {
			_log.error(e.getMessage());
		}

	}
		
}
