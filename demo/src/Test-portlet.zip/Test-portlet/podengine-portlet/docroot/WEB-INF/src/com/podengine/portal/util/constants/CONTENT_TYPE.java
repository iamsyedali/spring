package com.podengine.portal.util.constants;

public class CONTENT_TYPE {
	
	public static final String ADMIN_ADDED = "-1";
	
	public static final String HOSTED = "0";
	
	public static final String POSTED = "1";
	
}
