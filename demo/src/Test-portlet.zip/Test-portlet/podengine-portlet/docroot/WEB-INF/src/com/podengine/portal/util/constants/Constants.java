package com.podengine.portal.util.constants;

/**
 * @author Syed Ali
 */


public class Constants implements com.liferay.portal.kernel.util.Constants{
	
	public static final String OK_CAPS = "OK";
	
	public static final String OK_CAMEL = "Ok";
	
	public static final String YES = "Yes";
	
	public static final String NO = "No";
	
	public static final String CANCEL_CAPS = "CANCEL";
	
	public static final String CANCEL_CAMEL = "Cancel";
	
	public static final String EPISODE_ADDED_SUCCESSFULLY  = "Episode added Successfully.";
	
	public static final String EPISODE_ALREADY_EXISTS_IN_PLAYLIST  =  "Episode already exists in Playlist";
	
	public static final String FINDCONTENT_POPUP_TITLE = "Podcast Description";
	
	public static final String EPISODE_POPUP_TITLE = "All Episodes";
	
	public static final String PODJOCKEY_POPUP_TITLE = "Podjockey Description";
	
	public static final String DESCRIPTION = "description";
	
	public static final String LANGUAGE = "language";
	
	public static final String STATE = "state";
	
	public static final String COUNTRY = "country";
	
	public static final String CITY = "city";

}
