package com.podengine.portal.util;

import java.io.Serializable;
import java.util.Locale;
import java.util.Map;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.workflow.BaseWorkflowHandler;
import com.liferay.portal.kernel.workflow.WorkflowConstants;
import com.liferay.portlet.asset.service.AssetEntryLocalServiceUtil;
import com.podengine.service.model.RSSfeed;
import com.podengine.service.service.RSSfeedLocalServiceUtil;

public class HostAndPostWorkflowHandler extends BaseWorkflowHandler{

	@Override
	public String getClassName() {
		// TODO Auto-generated method stub
		return RSSfeed.class.getName();
	}

	@Override
	public String getType(Locale arg0) {
		// TODO Auto-generated method stub
		return "RSSfeed";
	}

	@Override
	public RSSfeed updateStatus(int status, Map<String, Serializable> workflowContext)
			throws PortalException, SystemException {
		//long userId = GetterUtil.getLong(WorkflowConstants.CONTEXT_USER_ID);
		long resourcePrimaryKey = GetterUtil.getLong(workflowContext.get(WorkflowConstants.CONTEXT_ENTRY_CLASS_PK));
		RSSfeed rssFeed = RSSfeedLocalServiceUtil.getRSSfeed(resourcePrimaryKey);
		rssFeed.setWorkflowStatus(status);
		//rssFeed.setFeedURL(rssFeed.getFeedURL());
		rssFeed.setTitle(rssFeed.getTitle());
		
		RSSfeedLocalServiceUtil.updateRSSfeed(rssFeed);
		
		if(status == WorkflowConstants.STATUS_APPROVED){
			AssetEntryLocalServiceUtil.updateVisible(RSSfeed.class.getName(), resourcePrimaryKey, true);
		}else{
			AssetEntryLocalServiceUtil.updateVisible(RSSfeed.class.getName(), resourcePrimaryKey, false);
		}
		return rssFeed;
	}

}
